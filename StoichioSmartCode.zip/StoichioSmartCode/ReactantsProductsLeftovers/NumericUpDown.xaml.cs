﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236
//This user control is for a customized NumericUpDown button for decreasing or incrementing the number of molecules for reactants
namespace ReactantsProductsLeftovers
{
    public sealed partial class NumericUpDown : UserControl
    {
        public int Minimum { get; set; } = 0;
        public int Maximum { get; set; } = 100;
        private int _value = 0;
        public int Value {
            get { return _value; }
            set
            {
                if (value >= Minimum && value <= Maximum)
                {
                    _value = value;
                    ValueTextBox.Text = _value.ToString();
                    ValueChanged?.Invoke(this, new RoutedEventArgs());
                }
            }
        }

        public event RoutedEventHandler ValueChanged;
        public NumericUpDown()
        {
            this.InitializeComponent();
        }

        private void DecreaseButton_Click(object sender, RoutedEventArgs e)
        {
            if (Value > Minimum)
            {
                Value--;
                ValueTextBox.Text = Value.ToString();
                ValueChanged?.Invoke(this, new RoutedEventArgs());
            }
        }

        private void IncreaseButton_Click(object sender, RoutedEventArgs e)
        {
            if (Value < Maximum)
            {
                Value++;
                ValueTextBox.Text = Value.ToString();
                ValueChanged?.Invoke(this, new RoutedEventArgs());
            }
        }
    }
}