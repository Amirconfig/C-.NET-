﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using static System.Collections.Specialized.BitVector32;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ReactantsProductsLeftovers
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Sandwiches : Page
    {
        //DynamicUIManager class that generates StackPanels, TextBlock, Image controls FOR REACTANTS WITH ONE PRODUCTS
        private DynamicUIManager dynamicUIManager;

        //DynamicUIManager class that generates StackPanels, TextBlock, Image controls FOR REACTANTS WITH TWO PRODUCTS
        private DynamicUIManagerTwoProducts dynamicUIManagerTwoProducts;

        // Class-level variable to store the selected reaction
        private string selectedReaction;

        //Variables for Molecules
        private int breadCount;
        private int meatCount;
        private int cheeseCount;
        private int breadCheeseSandwichProduced;
        private int meatCheeseSandichProduced;
        int formulaBread, formulaMeat, formulaCheese;
        int customSandwichProduced;

        //Class-level variable to store the path to or for molecular geometry for use
        private string molecularGeometry;
        private string reactant1Geometry;
        private string reactant2Geometry;
        private string reactant3Geometry;
        private string product1Geometry;
        private string product2Geometry;
        private string product3Geometry;

        private StackPanel stackPanel;
        private NumericUpDown numericUpDown;
        public Sandwiches()
        {
            this.InitializeComponent();
            this.dynamicUIManager = new DynamicUIManager();
            //Select Cheese reaction on launch
            selectReaction.SelectedIndex = 0;
        }
        private void SelectReaction_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (selectReaction.SelectedItem is ComboBoxItem selectedItem)
            {
                //reset the number of molecules/reactants before updating new reaction details
                reactant1.Value = 0;
                reactant2.Value = 0;
                reactant3.Value = 0;

                //Reset stackpanels each time a new reaction is selected
                imageStackPanel1.Children.Clear();
                imageStackPanel2.Children.Clear();

                //Reset the label for Products and LeftOvers after each selection of a reaction
                txtProducts.Margin = new Thickness(0, 0, 80, 0);
                txtLeftOvers.Margin = new Thickness(0, 0, 30, 0);


                selectedReaction = selectedItem.Content.ToString();
                // Logic to Update Reaction Details
                switch (selectedReaction)
                {
                    case "Cheese":
                        RestorePanelsDimension();

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/MakeCheeseSandwich.png"));


                        //Molecular Geometry to be added for reactant 1 and 2 and products
                        this.reactant1Geometry = "ms-appx:///Assets/Bread.png";
                        this.reactant2Geometry = "ms-appx:///Assets/Cheese.png";
                        this.product1Geometry = "ms-appx:///Assets/BreadSandwich.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri(this.reactant1Geometry));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri(this.reactant2Geometry));


                        productOneGeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/BreadSandwich.png"));
                        leftOver1GeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/Bread.png"));
                        leftOver2GeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/Cheese.png"));

                        break;
                    case "Meat And Cheese":
                        //Enable custom stackpanel
                        customSandwichStackPanel.Visibility = Visibility.Collapsed;
                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/Hams.png"));
                        GoHome.Margin = new Thickness(800, 10, 0, 0);

                        reactantsColumn1Panel.Width = 520;
                        beforeReactantion.Width = 520;
                        //Molecular Geometry to be added for reactant 1 and 2 and products
                        this.reactant1Geometry = "ms-appx:///Assets/Bread.png";
                        this.reactant2Geometry = "ms-appx:///Assets/Meat.png";
                        this.reactant3Geometry = "ms-appx:///Assets/Cheese.png";
                        this.product1Geometry = "ms-appx:///Assets/BreadMeatCheese.png";


                        //Enable UI Elements and set dimensions
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri(this.reactant1Geometry));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri(this.reactant2Geometry));
                        reactant3ImageGeometry.Visibility = Visibility.Visible;
                        reactant3ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/Cheese.png"));

                        //StackPanels to add images on button click
                        beforeReactantion.Width = 520;
                        reactantsPanel.Width = 500;

                        afterReactionsStackPanel.Width = 400;
                        reactant3Border.Visibility = Visibility.Visible;
                        imageStackPanel3.Visibility = Visibility.Visible;
                        reactant3Image.Visibility = Visibility.Visible;


                        reactant1ImageGeometry.Margin = new Thickness(0, 0, 70, 0);
                        reactant2ImageGeometry.Margin = new Thickness(20, 0, 20, 0);
                        reactant3ImageGeometry.Margin = new Thickness(70, 0, 0, 0);

                        //Buttons
                        reactant2.Margin = new Thickness(30, 0, 60, 0);
                        reactant3.Visibility = Visibility.Visible;
                        reactant3.Margin = new Thickness(0, 0, 0, 0);
                        imageStackPanel1.Margin = new Thickness(0, 0, 0, 0);
                        imageStackPanel3.Margin = new Thickness(0, 0, 0, 0);
                        imageStackPanel3.Margin = new Thickness(80, 0, 0, 0);

                        //Products and leftover panels dimensions
                        productLeftOverPanel.Width = 420;
                        productLeftOverPanel.Padding = new Thickness(0);
                        productLeftOverPanel.Margin = new Thickness(10);
                        leftOversPanel.Padding = new Thickness(25, 0, 10, 0);
                        imageStackPanelProductOne.Width = 105;
                        imageStackPanelLeftOver1.Width = 105;
                        imageStackPanelLeftOver2.Width = 105;
                        imageStackPanelLeftOver3.Visibility = Visibility.Visible;
                        imageStackPanelLeftOver3.Width = 105;
                        //labels for number of left overs
                        txtBlockProductMolecule.Width = 105;
                        txtBlockLeftOver1Molecule.Width = 105;
                        txtBlockLeftOver2Molecule.Width = 105;
                        txtBlockLeftOver3Molecule.Width = 105;

                        txtBlockLeftOver3Molecule.Visibility = Visibility.Visible;
                        leftOver3GeometryLabel.Visibility = Visibility.Visible;

                        //Set dimensions for geometries
                        productsLeftOversGeometryPanel.Padding = new Thickness(25, 0, 10, 0);
                        productsLeftOversGeometryPanel.Margin = new Thickness(0, 0, 30, 0);
                        productsLeftOversGeometryPanel.Width = 420;
                        productOneGeometryLabel.Width = 105;
                        leftOver1GeometryLabel.Width = 105;
                        leftOver2GeometryLabel.Width = 105;
                        leftOver3GeometryLabel.Width = 105;
                        txtProducts.Margin = new Thickness(0, 0, 120, 0);
                        txtLeftOvers.Margin = new Thickness(0, 0, 100, 0);
                        productOneGeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/BreadMeatCheese.png"));
                        leftOver1GeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/Bread.png"));
                        leftOver2GeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/Meat.png"));
                        leftOver3GeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/Cheese.png"));



                        break;
                    case "Custom Sandwich":
                        //Enable custom stackpanel
                        customSandwichStackPanel.Visibility = Visibility.Visible;
                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = null;
                        GoHome.Margin = new Thickness(100, 10, 0, 0);

                        reactantsColumn1Panel.Width = 520;
                        afterReactionsStackPanel.Width = 400;
                        //Molecular Geometry to be added for reactant 1 and 2 and products
                        this.reactant1Geometry = "ms-appx:///Assets/Bread.png";
                        this.reactant2Geometry = "ms-appx:///Assets/Meat.png";
                        this.reactant3Geometry = "ms-appx:///Assets/Cheese.png";
                        this.product1Geometry = "ms-appx:///Assets/StackSandwich.png";


                        //Enable UI Elements and set dimensions
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri(this.reactant1Geometry));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri(this.reactant2Geometry));
                        reactant3ImageGeometry.Visibility = Visibility.Visible;
                        reactant3ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/Cheese.png"));

                        //StackPanels to add images on button click
                        //StackPanels to add images on button click
                        beforeReactantion.Width = 520;
                        reactantsPanel.Width = 500;
                        reactant3Border.Visibility = Visibility.Visible;
                        imageStackPanel3.Visibility = Visibility.Visible;
                        reactant3Image.Visibility = Visibility.Visible;

                        reactant1ImageGeometry.Margin = new Thickness(0, 0, 70, 0);
                        reactant2ImageGeometry.Margin = new Thickness(20, 0, 20, 0);
                        reactant3ImageGeometry.Margin = new Thickness(70, 0, 0, 0);

                        //Buttons
                        reactant2.Margin = new Thickness(30, 0, 60, 0);
                        reactant3.Visibility = Visibility.Visible;
                        reactant3.Margin = new Thickness(0, 0, 0, 0);
                        imageStackPanel1.Margin = new Thickness(0, 0, 0, 0);
                        imageStackPanel3.Margin = new Thickness(0, 0, 0, 0);
                        imageStackPanel3.Margin = new Thickness(80, 0, 0, 0);

                        //Products and leftover panels dimensions
                        productLeftOverPanel.Width = 420;
                        productLeftOverPanel.Padding = new Thickness(0);
                        productLeftOverPanel.Margin = new Thickness(10);
                        leftOversPanel.Padding = new Thickness(25, 0, 10, 0);
                        imageStackPanelProductOne.Width = 105;
                        imageStackPanelLeftOver1.Width = 105;
                        imageStackPanelLeftOver2.Width = 105;
                        imageStackPanelLeftOver3.Visibility = Visibility.Visible;
                        imageStackPanelLeftOver3.Width = 105;
                        //labels for number of left overs
                        txtBlockProductMolecule.Width = 105;
                        txtBlockLeftOver1Molecule.Width = 105;
                        txtBlockLeftOver2Molecule.Width = 105;
                        txtBlockLeftOver3Molecule.Width = 105;

                        txtBlockLeftOver3Molecule.Visibility = Visibility.Visible;
                        leftOver3GeometryLabel.Visibility = Visibility.Visible;

                        //Set dimensions for geometries
                        productsLeftOversGeometryPanel.Padding = new Thickness(25, 0, 10, 0);
                        productsLeftOversGeometryPanel.Margin = new Thickness(0, 0, 30, 0);
                        productsLeftOversGeometryPanel.Width = 420;
                        productOneGeometryLabel.Width = 105;
                        leftOver1GeometryLabel.Width = 105;
                        leftOver2GeometryLabel.Width = 105;
                        leftOver3GeometryLabel.Width = 105;
                        txtProducts.Margin = new Thickness(0, 0, 120, 0);
                        txtLeftOvers.Margin = new Thickness(0, 0, 100, 0);

                        productOneGeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/StackSandwich.png"));
                        leftOver1GeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/Bread.png"));
                        leftOver2GeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/Meat.png"));
                        leftOver3GeometryLabel.Source = new BitmapImage(new Uri("ms-appx:///Assets/Cheese.png"));


                        break;
                }
            }
        }
        //Method to restore panels dimension for reactants that produce one product
        private void RestorePanelsDimension() {

            //Buttons
            reactant1.Width = 120;
            reactant2.Width = 120;
            reactant1.Margin = new Thickness(0, 0, 30, 0);
            reactant2.Margin = new Thickness(30, 0, 0, 0);
            reactant3.Visibility = Visibility.Collapsed;

            reactantsButtonPanel.Margin = new Thickness(10, 10, 10, 0);

            //Enable custom stackpanel
            customSandwichStackPanel.Visibility = Visibility.Collapsed;
            GoHome.Margin = new Thickness(800, 10, 0, 0);
            beforeReactantion.Width = 350;
            reactantsColumn1Panel.Width = 350;
            reactantsColumn1Panel.Padding = new Thickness(0, 0, 0, 0);
            reactantsColumn1Panel.Margin = new Thickness(0, 10, 0, 0);

            reactantsPanel.Width = 330;
            reactantsPanel.Padding = new Thickness(15, 0, 0, 0);
            reactantsPanel.Margin = new Thickness(0, 10, 0, 0);

            //Disable visibility for reactant 3 and leftover 3 panel, restore orginal dimensions
            reactant3Border.Visibility = Visibility.Collapsed;
            reactant3.Visibility = Visibility.Collapsed;
            reactant3ImageGeometry.Visibility = Visibility.Collapsed;
            imageStackPanelLeftOver3.Visibility = Visibility.Collapsed;
            txtBlockLeftOver3Molecule.Visibility = Visibility.Collapsed;
            leftOver3GeometryLabel.Visibility = Visibility.Collapsed;
            //Restoring original dimensions

            reactantsGeometryPanel.Margin = new Thickness(10, 10, 10, 0);
            reactant1ImageGeometry.Margin = new Thickness(0, 0, 80, 0);
            reactant2ImageGeometry.Margin = new Thickness(80, 0, 0, 0);

            //Products and leftover panels dimensions
            productLeftOverPanel.MinWidth = 380;
            productLeftOverPanel.Padding = new Thickness(15, 0, 25, 0);
            productLeftOverPanel.Margin = new Thickness(10, 10, 10, 0);

            leftOversPanel.Padding = new Thickness(50, 0, 10, 0);
            imageStackPanelProductOne.Width = 125;
            imageStackPanelLeftOver1.Width = 125;
            imageStackPanelLeftOver2.Width = 125;

            //labels for number of left overs
            txtBlockProductMolecule.Width = 125;
            txtBlockLeftOver1Molecule.Width = 125;
            txtBlockLeftOver2Molecule.Width = 125;

            productsLeftOversGeometryPanel.Padding = new Thickness(0);
            productsLeftOversGeometryPanel.Margin = new Thickness(50, 0, 30, 0);
            productsLeftOversGeometryPanel.Width = 420;
            productOneGeometryLabel.Width = 125;
            leftOver1GeometryLabel.Width = 125;
            leftOver2GeometryLabel.Width = 125;

            txtProducts.Margin = new Thickness(0, 0, 130, 0);
            txtLeftOvers.Margin = new Thickness(0, 0, 50, 0);
        }
        //Method to add molecular geometry/images for reactants based on button clicked and the value
        private void NumericUpDown_ValueChanged(object sender, RoutedEventArgs e)
        {
            if (selectReaction.SelectedIndex != -1)
            {
                //variable to hold the name of the button clicked
                this.numericUpDown = sender as NumericUpDown;

                //A call to the storyboard in MainPage.Xaml to animate the arrow after button click
                blowWindStoryboard.Begin();

                //Statement to check which button was clicked to assign appropriate panel and images to stack
                if (this.numericUpDown == reactant1)
                {
                    this.stackPanel = imageStackPanel1;
                    this.molecularGeometry = this.reactant1Geometry;
                }
                else if (this.numericUpDown == reactant2)
                {
                    this.stackPanel = imageStackPanel2;
                    this.molecularGeometry = this.reactant2Geometry;
                }
                else
                {
                    this.stackPanel = imageStackPanel3;
                    this.molecularGeometry = this.reactant3Geometry;
                }

                // count only Image elements
                int imageCount = this.stackPanel.Children.OfType<Image>().Count();

                //If the images the value of the button is greater than count of images, add image
                if (this.numericUpDown.Value > imageCount)
                {
                    // Add images with animation
                    for (int i = imageCount; i < this.numericUpDown.Value; i++)
                    {
                        AddImageToStackPanel(this.stackPanel, this.molecularGeometry);
                    }
                }
                else if (this.numericUpDown.Value < imageCount)
                {
                    // Remove images
                    for (int i = imageCount; i > this.numericUpDown.Value; i--)
                    {
                        this.stackPanel.Children.RemoveAt(0);
                    }
                }

                // Update the stack panel in real-time
                UpdateStackPanel();
            }
        }
        private void AddImageToStackPanel(StackPanel stackPanel, string molecularGeometry)
        {
            Image newImage = new Image
            {
                Source = new BitmapImage(new Uri(molecularGeometry)),
                Width = 50,
                Height = 50,
                Margin = new Thickness(5, 0, 5, 0),
                RenderTransform = new TranslateTransform(),
                RenderTransformOrigin = new Windows.Foundation.Point(0.5, 1) // Start from bottom
            };

            stackPanel.Children.Insert(0, newImage);

            // Animate the image to move upwards
            Storyboard storyboard = new Storyboard();
            DoubleAnimation translateAnimation = new DoubleAnimation
            {
                From = 50,
                To = 0,
                Duration = new Duration(TimeSpan.FromSeconds(0.5)),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(translateAnimation, newImage);
            Storyboard.SetTargetProperty(translateAnimation, "(UIElement.RenderTransform).(TranslateTransform.Y)");

            storyboard.Children.Add(translateAnimation);
            storyboard.Begin();
        }
        // Method to update the stack panel with the correct number of images
        private void UpdateStackPanel()
        {
            //Variables to hold the number of molecules for the reactants each time a button is clicked
            int reactant1Count = (int)reactant1.Value;
            int reactant2Count = (int)reactant2.Value;
            int reactant3Count = (int)reactant3.Value;
            // Logic to handle different reactions
            switch (selectedReaction)
            {
                case "Cheese":
                    // Number of H2 and O2 molecules available for the reaction
                    breadCount = reactant1Count;
                    cheeseCount = reactant2Count;

                    // Call to a method simulating Water Reaction
                    breadCheeseSandwichProduced = MakeBreadAndCheeseSandwich(ref breadCount, ref cheeseCount);

                    txtBlockProductMolecule.Text = breadCheeseSandwichProduced.ToString();
                    txtBlockLeftOver1Molecule.Text = breadCount.ToString();
                    txtBlockLeftOver2Molecule.Text = cheeseCount.ToString();

                    break;
                case "Meat And Cheese":
                    // Number of H2 and O2 molecules available for the reaction
                    this.breadCount = reactant1Count;
                    this.meatCount = reactant2Count;
                    this.cheeseCount = reactant3Count;

                    // Call to a method simulating Water Reaction
                    this.meatCheeseSandichProduced = MakeMeatAndCheeseSandwich(ref this.breadCount, ref meatCount, ref this.cheeseCount);

                    // Displaying the result
                    txtBlockProductMolecule.Text = this.meatCheeseSandichProduced.ToString();
                    txtBlockLeftOver1Molecule.Text = this.breadCount.ToString();
                    txtBlockLeftOver2Molecule.Text = this.meatCount.ToString();
                    txtBlockLeftOver3Molecule.Text = this.cheeseCount.ToString();


                    break;
                case "Custom Sandwich":
                    // Number of H2 and O2 molecules available for the reaction
                    this.breadCount = reactant1Count;
                    this.meatCount = reactant2Count;
                    this.cheeseCount = reactant3Count;

                    formulaBread = numberOfBread.Value;
                    formulaMeat = numberOfMeat.Value;
                    formulaCheese = numberOfCheese.Value;
                    if (formulaBread == 0 && formulaMeat == 0 && formulaCheese == 0)
                    {
                        return;
                    }
                    else
                    {
                        // Call the method to calculate sandwiches
                        customSandwichProduced = MakeCustomSandwiches(ref breadCount, ref meatCount, ref cheeseCount, (formulaBread, formulaMeat, formulaCheese));

                        // Displaying the result
                        txtBlockProductMolecule.Text = customSandwichProduced.ToString();
                        txtBlockLeftOver1Molecule.Text = this.breadCount.ToString();
                        txtBlockLeftOver2Molecule.Text = this.meatCount.ToString();
                        txtBlockLeftOver3Molecule.Text = this.cheeseCount.ToString();
                    }

                    break;
            }
            // Refresh the stack panel based on the updated molecule counts
            switch (selectedReaction)
            {
                case "Cheese":
                    UpdateLeftOverImages(imageStackPanelProductOne, breadCheeseSandwichProduced, this.product1Geometry);
                    UpdateLeftOverImages(imageStackPanelLeftOver1, breadCount, reactant1Geometry);
                    UpdateLeftOverImages(imageStackPanelLeftOver2, cheeseCount, reactant2Geometry);

                    break;
                case "Meat And Cheese":
                    UpdateLeftOverImages(imageStackPanelProductOne, this.meatCheeseSandichProduced, this.product1Geometry);
                    UpdateLeftOverImages(imageStackPanelLeftOver1, this.breadCount, this.reactant1Geometry);
                    UpdateLeftOverImages(imageStackPanelLeftOver2, this.meatCount, this.reactant2Geometry);
                    UpdateLeftOverImages(imageStackPanelLeftOver3, this.cheeseCount, this.reactant3Geometry);
                    break;
                case "Custom Sandwich":
                    if (formulaBread == 0 || formulaMeat == 0 || formulaCheese == 0)
                    {
                        UpdateLeftOverImages(imageStackPanelLeftOver1, this.breadCount, this.reactant1Geometry);
                        UpdateLeftOverImages(imageStackPanelLeftOver2, this.meatCount, this.reactant2Geometry);
                        UpdateLeftOverImages(imageStackPanelLeftOver3, this.cheeseCount, this.reactant3Geometry);

                    }

                    else
                    {
                        UpdateLeftOverImages(imageStackPanelProductOne, customSandwichProduced, this.product1Geometry);
                        UpdateLeftOverImages(imageStackPanelLeftOver1, this.breadCount, this.reactant1Geometry);
                        UpdateLeftOverImages(imageStackPanelLeftOver2, this.meatCount, this.reactant2Geometry);
                        UpdateLeftOverImages(imageStackPanelLeftOver3, this.cheeseCount, this.reactant3Geometry);

                    }
                    break;
            }
        }
        // Method to update the left-over images
        private void UpdateLeftOverImages(StackPanel stackPanel, int moleculeCount, string molecularGeometry)
        {
            // count only Image elements
            int imageCount = stackPanel.Children.OfType<Image>().Count();

            // Add or remove images to match the molecule count
            if (moleculeCount > imageCount)
            {
                for (int i = imageCount; i < moleculeCount; i++)
                {
                    AddImageToStackPanel(stackPanel, molecularGeometry);
                }
            }
            else if (moleculeCount < imageCount)
            {
                for (int i = imageCount; i > moleculeCount; i--)
                {
                    stackPanel.Children.RemoveAt(0);
                }
            }
        }
        private void NavigateToHome(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(HomePage));
            //Reset stackpanels
            imageStackPanel1.Children.Clear();
            imageStackPanel2.Children.Clear();
            productLeftOverPanel.Children.Clear();
            productsLeftOversGeometryPanel.Children.Clear();
        }
        static int MakeBreadAndCheeseSandwich(ref int breadCount, ref int cheeseCount)
        {
            // Stoichiometric coefficients for the reaction
            const int breadStoich = 2;
            const int cheeseStoich = 1;
            const int breadCheeseStoich = 1;

            // Calculate the maximum number of sandwich that can be produced
            int maxSandwichByBread = breadCount / breadStoich;
            int maxSandwichByCheese = cheeseCount / cheeseStoich;
            int maxBreadCheeseSandwich = Math.Min(maxSandwichByBread, maxSandwichByCheese) * breadCheeseStoich;

            // Update the remaining bread and cheese
            breadCount -= (maxBreadCheeseSandwich / breadCheeseStoich) * breadStoich;
            cheeseCount -= (maxBreadCheeseSandwich / breadCheeseStoich) * cheeseStoich;

            return maxBreadCheeseSandwich;
        }

        private void txtBlockSelectReactions_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        // Method to make meat and cheese sandwiches
        static int MakeMeatAndCheeseSandwich(ref int breadCount, ref int meatCount, ref int cheeseCount)
        {
            // Stoichiometric coefficients for the reaction
            const int breadStoich = 2;
            const int meatStoich = 1;
            const int cheeseStoich = 1;

            // Calculate the maximum number of sandwiches that can be produced
            int maxSandwichByBread = breadCount / breadStoich;
            int maxSandwichByMeat = meatCount / meatStoich;
            int maxSandwichByCheese = cheeseCount / cheeseStoich;
            int maxSandwiches = Math.Min(Math.Min(maxSandwichByBread, maxSandwichByMeat), maxSandwichByCheese);

            // Update the remaining bread, meat, and cheese
            breadCount -= maxSandwiches * breadStoich;
            meatCount -= maxSandwiches * meatStoich;
            cheeseCount -= maxSandwiches * cheeseStoich;

            return maxSandwiches;
        }
        //Method for Custom Sandwich
        public static int MakeCustomSandwiches(ref int breadCount, ref int meatCount, ref int cheeseCount, (int bread, int meat, int cheese) formula)
        {
            // Stoichiometric coefficients for the custom formula
            int breadStoich = formula.bread;
            int meatStoich = formula.meat;
            int cheeseStoich = formula.cheese;

            // Calculate the maximum number of sandwiches that can be produced
            int maxSandwichByBread = (breadStoich == 0) ? int.MaxValue : breadCount / breadStoich;
            int maxSandwichByMeat = (meatStoich == 0) ? int.MaxValue : meatCount / meatStoich;
            int maxSandwichByCheese = (cheeseStoich == 0) ? int.MaxValue : cheeseCount / cheeseStoich;

            int maxSandwiches = Math.Min(Math.Min(maxSandwichByBread, maxSandwichByMeat), maxSandwichByCheese);

            // Update the remaining bread, meat, and cheese
            if (breadStoich != 0)
                breadCount -= maxSandwiches * breadStoich;
            if (meatStoich != 0)
                meatCount -= maxSandwiches * meatStoich;
            if (cheeseStoich != 0)
                cheeseCount -= maxSandwiches * cheeseStoich;

            return maxSandwiches;
        }
    }
}
