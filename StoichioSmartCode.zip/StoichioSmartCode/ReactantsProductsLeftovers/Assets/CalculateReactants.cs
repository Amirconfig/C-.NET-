﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReactantsProductsLeftovers.Assets
{
    public static class CalculateReactants
    {
        //Method to calculate number of Hydrogen and Oxygen given amount of products and leftover
        public static void CalculateReactantsForH2AndO2(int waterMolecules, int remainingHydrogenMolecules, int remainingOxygenMolecules, out int initialHydrogenMolecules, out int initialOxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction 2H2 + O2 -> 2H2O
            const int hydrogenStoich = 2;
            const int oxygenStoich = 1;
            const int waterStoich = 2;

            // Calculate the number of hydrogen and oxygen molecules used to produce the given water molecules
            int hydrogenUsed = (waterMolecules / waterStoich) * hydrogenStoich;
            int oxygenUsed = (waterMolecules / waterStoich) * oxygenStoich;

            // Calculate the initial number of hydrogen and oxygen molecules
            initialHydrogenMolecules = hydrogenUsed + remainingHydrogenMolecules;
            initialOxygenMolecules = oxygenUsed + remainingOxygenMolecules;
        }

        // Method to calculate the initial number of reactants given the number of products and leftovers for ammonia production
        public static void CalculateReactantsForN2AndH2(int ammoniaMolecules, int remainingNitrogenMolecules, int remainingHydrogenMolecules, out int initialNitrogenMolecules, out int initialHydrogenMolecules)
        {
            // Stoichiometric coefficients for the reaction N2 + 3H2 -> 2NH3
            const int nitrogenStoich = 1;
            const int hydrogenStoich = 3;
            const int ammoniaStoich = 2;

            // Calculate the number of nitrogen and hydrogen molecules used to produce the given ammonia molecules
            int nitrogenUsed = (ammoniaMolecules / ammoniaStoich) * nitrogenStoich;
            int hydrogenUsed = (ammoniaMolecules / ammoniaStoich) * hydrogenStoich;

            // Calculate the initial number of nitrogen and hydrogen molecules
            initialNitrogenMolecules = nitrogenUsed + remainingNitrogenMolecules;
            initialHydrogenMolecules = hydrogenUsed + remainingHydrogenMolecules;
        }
        public static void CalculateReactantsForCh2oAndH2(int ch3ohMolecules, int remainingCh2oMolecules, int remainingH2Molecules, out int initialCh2oMolecules, out int initialH2Molecules)
        {
            // Stoichiometric coefficients for the reaction 1 CH₂O + 1 H₂ -> 1 CH₃OH
            const int ch2oStoich = 1;
            const int h2Stoich = 1;
            const int ch3ohStoich = 1;

            // Calculate the number of CH₂O and H₂ molecules used to produce the given CH₃OH molecules
            int ch2oUsed = (ch3ohMolecules / ch3ohStoich) * ch2oStoich;
            int h2Used = (ch3ohMolecules / ch3ohStoich) * h2Stoich;

            // Calculate the initial number of CH₂O and H₂ molecules
            initialCh2oMolecules = ch2oUsed + remainingCh2oMolecules;
            initialH2Molecules = h2Used + remainingH2Molecules;
        }

        public static void CalculateReactantsForCAndCo2(int coMolecules, int remainingCMolecules, int remainingCo2Molecules, out int initialCMolecules, out int initialCo2Molecules)
        {
            // Stoichiometric coefficients for the reaction 1 C + 1 CO₂ -> 2 CO
            const int cStoich = 1;
            const int co2Stoich = 1;
            const int coStoich = 2;

            // Calculate the number of C and CO₂ molecules used to produce the given CO molecules
            int cUsed = (coMolecules / coStoich) * cStoich;
            int co2Used = (coMolecules / coStoich) * co2Stoich;

            // Calculate the initial number of C and CO₂ molecules
            initialCMolecules = cUsed + remainingCMolecules;
            initialCo2Molecules = co2Used + remainingCo2Molecules;
        }

        public static void CalculateReactantsForP4AndF2(int pf3Molecules, int remainingP4Molecules, int remainingF2Molecules, out int initialP4Molecules, out int initialF2Molecules)
        {
            // Stoichiometric coefficients for the reaction P₄ + 6 F₂ -> 4 PF₃
            const int p4Stoich = 1;
            const int f2Stoich = 6;
            const int pf3Stoich = 4;

            // Calculate the number of P₄ and F₂ molecules used to produce the given PF₃ molecules
            int p4Used = (pf3Molecules / pf3Stoich) * p4Stoich;
            int f2Used = (pf3Molecules / pf3Stoich) * f2Stoich;

            // Calculate the initial number of P₄ and F₂ molecules
            initialP4Molecules = p4Used + remainingP4Molecules;
            initialF2Molecules = f2Used + remainingF2Molecules;
        }
        // Method to calculate the initial number of reactants given the number of products and leftovers for methane combustion
        public static void CalculateReactantsForCH4AndO2(int carbonDioxideMolecules, int waterMolecules, int remainingMethaneMolecules, int remainingOxygenMolecules, out int initialMethaneMolecules, out int initialOxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction CH4 + 2O2 -> CO2 + 2H2O
            const int methaneStoich = 1;
            const int oxygenStoich = 2;
            const int carbonDioxideStoich = 1;
            const int waterStoich = 2;

            // Calculate the number of methane and oxygen molecules used to produce the given carbon dioxide and water molecules
            int methaneUsed = (carbonDioxideMolecules / carbonDioxideStoich) * methaneStoich;
            int oxygenUsed = (carbonDioxideMolecules / carbonDioxideStoich) * oxygenStoich;

            // Calculate the initial number of methane and oxygen molecules
            initialMethaneMolecules = methaneUsed + remainingMethaneMolecules;
            initialOxygenMolecules = oxygenUsed + remainingOxygenMolecules;
        }
        public static void CalculateReactantsForAlAndFe2O3(int aluminumOxideProduced, int ironProduced, int remainingAluminum, int remainingIronOxide, out int initialAluminum, out int initialIronOxide)
        {
            const int aluminumStoich = 2;
            const int ironOxideStoich = 1;
            const int ironStoich = 2;
            const int aluminumOxideStoich = 1;

            int aluminumUsed = (ironProduced / ironStoich) * aluminumStoich;
            int ironOxideUsed = (ironProduced / ironStoich) * ironOxideStoich;

            initialAluminum = aluminumUsed + remainingAluminum;
            initialIronOxide = ironOxideUsed + remainingIronOxide;
        }
        // Method to calculate the initial number of reactants given the number of products and leftovers for ethane combustion
        public static void CalculateReactantsForC2H6AndO2(int carbonDioxideMolecules, int waterMolecules, int remainingEthaneMolecules, int remainingOxygenMolecules, out int initialEthaneMolecules, out int initialOxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction C2H6 + 3.5O2 -> 2CO2 + 3H2O
            const int ethaneStoich = 1;
            const int oxygenStoich = 7;
            const int carbonDioxideStoich = 2;
            const int waterStoich = 3;

            // Calculate the number of ethane and oxygen molecules used to produce the given carbon dioxide and water molecules
            int ethaneUsed = (carbonDioxideMolecules / carbonDioxideStoich) * ethaneStoich;
            int oxygenUsed = (carbonDioxideMolecules / carbonDioxideStoich) * oxygenStoich;

            // Calculate the initial number of ethane and oxygen molecules
            initialEthaneMolecules = ethaneUsed + remainingEthaneMolecules;
            initialOxygenMolecules = oxygenUsed + remainingOxygenMolecules;
        }
        public static void CalculateReactantsForC2H5OHAndO2(int carbonDioxideProduced, int waterProduced, int remainingEthanol, int remainingOxygen, out int initialEthanol, out int initialOxygen)
        {
            const int ethanolStoich = 1;
            const int oxygenStoich = 3;
            const int carbonDioxideStoich = 2;
            const int waterStoich = 3;

            int ethanolUsed = (carbonDioxideProduced / carbonDioxideStoich) * ethanolStoich;
            int oxygenUsed = (carbonDioxideProduced / carbonDioxideStoich) * oxygenStoich;

            initialEthanol = ethanolUsed + remainingEthanol;
            initialOxygen = oxygenUsed + remainingOxygen;
        }
        public static void CalculateReactantsForFeOAndNa(int sodiumOxideProduced, int ironProduced, int remainingIronOxide, int remainingSodium, out int initialIronOxide, out int initialSodium)
        {
            const int ironOxideStoich = 1;
            const int sodiumStoich = 2;
            const int sodiumOxideStoich = 1;
            const int ironStoich = 1;

            int ironOxideUsed = (sodiumOxideProduced / sodiumOxideStoich) * ironOxideStoich;
            int sodiumUsed = (sodiumOxideProduced / sodiumOxideStoich) * sodiumStoich;

            initialIronOxide = ironOxideUsed + remainingIronOxide;
            initialSodium = sodiumUsed + remainingSodium;
        }
        // Method to calculate the initial number of reactants given the number of products and leftovers for ethene combustion
        public static void CalculateReactantsForC2H4AndO2(int carbonDioxideMolecules, int waterMolecules, int remainingEtheneMolecules, int remainingOxygenMolecules, out int initialEtheneMolecules, out int initialOxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction C2H4 + 3O2 -> 2CO2 + 2H2O
            const int etheneStoich = 1;
            const int oxygenStoich = 3;
            const int carbonDioxideStoich = 2;
            const int waterStoich = 2;

            // Calculate the number of ethene and oxygen molecules used to produce the given carbon dioxide and water molecules
            int etheneUsed = (carbonDioxideMolecules / carbonDioxideStoich) * etheneStoich;
            int oxygenUsed = (carbonDioxideMolecules / carbonDioxideStoich) * oxygenStoich;

            // Calculate the initial number of ethene and oxygen molecules
            initialEtheneMolecules = etheneUsed + remainingEtheneMolecules;
            initialOxygenMolecules = oxygenUsed + remainingOxygenMolecules;
        }
        // Method to calculate the initial number of reactants given the number of products and leftovers for glucose fermentation
        public static void CalculateReactantsForC6H12O6(int ethanolMolecules, int carbonDioxideMolecules, int remainingGlucoseMolecules, out int initialGlucoseMolecules)
        {
            // Stoichiometric coefficients for the reaction C6H12O6 -> 2C2H5OH + 2CO2
            const int glucoseStoich = 1;
            const int ethanolStoich = 2;
            const int carbonDioxideStoich = 2;

            // Calculate the number of glucose molecules used to produce the given ethanol and carbon dioxide molecules
            int glucoseUsed = (ethanolMolecules / ethanolStoich) * glucoseStoich;

            // Calculate the initial number of glucose molecules
            initialGlucoseMolecules = glucoseUsed + remainingGlucoseMolecules;
        }
        public static void CalculateReactantsForFe2O3AndC(int ironProduced, int carbonMonoxideProduced, int remainingIronOxide, int remainingCarbon, out int initialIronOxide, out int initialCarbon)
        {
            const int ironOxideStoich = 1;
            const int carbonStoich = 3;
            const int ironStoich = 2;
            const int carbonMonoxideStoich = 3;

            int ironOxideUsed = (ironProduced / ironStoich) * ironOxideStoich;
            int carbonUsed = (ironProduced / ironStoich) * carbonStoich;

            initialIronOxide = ironOxideUsed + remainingIronOxide;
            initialCarbon = carbonUsed + remainingCarbon;
        }
    }
}
