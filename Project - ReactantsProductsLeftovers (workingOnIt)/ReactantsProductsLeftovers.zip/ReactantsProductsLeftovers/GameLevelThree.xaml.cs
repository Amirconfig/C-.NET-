﻿using ReactantsProductsLeftovers.Assets;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Shapes;
using static System.Net.Mime.MediaTypeNames;
using Image = Windows.UI.Xaml.Controls.Image;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ReactantsProductsLeftovers
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class GameLevelThree : Page
    {
        //DynamicUIManager class that generates StackPanels, TextBlock, Image controls FOR REACTANTS WITH ONE PRODUCTS
        private DynamicUIManager dynamicUIManager;

        //DynamicUIManager class that generates StackPanels, TextBlock, Image controls FOR REACTANTS WITH TWO PRODUCTS
        private DynamicUIManagerTwoProducts dynamicUIManagerTwoProducts;

        //Variables for holding the initial number of molecules
        private int originalHydrogen;
        private int originalOxygen;
        private int originalNitrogen;
        private int originalMethane;
        private int originalAluminum;
        private int originalIronOxide;

        //Variables to hold expected reactants after re-calculating
        private int waterReactionWaterProduced;
        private int waterReactionRemainingHydrogen;
        private int waterReactionRemainingOxygen;

        private int ammoniaReactionAmmoniaProduced;
        private int ammoniaReactionRemainingNitrogen;
        private int ammoniaReactionRemainingHydrogen;

        private int methaneReactionCO2Produced;
        private int methaneReactionH2OProduced;
        private int methaneReactionRemainingMethane;
        private int methaneReactionRemainingOxygen;
        private Tuple<int, int> methaneReactionResult;

        private int thermiteReactionRemainingAluminum;
        private int thermiteReactionRemainingIronOxide;
        private int thermiteReactionAluminumOxideProduced;
        private int thermiteReactionIronProduced;
        private Tuple<int, int> thermiteReactionResult;

        private int originalEthane;
        private int ethaneReactionCO2Produced;
        private int ethaneReactionH2OProduced;
        private int ethaneReactionRemainingEthane;
        private int ethaneReactionRemainingOxygen;
        private Tuple<int, int> ethaneReactionResult;


        private int originalEthanol;
        private int ethanolReactionCO2Produced;
        private int ethanolReactionH2OProduced;
        private int ethanolReactionRemainingEthanol;
        private int ethanolReactionRemainingOxygen;
        private Tuple<int, int> ethanolReactionResult;

        private int originalIronIIOxide;
        private int originalSodium;
        private int ironSodiumReactionRemainingIronII;
        private int ironSodiumReactionRemainingSodium;
        private int ironSodiumReactionSodiumOxideProduced;
        private int ironSodiumReactionIronProduced;
        private Tuple<int, int> ironSodiumReactionResult;
        //***

        //***
        //Inputs
        private int productOneInput;
        private int productTwoInput;
        private int leftOver1Input;
        private int leftOver2Input;

        //Variables for StackPanels
        private StackPanel productOnePanel, productTwoPanel, leftOverOnePanel, leftOverTwoPanel;

        //Private tuple to hold the reaction results
        private int ammoniaMoleculesProduced;


        // Variables to hold desired leftover amounts
        private int desiredHydrogen;
        private int desiredNitrogen;


        //Variables to hold desired product amounts
        private int desiredAmmonia;


        //
        //


        //Class-level variable to store the path to or for molecular geometry for use
        private string molecularGeometry;
        private string reactant1Geometry;
        private string reactant2Geometry;
        private string productOneGeometry;
        private string productTwoGeometry;

        //Class level variable for a stackPanel. Used to determine the stackpanel to insert molecular geometry
        private StackPanel stackPanel;

        //Class level variable for NumericUpDown button
        private NumericUpDown numericUpDown;

        //Variable to hold the list of reactions
        private List<string> reactionNames;
        private List<string> selectedReactionName;
        private int currentChallengeNumber;
        private int totalScore;
        private int attempts;
        public GameLevelThree()
        {
            this.InitializeComponent();
            //Set the Question Mark Visible
            questionMark.Visibility = Visibility.Visible;
            // Initialize the list of reactions
            InitializeReactions();

            //Initialize selected reaction
            SelectRandomReaction();

            //Initialize The Method to display 5 Challenges
            ReactionChallenges();

            // Subscribe to ValueChanged events for NumericUpDown controls
            productOne.ValueChanged += NumericUpDown_ValueChanged;
            productTwo.ValueChanged += NumericUpDown_ValueChanged;
            LeftOver1Button.ValueChanged += NumericUpDown_ValueChanged;
            LeftOver2Button.ValueChanged += NumericUpDown_ValueChanged;

            //Initialize number of challenge attempts
            attempts = 0;
        }
        //Method to initialize a list of reactions
        private void InitializeReactions()
        {
            reactionNames = new List<string>
            {
                "Combust Methane",
                "Thermite Reaction",
                "Combust Ethane",
                "Combust Ethanol",
                "Iron (II) Oxide and Sodium"
            };
            totalScore = 0;
        }
        //The method use LINQ to order the questions randomly and then takes the first 5 questions.
        private void SelectRandomReaction()
        {
            Random randomReaction = new Random();
            selectedReactionName = reactionNames.OrderBy(x => randomReaction.Next()).Take(5).ToList();
            currentChallengeNumber = 0;
        }

        //A method to Display the Selected Challenges
        private void ReactionChallenges()
        {
            if (currentChallengeNumber < selectedReactionName.Count)
            {
                //Use random function to randomly generate number of products and leftovers
                Random randomReactants = new Random();
                //Display current challenge number
                txtChallengeNumber.Text = $"Challenge {currentChallengeNumber + 1} of {selectedReactionName.Count}";

                // Set reactants, products, and leftovers details: TextBlock labels, geometry/images
                switch (selectedReactionName[currentChallengeNumber])
                {
                    case "Combust Methane":
                        // Randomly Set initial amount of reactants
                        int randomMethane = randomReactants.Next(1, 9);
                        int randomMethaneOxygen = randomReactants.Next(1, 9);

                        //Assign the random molecules to retain same values in subsequent calculations
                        originalMethane = randomMethane;
                        originalOxygen = randomMethaneOxygen;

                        // Get the reaction results from ReactCH4AndO2
                        methaneReactionResult = ChemicalReactions.ReactCH4AndO2(ref originalMethane, ref originalOxygen);
                        methaneReactionCO2Produced = methaneReactionResult.Item1;
                        methaneReactionH2OProduced = methaneReactionResult.Item2;
                        methaneReactionRemainingMethane = originalMethane;
                        methaneReactionRemainingOxygen = originalOxygen;


                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);


                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustMethane.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "CH4";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "CH4";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/CH4.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/CH4.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));


                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CH4.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        
                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");

                        //set width of generate pamels
                        this.productOnePanel.Width = 125;
                        this.productTwoPanel.Width = 125;
                        this.leftOverOnePanel.Width = 125;
                        this.leftOverTwoPanel.Width = 125;

                        //
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Margin = new Thickness(60, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Margin = new Thickness(85, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Margin = new Thickness(85, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Margin = new Thickness(80, 0, 40, 0);

                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Margin = new Thickness(60, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Margin = new Thickness(85, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Margin = new Thickness(85, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Margin = new Thickness(80, 0, 40, 0);

                        //Assign the labels with initial desired number of reactants
                        txtReactant1Molecules.Text = randomMethane.ToString();
                        txtReactant2Molecules.Text = randomMethaneOxygen.ToString();


                        //Add geometries for desired reactants
                        for (int i = 0; i < randomMethane; i++)
                        {
                            AddImageToStackPanel(this.imageStackPanel1, this.reactant1Geometry);
                        }
                        for (int i = 0; i < randomMethaneOxygen; i++)
                        {
                            AddImageToStackPanel(this.imageStackPanel2, this.reactant2Geometry);
                        }
                        break;
                    case "Thermite Reaction":
                        // Set initial amount of desired products and leftovers - 2Al + Fe2O3 -> Al2O3 + 2Fe
                        int randomAluminum = randomReactants.Next(1, 9);
                        int randomIronOxide = randomReactants.Next(1, 9);

                        //Assign the random molecules to retain same values in subsequent calculations
                        originalAluminum = randomAluminum;
                        originalIronOxide = randomIronOxide;

                        //Call to a method simulating Thermite Reaction
                        thermiteReactionResult = ChemicalReactions.ReactAlAndFe2O3(ref originalAluminum, ref originalIronOxide);

                        thermiteReactionAluminumOxideProduced= thermiteReactionResult.Item1;
                        thermiteReactionIronProduced = thermiteReactionResult.Item2;
                        thermiteReactionRemainingAluminum = originalAluminum;
                        thermiteReactionRemainingIronOxide = originalIronOxide;


                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);


                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/ThermiteReaction.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "Al";
                        txtBlockReactant2.Text = "Fe2O3";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "Al2O3";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "Fe";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "Al";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "Fe2O3";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/AL.png";
                        this.reactant2Geometry = "ms-appx:///Assets/FE2O3.png";
                        this.productOneGeometry = "ms-appx:///Assets/AL2O3.png";
                        this.productTwoGeometry = "ms-appx:///Assets/FE.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/AL.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/FE2O3.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/AL2O3.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FE.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/AL.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FE2O3.png"));


                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");
                        //
                        //set width of generate pamels
                        this.productOnePanel.Width = 125;
                        this.productTwoPanel.Width = 125;
                        this.leftOverOnePanel.Width = 125;
                        this.leftOverTwoPanel.Width = 125;

                        //
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Margin = new Thickness(60, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Margin = new Thickness(85, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Margin = new Thickness(85, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Margin = new Thickness(80, 0, 40, 0);

                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Margin = new Thickness(60, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Margin = new Thickness(85, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Margin = new Thickness(85, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Margin = new Thickness(80, 0, 40, 0);

                        //Assign the labels with initial desired number of reactants
                        txtReactant1Molecules.Text = randomAluminum.ToString();
                        txtReactant2Molecules.Text = randomIronOxide.ToString();

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < thermiteReactionAluminumOxideProduced; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < thermiteReactionIronProduced; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        //Desired Leftovers
                        for (int i = 0; i < thermiteReactionRemainingAluminum; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < thermiteReactionRemainingIronOxide; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Combust Ethane":
                        // Set initial amount of desired products and leftovers - 2C2H6 + 7O2 -> 4CO2 + 6H2O
                        int randomEthane = randomReactants.Next(1, 9);
                        int randomEthaneOxygen = randomReactants.Next(1, 9);

                        originalEthane = randomEthane;
                        originalOxygen = randomEthaneOxygen;


                        //Call to a method simulating Ethane Combustion
                        ethaneReactionResult = ChemicalReactions.ReactC2H6AndO2(ref originalEthane, ref originalOxygen);
                        ethaneReactionCO2Produced = ethaneReactionResult.Item1;
                        ethaneReactionH2OProduced = ethaneReactionResult.Item2;
                        ethaneReactionRemainingEthane = originalEthane;
                        ethaneReactionRemainingOxygen = originalOxygen;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustEthane.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "C2H6";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "C2H6";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/C2H6.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H6.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H6.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");
                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");
                        //
                        //set width of generate pamels
                        this.productOnePanel.Width = 125;
                        this.productTwoPanel.Width = 125;
                        this.leftOverOnePanel.Width = 125;
                        this.leftOverTwoPanel.Width = 125;

                        //
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Margin = new Thickness(60, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Margin = new Thickness(85, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Margin = new Thickness(85, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Margin = new Thickness(80, 0, 40, 0);

                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Margin = new Thickness(60, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Margin = new Thickness(85, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Margin = new Thickness(85, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Margin = new Thickness(80, 0, 40, 0);

                        //Assign the labels with initial desired number of reactants
                        txtReactant1Molecules.Text = randomEthane.ToString();
                        txtReactant2Molecules.Text = randomEthaneOxygen.ToString();

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < ethaneReactionCO2Produced; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < ethaneReactionH2OProduced; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        //Desired Leftovers
                        for (int i = 0; i < ethaneReactionRemainingEthane; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < ethaneReactionRemainingOxygen; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Combust Ethanol":
                        //Set initial amount of leftovers - C2H5OH + 3O2 -> 2CO2 + 3H2O
                        int randomEthanol = randomReactants.Next(1, 9);
                        int randomEthanolOxygen = randomReactants.Next(1, 9);

                        //Call to a method simulating Ethanol Combustion
                        ethanolReactionResult = ChemicalReactions.ReactC2H5OHAndO2(ref originalEthanol, ref originalOxygen);

                        //Desired products
                        ethanolReactionCO2Produced = ethanolReactionResult.Item1;
                        ethanolReactionH2OProduced = ethanolReactionResult.Item2;
                        ethanolReactionRemainingEthanol = originalEthanol;
                        ethanolReactionRemainingOxygen = originalOxygen;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustEthanol.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "C2H5OH";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "C2H5OH";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/C2H5OH.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H5OH.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));


                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H5OH.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");
                        //
                        //set width of generate pamels
                        this.productOnePanel.Width = 125;
                        this.productTwoPanel.Width = 125;
                        this.leftOverOnePanel.Width = 125;
                        this.leftOverTwoPanel.Width = 125;

                        //
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Margin = new Thickness(60, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Margin = new Thickness(85, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Margin = new Thickness(85, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Margin = new Thickness(80, 0, 40, 0);

                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Margin = new Thickness(60, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Margin = new Thickness(85, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Margin = new Thickness(85, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Margin = new Thickness(80, 0, 40, 0);

                        //Assign the labels with initial desired number of reactants
                        txtReactant1Molecules.Text = randomEthanol.ToString();
                        txtReactant2Molecules.Text = randomEthanolOxygen.ToString();

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < ethanolReactionCO2Produced; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < ethanolReactionH2OProduced; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        //Desired Leftovers
                        for (int i = 0; i < ethanolReactionRemainingEthanol; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < ethanolReactionRemainingOxygen; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Iron (II) Oxide and Sodium":
                        // Set initial amount of desired products and leftovers - FeO + 2Na -> Na2O + Fe
                        int randomIronIIOxide = randomReactants.Next(1, 9);
                        int randomSodium = randomReactants.Next(1, 9);

                        originalIronIIOxide = randomIronIIOxide;
                        originalSodium = randomSodium;


                        //Call to a method simulating Reaction of Iron II Oxide and Sodium
                        ironSodiumReactionResult = ChemicalReactions.ReactFeOAndNa(ref originalIronIIOxide, ref originalSodium);

                        //Desired products
                        ironSodiumReactionSodiumOxideProduced = ironSodiumReactionResult.Item1;
                        ironSodiumReactionIronProduced = ironSodiumReactionResult.Item2;

                        ironSodiumReactionRemainingIronII = originalIronIIOxide;
                        ironSodiumReactionRemainingSodium = originalSodium;


                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/IronIIOxideAndSodium.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "FeO";
                        txtBlockReactant2.Text = "Na";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "Na2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "Fe";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "FeO";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "Na";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/FeO.png";
                        this.reactant2Geometry = "ms-appx:///Assets/Na.png";
                        this.productOneGeometry = "ms-appx:///Assets/Na2O.png";
                        this.productTwoGeometry = "ms-appx:///Assets/Fe.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/FeO.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/Na.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/Na2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/Fe.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FeO.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/Na.png"));

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");
                        //
                        //set width of generate pamels
                        this.productOnePanel.Width = 125;
                        this.productTwoPanel.Width = 125;
                        this.leftOverOnePanel.Width = 125;
                        this.leftOverTwoPanel.Width = 125;

                        //
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Margin = new Thickness(60, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Margin = new Thickness(85, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Margin = new Thickness(85, 0, 40, 0);
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Margin = new Thickness(80, 0, 40, 0);

                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Margin = new Thickness(60, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Margin = new Thickness(85, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Margin = new Thickness(85, 0, 40, 0);
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Margin = new Thickness(80, 0, 40, 0);

                        //Assign the labels with initial desired number of reactants
                        txtReactant1Molecules.Text = randomIronIIOxide.ToString();
                        txtReactant2Molecules.Text = randomSodium.ToString();

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < ironSodiumReactionSodiumOxideProduced; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < ironSodiumReactionIronProduced; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        //Desired Leftovers
                        for (int i = 0; i < ironSodiumReactionRemainingIronII; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < ironSodiumReactionRemainingSodium; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                }
            }
        }

        //Method to add molecular geometry/images for reactants based on button clicked and the value
        private void NumericUpDown_ValueChanged(object sender, RoutedEventArgs e)
        {
            if (selectedReactionName != null)
            {
                //Set the Question Mark image to invisible
                questionMark.Visibility = Visibility.Collapsed;
                //Set Sad Face invisible if present
                sadFace.Visibility = Visibility.Collapsed;
                //Set Smiley Face invisible if present
                smileyFace.Visibility = Visibility.Collapsed;

                //variable to hold the name of the button clicked
                this.numericUpDown = sender as NumericUpDown;

                //A call to the storyboard in MainPage.Xaml to animate the arrow after button click
                blowWindStoryboard.Begin();

                //Statement to check which button was clicked to assign appropriate panel and images to stack
                if (this.numericUpDown == productOne)
                {
                    this.stackPanel = productOnePanel;
                    this.molecularGeometry = this.productOneGeometry;
                }
                if (this.numericUpDown == productTwo)
                {
                    this.stackPanel = productTwoPanel;
                    this.molecularGeometry = this.productTwoGeometry;
                }
                else if (this.numericUpDown == LeftOver1Button)
                {
                    this.stackPanel = leftOverOnePanel;
                    this.molecularGeometry = this.reactant1Geometry;
                }
                else if (this.numericUpDown == this.LeftOver2Button)
                {
                    this.stackPanel = leftOverTwoPanel;
                    this.molecularGeometry = this.reactant2Geometry;
                }
                // count only Image elements
                int imageCount = this.stackPanel.Children.OfType<Image>().Count();

                //If the value of the button is greater than count of images, add image
                if (this.numericUpDown.Value > imageCount)
                {
                    // Add images with animation
                    for (int i = imageCount; i < this.numericUpDown.Value; i++)
                    {
                        AddImageToStackPanel(this.stackPanel, this.molecularGeometry);
                    }
                }
                else if (this.numericUpDown.Value < imageCount)
                {
                    // Remove images
                    for (int i = imageCount; i > this.numericUpDown.Value; i--)
                    {
                        this.stackPanel.Children.RemoveAt(0);
                    }
                }
            }
        }

        // Method to add Molecular geometry to the stack panel
        private void AddImageToStackPanel(StackPanel stackPanel, string molecularGeometry)
        {
            Image newImage = new Image
            {
                Source = new BitmapImage(new Uri(molecularGeometry)),
                Width = 50,
                Height = 50,
                Margin = new Thickness(5, 0, 5, 0),
                RenderTransform = new TranslateTransform(),
                RenderTransformOrigin = new Windows.Foundation.Point(0.5, 1) // Start from bottom
            };

            stackPanel.Children.Insert(0, newImage); // Insert images at the beginning of the StackPanel

            // Animate the image to move upwards
            Storyboard storyboard = new Storyboard();
            DoubleAnimation translateAnimation = new DoubleAnimation
            {
                From = 50, // Starting position below the visible area
                To = 0,    // Ending position (final position in the StackPanel)
                Duration = new Duration(TimeSpan.FromSeconds(0.5)),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(translateAnimation, newImage);
            Storyboard.SetTargetProperty(translateAnimation, "(UIElement.RenderTransform).(TranslateTransform.Y)");

            storyboard.Children.Add(translateAnimation);
            storyboard.Begin();
        }

        //On-click Event: takes the number of molecules entered, simulate the reaction, and check if user has provided correct number of reactants
        private void BalanceEquationButton_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("BalanceEquationButton_Click called");
            //Set the Question Mark image to invisible
            questionMark.Visibility = Visibility.Collapsed;
            //Set Sad Face invisible if present
            sadFace.Visibility = Visibility.Collapsed;
            //Set Smiley Face invisible if present
            smileyFace.Visibility = Visibility.Collapsed;

            switch (selectedReactionName[currentChallengeNumber])
            {
                case "Combust Methane":
                    //Recalculate Reactants
                    CalculateReactants.CalculateReactantsForCH4AndO2(methaneReactionCO2Produced, methaneReactionH2OProduced, originalMethane, originalOxygen, out int expectedMethane, out int expectedMethaneOxygen);
                    //Products and leftovers entered by user
                    productOneInput = productOne.Value;
                    productTwoInput = productTwo.Value;
                    leftOver1Input = LeftOver1Button.Value;
                    leftOver2Input = LeftOver2Button.Value;


                    //Compare calculated initial product and leftovers with user input
                    CheckTwoProducts(methaneReactionCO2Produced, methaneReactionH2OProduced, methaneReactionRemainingMethane, methaneReactionRemainingOxygen, productOneInput, productTwoInput, leftOver1Input, leftOver2Input);

                    break;
                case "Thermite Reaction":

                    CalculateReactants.CalculateReactantsForAlAndFe2O3(thermiteReactionAluminumOxideProduced,thermiteReactionIronProduced, originalAluminum, originalIronIIOxide, out int expectedAluminum, out int expectedIronIIOxide);
                    //Products and leftovers entered by user
                    productOneInput = productOne.Value;
                    productTwoInput = productTwo.Value;
                    leftOver1Input = LeftOver1Button.Value;
                    leftOver2Input = LeftOver2Button.Value;


                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(thermiteReactionAluminumOxideProduced, thermiteReactionIronProduced, thermiteReactionRemainingAluminum, thermiteReactionRemainingIronOxide, productOneInput, productTwoInput, leftOver1Input, leftOver2Input);

                    break;
                case "Combust Ethane":

                    CalculateReactants.CalculateReactantsForC2H6AndO2(ethaneReactionCO2Produced, ethaneReactionH2OProduced, originalEthane, originalOxygen, out int expectedEthane, out int expectedEthaneOxygen);
                    
                    productOneInput = productOne.Value;
                    productTwoInput = productTwo.Value;
                    leftOver1Input = LeftOver1Button.Value;
                    leftOver2Input = LeftOver2Button.Value;

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(ethaneReactionCO2Produced, ethaneReactionH2OProduced, ethaneReactionRemainingEthane, ethaneReactionRemainingOxygen, productOneInput, productTwoInput, leftOver1Input, leftOver2Input);

                    break;
                case "Combust Ethanol":
                    CalculateReactants.CalculateReactantsForC2H5OHAndO2(ethanolReactionCO2Produced, ethanolReactionH2OProduced, originalEthanol, originalOxygen, out int expectedEthanol, out int expectedEthanolOxygen);

                    productOneInput = productOne.Value;
                    productTwoInput = productTwo.Value;
                    leftOver1Input = LeftOver1Button.Value;
                    leftOver2Input = LeftOver2Button.Value;

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(ethanolReactionCO2Produced, ethanolReactionH2OProduced,ethanolReactionRemainingEthanol, ethanolReactionRemainingOxygen, productOneInput, productTwoInput, leftOver1Input, leftOver2Input);

                    break;
                case "Iron (II) Oxide and Sodium":
                    ironSodiumReactionSodiumOxideProduced = ironSodiumReactionResult.Item1;
                    ironSodiumReactionIronProduced = ironSodiumReactionResult.Item2;

                    ironSodiumReactionRemainingIronII = originalIronIIOxide;
                    ironSodiumReactionRemainingSodium = originalSodium;
                    CalculateReactants.CalculateReactantsForFeOAndNa(ironSodiumReactionSodiumOxideProduced, ironSodiumReactionIronProduced, originalIronIIOxide, originalSodium, out int IronIIOxide, out int expectedSodium);
                    

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(ironSodiumReactionSodiumOxideProduced, ironSodiumReactionIronProduced, ironSodiumReactionRemainingIronII, ironSodiumReactionRemainingSodium, productOneInput, productTwoInput, leftOver1Input, leftOver2Input);

                    break;
            }
        }
        //
        //Method to clear stack panels of Geometry and TextBlock values
        //
        //Method to Show Images as Answer for number of reactants

        //Event Handler for the next button
        private void NextChallengeButton_Click(object sender, RoutedEventArgs e)
        {
            imageStackPanel1.Children.Clear();
            imageStackPanel2.Children.Clear();
            productsLeftOversGeometryPanel.Children.Clear();
            productsLeftOversGeometryLabels.Children.Clear();
            this.productOnePanel.Children.Clear();
            this.productTwoPanel.Children.Clear();

            this.leftOverOnePanel.Children.Clear();
            this.leftOverTwoPanel.Children.Clear();

            productOne.Value = 0;
            productTwo.Value = 0;
            LeftOver1Button.Value = 0;
            LeftOver2Button.Value = 0;

            currentChallengeNumber++;
            ReactionChallenges();
            attempts = 0;
            Next.Visibility = Visibility.Collapsed;
            Check.Visibility = Visibility.Visible;
        }
        //Event Handler for the Try button
        private void TryAgainChallengeButton_Click(object sender, RoutedEventArgs e)
        {
            smileyFace.Visibility = Visibility.Collapsed;
            sadFace.Visibility = Visibility.Collapsed;
            Check.Visibility = Visibility.Visible;
            TryAgain.Visibility = Visibility.Collapsed;
        }
        //Event Handler for View Answer
        private void ViewAnswerButton_Click(object sender, RoutedEventArgs e)
        {
            ViewAnswer.Visibility = Visibility.Collapsed;
            Check.Visibility = Visibility.Collapsed;
            Next.Visibility = Visibility.Visible;
            sadFace.Visibility = Visibility.Collapsed;


            // Set reactants, products, and leftovers details: TextBlock labels, geometry/images
            switch (selectedReactionName[currentChallengeNumber])
            {
                case "Combust Methane":
                    //For loop to add expected reactants geometry to stackpanel
                    for (int i = 0; i < methaneReactionCO2Produced; i++)
                    {
                        AddImageToStackPanel(productOnePanel, this.productOneGeometry);

                    }
                    for (int i = 0; i < methaneReactionH2OProduced; i++)
                    {
                        AddImageToStackPanel(productTwoPanel, this.productTwoGeometry);

                    }
                    for (int i = 0; i < waterReactionRemainingHydrogen; i++)
                    {
                        AddImageToStackPanel(leftOverOnePanel, this.reactant1Geometry);

                    }
                    for (int i = 0; i < waterReactionRemainingOxygen; i++)
                    {
                        AddImageToStackPanel(leftOverTwoPanel, this.reactant2Geometry);

                    }
                    productOne.Value = methaneReactionCO2Produced;
                    productTwo.Value = methaneReactionH2OProduced;
                    LeftOver1Button.Value = methaneReactionRemainingMethane;
                    LeftOver2Button.Value = methaneReactionRemainingOxygen;
                    break;
                case "Thermite Reaction":
                    
                    //For loop to add expected reactants geometry to stackpanel
                    for (int i = 0; i < thermiteReactionAluminumOxideProduced; i++)
                    {
                        AddImageToStackPanel(productOnePanel, this.productOneGeometry);

                    }
                    for (int i = 0; i < thermiteReactionIronProduced; i++)
                    {
                        AddImageToStackPanel(productTwoPanel, this.productTwoGeometry);

                    }
                    for (int i = 0; i < thermiteReactionRemainingAluminum; i++)
                    {
                        AddImageToStackPanel(leftOverOnePanel, this.reactant1Geometry);

                    }
                    for (int i = 0; i < thermiteReactionRemainingIronOxide; i++)
                    {
                        AddImageToStackPanel(leftOverTwoPanel, this.reactant2Geometry);

                    }
                    productOne.Value = thermiteReactionAluminumOxideProduced;
                    productTwo.Value = thermiteReactionIronProduced;
                    LeftOver1Button.Value = thermiteReactionRemainingAluminum;
                    LeftOver2Button.Value = thermiteReactionRemainingIronOxide;
                    break;
                case "Combust Ethane":
                    for (int i = 0; i < ethaneReactionCO2Produced; i++)
                    {
                        AddImageToStackPanel(productOnePanel, this.productOneGeometry);

                    }
                    for (int i = 0; i < ethaneReactionH2OProduced; i++)
                    {
                        AddImageToStackPanel(productTwoPanel, this.productTwoGeometry);

                    }
                    for (int i = 0; i < ethaneReactionRemainingEthane; i++)
                    {
                        AddImageToStackPanel(leftOverOnePanel, this.reactant1Geometry);

                    }
                    for (int i = 0; i < ethaneReactionRemainingOxygen; i++)
                    {
                        AddImageToStackPanel(leftOverTwoPanel, this.reactant2Geometry);

                    }
                    productOne.Value = ethaneReactionCO2Produced;
                    productTwo.Value = ethaneReactionH2OProduced;
                    LeftOver1Button.Value = ethaneReactionRemainingEthane;
                    LeftOver2Button.Value = ethaneReactionRemainingOxygen;
                    break;
                case "Combust Ethanol":
                    for (int i = 0; i < ethanolReactionCO2Produced; i++)
                    {
                        AddImageToStackPanel(productOnePanel, this.productOneGeometry);

                    }
                    for (int i = 0; i < ethanolReactionH2OProduced; i++)
                    {
                        AddImageToStackPanel(productTwoPanel, this.productTwoGeometry);

                    }
                    for (int i = 0; i < ethanolReactionRemainingEthanol; i++)
                    {
                        AddImageToStackPanel(leftOverOnePanel, this.reactant1Geometry);

                    }
                    for (int i = 0; i < ethanolReactionRemainingOxygen; i++)
                    {
                        AddImageToStackPanel(leftOverTwoPanel, this.reactant2Geometry);

                    }

                    productOne.Value = ethanolReactionCO2Produced;
                    productTwo.Value = ethanolReactionH2OProduced;
                    LeftOver1Button.Value = ethanolReactionRemainingEthanol;
                    LeftOver2Button.Value = ethanolReactionRemainingOxygen;
                    break;
                case "Iron (II) Oxide and Sodium":
                    for (int i = 0; i < ironSodiumReactionSodiumOxideProduced; i++)
                    {
                        AddImageToStackPanel(productOnePanel, this.productOneGeometry);

                    }
                    for (int i = 0; i < ironSodiumReactionIronProduced; i++)
                    {
                        AddImageToStackPanel(productTwoPanel, this.productTwoGeometry);

                    }
                    for (int i = 0; i < ironSodiumReactionRemainingIronII; i++)
                    {
                        AddImageToStackPanel(leftOverOnePanel, this.reactant1Geometry);

                    }
                    for (int i = 0; i < ironSodiumReactionRemainingSodium; i++)
                    {
                        AddImageToStackPanel(leftOverTwoPanel, this.reactant2Geometry);

                    }

                    productOne.Value = ironSodiumReactionSodiumOxideProduced;
                    productTwo.Value = ironSodiumReactionIronProduced;
                    LeftOver1Button.Value = ironSodiumReactionRemainingIronII;
                    LeftOver2Button.Value = ironSodiumReactionRemainingSodium;
                    break;
            }
        }
        //A method to Check if the user's input react to produced amount of desired products and initial leftovers
        //This method applies to reactions that produce One product
        private void CheckTwoProducts(int prodOneProduced, int prodTwoProduced, int leftOver1Produced, int leftOver2Produced, int firstProductInput, int secondProductInput, int leftOver1Input, int leftover2Input)
        {
            if (attempts == 0)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == firstProductInput &&
                        prodTwoProduced == secondProductInput &&
                        leftOver1Produced == leftOver1Input &&
                        leftOver2Produced == leftOver2Input)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 2;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    TryAgain.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
            else if (attempts == 1)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == firstProductInput &&
                        prodTwoProduced == secondProductInput &&
                        leftOver1Produced == leftOver1Input &&
                        leftOver2Produced == leftOver2Input)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 1;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    TryAgain.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
            else if (attempts == 2)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == firstProductInput &&
                        prodTwoProduced == secondProductInput &&
                        leftOver1Produced == leftOver1Input &&
                        leftOver2Produced == leftOver2Input)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 1;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    ViewAnswer.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
        }
        private void ShowConfettiEffect()
        {
            Random random = new Random();
            for (int i = 0; i < 30; i++)
            {
                Ellipse confetti = new Ellipse
                {
                    Width = 40,
                    Height = 40,
                    Fill = new SolidColorBrush(Color.FromArgb(
                        200,
                        (byte)random.Next(256),
                        (byte)random.Next(256),
                        (byte)random.Next(256)))
                };

                Canvas.SetLeft(confetti, random.Next((int)ConfettiCanvas.ActualWidth));
                Canvas.SetTop(confetti, -10);
                ConfettiCanvas.Children.Add(confetti);

                DoubleAnimation fallAnimation = new DoubleAnimation
                {
                    From = -10,
                    To = ConfettiCanvas.ActualHeight + 10,
                    Duration = TimeSpan.FromSeconds(2 + random.NextDouble() * 3),
                    EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn }
                };

                Storyboard.SetTarget(fallAnimation, confetti);
                Storyboard.SetTargetProperty(fallAnimation, "(Canvas.Top)");

                Storyboard storyboard = new Storyboard();
                storyboard.Children.Add(fallAnimation);
                storyboard.Begin();
            }
        }
    }
}