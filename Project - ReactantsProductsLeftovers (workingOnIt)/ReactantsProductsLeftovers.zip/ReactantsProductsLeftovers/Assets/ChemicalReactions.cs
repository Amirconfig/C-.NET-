﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReactantsProductsLeftovers.Assets
{
    public class ChemicalReactions
    {
        //Method to simulate Water Reaction
        public static int ReactH2AndO2(ref int hydrogenMolecules, ref int oxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction 2H2 + O2 -> 2H2O
            const int hydrogenStoich = 2;
            const int oxygenStoich = 1;
            const int waterStoich = 2;

            // Calculate the maximum number of water molecules that can be produced
            int maxWaterByHydrogen = hydrogenMolecules / hydrogenStoich;
            int maxWaterByOxygen = oxygenMolecules / oxygenStoich;
            int maxWaterMolecules = Math.Min(maxWaterByHydrogen, maxWaterByOxygen) * waterStoich;

            // Update the remaining hydrogen and oxygen molecules
            hydrogenMolecules -= (maxWaterMolecules / waterStoich) * hydrogenStoich;
            oxygenMolecules -= (maxWaterMolecules / waterStoich) * oxygenStoich;

            return maxWaterMolecules;
        }

        //Method to simulate Ammonia Reaction
        public static int ReactN2AndH2(ref int nitrogenMolecules, ref int hydrogenMolecules)
        {
            // Stoichiometric coefficients for the reaction N2 + 3H2 -> 2NH3
            const int nitrogenStoich = 1;
            const int hydrogenStoich = 3;
            const int ammoniaStoich = 2;

            // Calculate the maximum number of ammonia molecules that can be produced
            int maxAmmoniaByNitrogen = nitrogenMolecules / nitrogenStoich;
            int maxAmmoniaByHydrogen = hydrogenMolecules / hydrogenStoich;
            int maxAmmoniaMolecules = Math.Min(maxAmmoniaByNitrogen, maxAmmoniaByHydrogen) * ammoniaStoich;

            // Update the remaining nitrogen and hydrogen molecules
            nitrogenMolecules -= (maxAmmoniaMolecules / ammoniaStoich) * nitrogenStoich;
            hydrogenMolecules -= (maxAmmoniaMolecules / ammoniaStoich) * hydrogenStoich;

            return maxAmmoniaMolecules;
        }

        //Method to simulate Methane Combustion
        public static Tuple<int, int> ReactCH4AndO2(ref int methaneMolecules, ref int oxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction CH4 + 2O2 -> CO2 + 2H2O
            const int methaneStoich = 1;
            const int oxygenStoich = 2;
            const int carbonDioxideStoich = 1;
            const int waterStoich = 2;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByMethane = methaneMolecules / methaneStoich;
            int maxReactionsByOxygen = oxygenMolecules / oxygenStoich;
            int maxReactions = Math.Min(maxReactionsByMethane, maxReactionsByOxygen);

            // Calculate the number of products
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;
            int waterProduced = maxReactions * waterStoich;

            // Update the remaining methane and oxygen molecules
            methaneMolecules -= maxReactions * methaneStoich;
            oxygenMolecules -= maxReactions * oxygenStoich;

            return Tuple.Create(carbonDioxideProduced, waterProduced);
        }

        //Method to simulate Thermite Reaction
        public static Tuple<int, int> ReactAlAndFe2O3(ref int aluminumMolecules, ref int ironOxideMolecules)
        {
            // Stoichiometric coefficients for the reaction 2Al + Fe2O3 -> 2Fe + Al2O3
            const int aluminumStoich = 2;
            const int ironOxideStoich = 1;
            const int ironStoich = 2;
            const int aluminumOxideStoich = 1;

            // Calculate the maximum number of iron and aluminum oxide molecules that can be produced
            int maxReactionsByAluminum = aluminumMolecules / aluminumStoich;
            int maxReactionsByIronOxide = ironOxideMolecules / ironOxideStoich;
            int maxReactions = Math.Min(maxReactionsByAluminum, maxReactionsByIronOxide);

            // Calculate the number of products
            int ironProduced = maxReactions * ironStoich;
            int aluminumOxideProduced = maxReactions * aluminumOxideStoich;

            // Update the remaining aluminum and iron(III) oxide
            aluminumMolecules -= maxReactions * aluminumStoich;
            ironOxideMolecules -= maxReactions * ironOxideStoich;

            return Tuple.Create(ironProduced, aluminumOxideProduced);
        }

        //Method to simulate Combustion of Ethane
        public static Tuple<int, int> ReactC2H6AndO2(ref int ethaneMolecules, ref int oxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction 2C2H6 + 7O2 -> 4CO2 + 6H2O
            const int ethaneStoich = 2;
            const int oxygenStoich = 7;
            const int carbonDioxideStoich = 4;
            const int waterStoich = 6;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByEthane = ethaneMolecules / ethaneStoich;
            int maxReactionsByOxygen = oxygenMolecules / oxygenStoich;
            int maxReactions = Math.Min(maxReactionsByEthane, maxReactionsByOxygen);

            // Calculate the number of products
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;
            int waterProduced = maxReactions * waterStoich;

            // Update the remaining ethane and oxygen molecules
            ethaneMolecules -= maxReactions * ethaneStoich;
            oxygenMolecules -= maxReactions * oxygenStoich;

            return Tuple.Create(carbonDioxideProduced, waterProduced);
        }

        //Method to simulate Combustion of Ethanol
        public static Tuple<int, int> ReactC2H5OHAndO2(ref int ethanolMolecules, ref int oxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction C2H5OH + 3O2 -> 2CO2 + 3H2O
            const int ethanolStoich = 1;
            const int oxygenStoich = 3;
            const int carbonDioxideStoich = 2;
            const int waterStoich = 3;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByEthanol = ethanolMolecules / ethanolStoich;
            int maxReactionsByOxygen = oxygenMolecules / oxygenStoich;
            int maxReactions = Math.Min(maxReactionsByEthanol, maxReactionsByOxygen);

            // Calculate the number of products
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;
            int waterProduced = maxReactions * waterStoich;

            // Update the remaining ethanol and oxygen molecules
            ethanolMolecules -= maxReactions * ethanolStoich;
            oxygenMolecules -= maxReactions * oxygenStoich;

            return Tuple.Create(carbonDioxideProduced, waterProduced);
        }

        //Method to simulate the displacement of Iron(II) oxide with Sodium
        public static Tuple<int, int> ReactFeOAndNa(ref int ironOxideMolecules, ref int sodiumMolecules)
        {
            // Stoichiometric coefficients for the reaction FeO + 2Na -> Na2O + Fe
            const int ironOxideStoich = 1;
            const int sodiumStoich = 2;
            const int sodiumOxideStoich = 1;
            const int ironStoich = 1;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByIronOxide = ironOxideMolecules / ironOxideStoich;
            int maxReactionsBySodium = sodiumMolecules / sodiumStoich;
            int maxReactions = Math.Min(maxReactionsByIronOxide, maxReactionsBySodium);

            // Calculate the number of products
            int sodiumOxideProduced = maxReactions * sodiumOxideStoich;
            int ironProduced = maxReactions * ironStoich;

            // Update the remaining iron(II) oxide and sodium atoms
            ironOxideMolecules -= maxReactions * ironOxideStoich;
            sodiumMolecules -= maxReactions * sodiumStoich;

            return Tuple.Create(sodiumOxideProduced, ironProduced);
        }

        //Method to Simulate Combustion of Ethene
        public static Tuple<int, int> ReactC2H4AndO2(ref int etheneMolecules, ref int oxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction C2H4 + 3O2 -> 2CO2 + 2H2O
            const int etheneStoich = 1;
            const int oxygenStoich = 3;
            const int carbonDioxideStoich = 2;
            const int waterStoich = 2;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByEthene = etheneMolecules / etheneStoich;
            int maxReactionsByOxygen = oxygenMolecules / oxygenStoich;
            int maxReactions = Math.Min(maxReactionsByEthene, maxReactionsByOxygen);

            // Calculate the number of products
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;
            int waterProduced = maxReactions * waterStoich;

            // Update the remaining ethene and oxygen molecules
            etheneMolecules -= maxReactions * etheneStoich;
            oxygenMolecules -= maxReactions * oxygenStoich;

            return Tuple.Create(carbonDioxideProduced, waterProduced);
        }
        //Method to Simulate Fermentation of Glucose
        public static Tuple<int, int> ReactC6H12O6(ref int glucoseMolecules)
        {
            // Stoichiometric coefficients for the reaction C6H12O6 -> 2C2H5OH + 2CO2
            const int glucoseStoich = 1;
            const int ethanolStoich = 2;
            const int carbonDioxideStoich = 2;

            // Calculate the maximum number of products that can be produced
            int maxReactions = glucoseMolecules / glucoseStoich;

            // Calculate the number of products
            int ethanolProduced = maxReactions * ethanolStoich;
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;

            // Update the remaining glucose molecules
            glucoseMolecules -= maxReactions * glucoseStoich;

            return Tuple.Create(ethanolProduced, carbonDioxideProduced);
        }

        //Method to simulate Iron (III) Oxide reduction
        public static Tuple<int, int> ReactFe2O3AndC(ref int ironOxideMolecules, ref int carbonAtoms)
        {
            // Stoichiometric coefficients for the reaction Fe2O3 + 3C -> 2Fe + 3CO2
            const int ironOxideStoich = 1;
            const int carbonStoich = 3;
            const int ironStoich = 2;
            const int carbonDioxideStoich = 3;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByIronOxide = ironOxideMolecules / ironOxideStoich;
            int maxReactionsByCarbon = carbonAtoms / carbonStoich;
            int maxReactions = Math.Min(maxReactionsByIronOxide, maxReactionsByCarbon);
            // Calculate the number of products
            int ironProduced = maxReactions * ironStoich;
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;

            // Update the remaining iron(III) oxide and carbon atoms
            ironOxideMolecules -= maxReactions * ironOxideStoich;
            carbonAtoms -= maxReactions * carbonStoich;

            return Tuple.Create(ironProduced, carbonDioxideProduced);
        }
    }
}
