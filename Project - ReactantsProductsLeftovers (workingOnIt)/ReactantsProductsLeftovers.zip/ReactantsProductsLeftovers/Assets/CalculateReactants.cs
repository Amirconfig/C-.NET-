﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReactantsProductsLeftovers.Assets
{
    public static class CalculateReactants
    {
        //Method to calculate number of Hydrogen and Oxygen given amount of products and leftover
        public static void CalculateReactantsForH2AndO2(int waterMolecules, int remainingHydrogenMolecules, int remainingOxygenMolecules, out int initialHydrogenMolecules, out int initialOxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction 2H2 + O2 -> 2H2O
            const int hydrogenStoich = 2;
            const int oxygenStoich = 1;
            const int waterStoich = 2;

            // Calculate the number of hydrogen and oxygen molecules used to produce the given water molecules
            int hydrogenUsed = (waterMolecules / waterStoich) * hydrogenStoich;
            int oxygenUsed = (waterMolecules / waterStoich) * oxygenStoich;

            // Calculate the initial number of hydrogen and oxygen molecules
            initialHydrogenMolecules = hydrogenUsed + remainingHydrogenMolecules;
            initialOxygenMolecules = oxygenUsed + remainingOxygenMolecules;
        }

        // Method to calculate the initial number of reactants given the number of products and leftovers for ammonia production
        public static void CalculateReactantsForN2AndH2(int ammoniaMolecules, int remainingNitrogenMolecules, int remainingHydrogenMolecules, out int initialNitrogenMolecules, out int initialHydrogenMolecules)
        {
            // Stoichiometric coefficients for the reaction N2 + 3H2 -> 2NH3
            const int nitrogenStoich = 1;
            const int hydrogenStoich = 3;
            const int ammoniaStoich = 2;

            // Calculate the number of nitrogen and hydrogen molecules used to produce the given ammonia molecules
            int nitrogenUsed = (ammoniaMolecules / ammoniaStoich) * nitrogenStoich;
            int hydrogenUsed = (ammoniaMolecules / ammoniaStoich) * hydrogenStoich;

            // Calculate the initial number of nitrogen and hydrogen molecules
            initialNitrogenMolecules = nitrogenUsed + remainingNitrogenMolecules;
            initialHydrogenMolecules = hydrogenUsed + remainingHydrogenMolecules;
        }
        // Method to calculate the initial number of reactants given the number of products and leftovers for methane combustion
        public static void CalculateReactantsForCH4AndO2(int carbonDioxideMolecules, int waterMolecules, int remainingMethaneMolecules, int remainingOxygenMolecules, out int initialMethaneMolecules, out int initialOxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction CH4 + 2O2 -> CO2 + 2H2O
            const int methaneStoich = 1;
            const int oxygenStoich = 2;
            const int carbonDioxideStoich = 1;
            const int waterStoich = 2;

            // Calculate the number of methane and oxygen molecules used to produce the given carbon dioxide and water molecules
            int methaneUsed = (carbonDioxideMolecules / carbonDioxideStoich) * methaneStoich;
            int oxygenUsed = (carbonDioxideMolecules / carbonDioxideStoich) * oxygenStoich;

            // Calculate the initial number of methane and oxygen molecules
            initialMethaneMolecules = methaneUsed + remainingMethaneMolecules;
            initialOxygenMolecules = oxygenUsed + remainingOxygenMolecules;
        }
        public static void CalculateReactantsForAlAndFe2O3(int aluminumOxideProduced, int ironProduced, int remainingAluminum, int remainingIronOxide, out int initialAluminum, out int initialIronOxide)
        {
            const int aluminumStoich = 2;
            const int ironOxideStoich = 1;
            const int ironStoich = 2;
            const int aluminumOxideStoich = 1;

            int aluminumUsed = (ironProduced / ironStoich) * aluminumStoich;
            int ironOxideUsed = (ironProduced / ironStoich) * ironOxideStoich;

            initialAluminum = aluminumUsed + remainingAluminum;
            initialIronOxide = ironOxideUsed + remainingIronOxide;
        }
        // Method to calculate the initial number of reactants given the number of products and leftovers for ethane combustion
        public static void CalculateReactantsForC2H6AndO2(int carbonDioxideMolecules, int waterMolecules, int remainingEthaneMolecules, int remainingOxygenMolecules, out int initialEthaneMolecules, out int initialOxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction C2H6 + 3.5O2 -> 2CO2 + 3H2O
            const int ethaneStoich = 1;
            const int oxygenStoich = 7;
            const int carbonDioxideStoich = 2;
            const int waterStoich = 3;

            // Calculate the number of ethane and oxygen molecules used to produce the given carbon dioxide and water molecules
            int ethaneUsed = (carbonDioxideMolecules / carbonDioxideStoich) * ethaneStoich;
            int oxygenUsed = (carbonDioxideMolecules / carbonDioxideStoich) * oxygenStoich;

            // Calculate the initial number of ethane and oxygen molecules
            initialEthaneMolecules = ethaneUsed + remainingEthaneMolecules;
            initialOxygenMolecules = oxygenUsed + remainingOxygenMolecules;
        }
        public static void CalculateReactantsForC2H5OHAndO2(int carbonDioxideProduced, int waterProduced, int remainingEthanol, int remainingOxygen, out int initialEthanol, out int initialOxygen)
        {
            const int ethanolStoich = 1;
            const int oxygenStoich = 3;
            const int carbonDioxideStoich = 2;
            const int waterStoich = 3;

            int ethanolUsed = (carbonDioxideProduced / carbonDioxideStoich) * ethanolStoich;
            int oxygenUsed = (carbonDioxideProduced / carbonDioxideStoich) * oxygenStoich;

            initialEthanol = ethanolUsed + remainingEthanol;
            initialOxygen = oxygenUsed + remainingOxygen;
        }
        public static void CalculateReactantsForFeOAndNa(int sodiumOxideProduced, int ironProduced, int remainingIronOxide, int remainingSodium, out int initialIronOxide, out int initialSodium)
        {
            const int ironOxideStoich = 1;
            const int sodiumStoich = 2;
            const int sodiumOxideStoich = 1;
            const int ironStoich = 1;

            int ironOxideUsed = (sodiumOxideProduced / sodiumOxideStoich) * ironOxideStoich;
            int sodiumUsed = (sodiumOxideProduced / sodiumOxideStoich) * sodiumStoich;

            initialIronOxide = ironOxideUsed + remainingIronOxide;
            initialSodium = sodiumUsed + remainingSodium;
        }
        // Method to calculate the initial number of reactants given the number of products and leftovers for ethene combustion
        public static void CalculateReactantsForC2H4AndO2(int carbonDioxideMolecules, int waterMolecules, int remainingEtheneMolecules, int remainingOxygenMolecules, out int initialEtheneMolecules, out int initialOxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction C2H4 + 3O2 -> 2CO2 + 2H2O
            const int etheneStoich = 1;
            const int oxygenStoich = 3;
            const int carbonDioxideStoich = 2;
            const int waterStoich = 2;

            // Calculate the number of ethene and oxygen molecules used to produce the given carbon dioxide and water molecules
            int etheneUsed = (carbonDioxideMolecules / carbonDioxideStoich) * etheneStoich;
            int oxygenUsed = (carbonDioxideMolecules / carbonDioxideStoich) * oxygenStoich;

            // Calculate the initial number of ethene and oxygen molecules
            initialEtheneMolecules = etheneUsed + remainingEtheneMolecules;
            initialOxygenMolecules = oxygenUsed + remainingOxygenMolecules;
        }
        // Method to calculate the initial number of reactants given the number of products and leftovers for glucose fermentation
        public static void CalculateReactantsForC6H12O6(int ethanolMolecules, int carbonDioxideMolecules, int remainingGlucoseMolecules, out int initialGlucoseMolecules)
        {
            // Stoichiometric coefficients for the reaction C6H12O6 -> 2C2H5OH + 2CO2
            const int glucoseStoich = 1;
            const int ethanolStoich = 2;
            const int carbonDioxideStoich = 2;

            // Calculate the number of glucose molecules used to produce the given ethanol and carbon dioxide molecules
            int glucoseUsed = (ethanolMolecules / ethanolStoich) * glucoseStoich;

            // Calculate the initial number of glucose molecules
            initialGlucoseMolecules = glucoseUsed + remainingGlucoseMolecules;
        }
        public static void CalculateReactantsForFe2O3AndC(int ironProduced, int carbonMonoxideProduced, int remainingIronOxide, int remainingCarbon, out int initialIronOxide, out int initialCarbon)
        {
            const int ironOxideStoich = 1;
            const int carbonStoich = 3;
            const int ironStoich = 2;
            const int carbonMonoxideStoich = 3;

            int ironOxideUsed = (ironProduced / ironStoich) * ironOxideStoich;
            int carbonUsed = (ironProduced / ironStoich) * carbonStoich;

            initialIronOxide = ironOxideUsed + remainingIronOxide;
            initialCarbon = carbonUsed + remainingCarbon;
        }
    }
}
