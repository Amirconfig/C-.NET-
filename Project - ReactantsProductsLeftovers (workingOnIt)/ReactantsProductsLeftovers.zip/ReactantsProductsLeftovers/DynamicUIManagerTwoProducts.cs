﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Text;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml;
using Windows.UI;

namespace ReactantsProductsLeftovers
{
    //This class is for dynamic generation StackPanels, Borders, TextBlocks, Image controls for reactions that produced two productions.
    //This is helps to ease formatting since we are using single StackPanel to display/Stack Molecular Geometry for products and left overs
    //Some reactions produce one product
    public class DynamicUIManagerTwoProducts
    {
        // Dictionaries to store dynamically generate elements
        private Dictionary<string, StackPanel> dynamicStackPanels = new Dictionary<string, StackPanel>();
        private Dictionary<string, TextBlock> dynamicTextBlocks = new Dictionary<string, TextBlock>();
        private Dictionary<string, Image> dynamicImages = new Dictionary<string, Image>();
        private Dictionary<string, TextBlock> dynamicTextBlocksProductLeftOversGeometryLabels = new Dictionary<string, TextBlock>();


        //METHOD TO CREATE StackPanels Dynamically
        public void CreateBorderAndStackPanelDynamically(StackPanel productLeftOverPanel)
        {
            //Create Borders to add to a stackpanel for products and leftovers
            //Create Border for the Product StackPanel and set properties
            Border productOneBorder = new Border();

            productOneBorder.Name = "productOneBorder";
            productOneBorder.Background = new SolidColorBrush(Colors.White);
            productOneBorder.Padding = new Thickness(5);
            productOneBorder.Height = 400;
            productOneBorder.MinWidth = 80;
            productOneBorder.Margin = new Thickness(20, 0, 0, 0);

            //Add productOneBorder to a StackPanel
            productLeftOverPanel.Children.Add(productOneBorder);

            // Create instance of first product StackPanel and set properties
            StackPanel stackPanelProductOne = new StackPanel();
            stackPanelProductOne.Name = "imageStackPanelProductOne";
            stackPanelProductOne.VerticalAlignment = VerticalAlignment.Bottom;

            //Add stackpanel to border
            productOneBorder.Child = stackPanelProductOne;

            // Store the StackPanel in the dictionary with a name to allow reference in MainPage.xaml.cs
            dynamicStackPanels["imageStackPanelProductOne"] = stackPanelProductOne;

            //Create Border for the Second Product StackPanel and set properties
            Border productTwoBorder = new Border();

            productTwoBorder.Name = "productTwoBorder";
            productTwoBorder.Background = new SolidColorBrush(Colors.White);
            productTwoBorder.Padding = new Thickness(5);
            productTwoBorder.Height = 400;
            productTwoBorder.MinWidth = 80;
            productTwoBorder.Margin = new Thickness(20, 0, 0, 0);

            //Add productTwoBorder to a StackPanel
            productLeftOverPanel.Children.Add(productTwoBorder);

            // Create instance of second StackPanel and set properties
            StackPanel stackPanelProductTwo = new StackPanel();
            stackPanelProductTwo.Name = "imageStackPanelProductTwo";
            stackPanelProductTwo.VerticalAlignment = VerticalAlignment.Bottom;
            
            //Add stackpanel to border
            productTwoBorder.Child = stackPanelProductTwo;

            // Store the StackPanel in the dictionary with a name to allow reference in MainPage.xaml.cs
            dynamicStackPanels["imageStackPanelProductTwo"] = stackPanelProductTwo;


            //Create Border for the First LeftOver and Set Properties
            Border leftOverOneBorder = new Border();

            leftOverOneBorder.Name = "leftOverOneBorder";
            leftOverOneBorder.Background = new SolidColorBrush(Colors.White);
            leftOverOneBorder.Padding = new Thickness(5);
            leftOverOneBorder.Height = 400;
            leftOverOneBorder.MinWidth = 80;
            leftOverOneBorder.Margin = new Thickness(20, 0, 0, 0);

            //Add leftOverOneBorder to StackPanel
            productLeftOverPanel.Children.Add(leftOverOneBorder);

            //Create instance of second StackPanel and set properties
            StackPanel stackPanelTwo = new StackPanel();
            stackPanelTwo.Name = "imageStackPanelLeftOver1";
            stackPanelTwo.VerticalAlignment = VerticalAlignment.Bottom;

            //Add second StackPanel to leftOverOneBorder
            leftOverOneBorder.Child = stackPanelTwo;

            // Store the StackPanel in the dictionary with a name to allow reference in MainPage.xaml.cs
            dynamicStackPanels["imageStackPanelLeftOver1"] = stackPanelTwo;


            //Create Border for the Second LeftOver and set properties
            Border leftOverTwoBorder = new Border();

            leftOverTwoBorder.Name = "leftOverTwoBorder";
            leftOverTwoBorder.Background = new SolidColorBrush(Colors.White);
            leftOverTwoBorder.Padding = new Thickness(5);
            leftOverTwoBorder.Height = 400;
            leftOverTwoBorder.MinWidth = 80;
            leftOverTwoBorder.Margin = new Thickness(20, 0, 20, 0);

            //Add leftOverTwoBorder to StackPanel
            productLeftOverPanel.Children.Add(leftOverTwoBorder);

            //Create instance of third StackPanel and set properties
            StackPanel stackPanelThree = new StackPanel();
            stackPanelThree.Name = "imageStackPanelLeftOver2";
            stackPanelThree.VerticalAlignment = VerticalAlignment.Bottom;

            //Add third StackPanel to leftOverTwoBorder
            leftOverTwoBorder.Child = stackPanelThree;

            // Store the StackPanel in the dictionary with a name to allow reference in MainPage.xaml.cs
            dynamicStackPanels["imageStackPanelLeftOver2"] = stackPanelThree;


        }

        //Method to create TextBlocks for holding number of products and molecules leftovers
        public void CreateTextBlockslDynamically(StackPanel leftOversPanel)
        {
            //CREATE TEXTBLOCKS FOR HOLDING THE Number of molecules for the product and leftovers
            //Create first textblock
            TextBlock textBlockProductOne = new TextBlock();
            textBlockProductOne.Name = "txtBlockProductMolecule";
            textBlockProductOne.Text = "0";
            textBlockProductOne.VerticalAlignment = VerticalAlignment.Center;
            textBlockProductOne.HorizontalAlignment = HorizontalAlignment.Center;
            textBlockProductOne.FontSize = 18;
            textBlockProductOne.FontWeight = FontWeights.Bold;
            textBlockProductOne.Margin = new Thickness(50, 0, 40, 0);

            //Add TextBlock to the leftOversPanel
            leftOversPanel.Children.Add(textBlockProductOne);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicTextBlocks["txtBlockProductMolecule"] = textBlockProductOne;

            //Create first textblock
            TextBlock textBlockProductTwo = new TextBlock();
            textBlockProductTwo.Name = "txtBlockProductTwoMolecule";
            textBlockProductTwo.Text = "0";
            textBlockProductTwo.VerticalAlignment = VerticalAlignment.Center;
            textBlockProductTwo.HorizontalAlignment = HorizontalAlignment.Center;
            textBlockProductTwo.FontSize = 18;
            textBlockProductTwo.FontWeight = FontWeights.Bold;
            textBlockProductTwo.Margin = new Thickness(50, 0, 40, 0);

            //Add TextBlock to the leftOversPanel
            leftOversPanel.Children.Add(textBlockProductTwo);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicTextBlocks["txtBlockProductTwoMolecule"] = textBlockProductTwo;

            //Create second textblock
            TextBlock textBlockTwo = new TextBlock();
            textBlockTwo.Name = "txtBlockLeftOver1Molecule";
            textBlockTwo.Text = "0";
            textBlockTwo.VerticalAlignment = VerticalAlignment.Center;
            textBlockTwo.HorizontalAlignment = HorizontalAlignment.Center;
            textBlockTwo.FontSize = 18;
            textBlockTwo.FontWeight = FontWeights.Bold;
            textBlockTwo.Margin = new Thickness(50, 0, 50, 0);

            //Add TextBlock to the leftOversPanel
            leftOversPanel.Children.Add(textBlockTwo);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicTextBlocks["txtBlockLeftOver1Molecule"] = textBlockTwo;

            //Create Third textblock
            TextBlock textBlockThree = new TextBlock();
            textBlockThree.Name = "txtBlockLeftOver2Molecule";
            textBlockThree.Text = "0";
            textBlockThree.VerticalAlignment = VerticalAlignment.Center;
            textBlockThree.HorizontalAlignment = HorizontalAlignment.Center;
            textBlockThree.FontSize = 18;
            textBlockThree.FontWeight = FontWeights.Bold;
            textBlockThree.Margin = new Thickness(40, 0, 50, 0);

            //Add TextBlock to the leftOversPanel
            leftOversPanel.Children.Add(textBlockThree);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicTextBlocks["txtBlockLeftOver2Molecule"] = textBlockThree;

        }


        //CREATE IMAGE CONTROL for displaying molecular geometry for products and leftovers
        public void CreateImageControlsDynamically(StackPanel productsLeftOversGeometryPanel)
        {
            //First Image Control for Products and assoicated Properties
            Image productsGeometryImageControl = new Image();
            productsGeometryImageControl.Name = "productsImageGeometry";
            productsGeometryImageControl.Width = 30;
            productsGeometryImageControl.Height = 30;
            productsGeometryImageControl.VerticalAlignment = VerticalAlignment.Center;
            productsGeometryImageControl.HorizontalAlignment = HorizontalAlignment.Center;
            productsGeometryImageControl.Margin = new Windows.UI.Xaml.Thickness(40, 0, 40, 0);

            //Add Image to StackPanel
            productsLeftOversGeometryPanel.Children.Add(productsGeometryImageControl);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicImages["productsImageGeometry"] = productsGeometryImageControl;

            //First Image Control for Products and assoicated Properties
            Image products2GeometryImageControl = new Image();
            products2GeometryImageControl.Name = "products2ImageGeometry";
            products2GeometryImageControl.Width = 30;
            products2GeometryImageControl.Height = 30;
            products2GeometryImageControl.VerticalAlignment = VerticalAlignment.Center;
            products2GeometryImageControl.HorizontalAlignment = HorizontalAlignment.Center;
            products2GeometryImageControl.Margin = new Windows.UI.Xaml.Thickness(30, 0, 40, 0);

            //Add Image to StackPanel
            productsLeftOversGeometryPanel.Children.Add(products2GeometryImageControl);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicImages["products2ImageGeometry"] = products2GeometryImageControl;

            //Second Image Control for leftovers and associated Properties
            Image leftOver1ImageControl = new Image();
            leftOver1ImageControl.Name = "leftOver1ImageGeometry";
            leftOver1ImageControl.Width = 30;
            leftOver1ImageControl.Height = 30;
            leftOver1ImageControl.VerticalAlignment = VerticalAlignment.Center;
            leftOver1ImageControl.HorizontalAlignment = HorizontalAlignment.Center;
            leftOver1ImageControl.Margin = new Windows.UI.Xaml.Thickness(30, 0, 40, 0);

            //Add Image to StackPanel
            productsLeftOversGeometryPanel.Children.Add(leftOver1ImageControl);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicImages["leftOver1ImageGeometry"] = leftOver1ImageControl;

            //Second Image Control for leftovers and assoicated Properties
            Image leftOver2ImageControl = new Image();
            leftOver2ImageControl.Name = "leftOver2ImageGeometry";
            leftOver2ImageControl.Width = 30;
            leftOver2ImageControl.Height = 30;
            leftOver2ImageControl.VerticalAlignment = VerticalAlignment.Center;
            leftOver2ImageControl.HorizontalAlignment = HorizontalAlignment.Center;
            leftOver2ImageControl.Margin = new Windows.UI.Xaml.Thickness(30, 0, 40, 0);

            //Add Image to StackPanel
            productsLeftOversGeometryPanel.Children.Add(leftOver2ImageControl);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicImages["leftOver2ImageGeometry"] = leftOver2ImageControl;

        }


        //METHOD TO CREATE TEXTBLOCKS WHICH ARE LABELS FOR PRODUCTS AND LEFTOVERS GEOMETRY
        public void CreateTextBlockLabelsForProductsAndImagesGeometry(StackPanel productsLeftOversGeometryLabels)
        {
            //CREATE TEXTBLOCKS FOR labeling geometry for the product and leftovers
            //Create first textblock
            TextBlock textBlockProduct1Label = new TextBlock();
            textBlockProduct1Label.Name = "product1GeometryLabel";
            textBlockProduct1Label.Text = "0";
            textBlockProduct1Label.VerticalAlignment = VerticalAlignment.Center;
            textBlockProduct1Label.HorizontalAlignment = HorizontalAlignment.Center;
            textBlockProduct1Label.FontSize = 18;
            textBlockProduct1Label.FontWeight = FontWeights.Bold;
            textBlockProduct1Label.Margin = new Thickness(40, 0, 40, 0);

            //Add TextBlock to the leftOversPanel
            productsLeftOversGeometryLabels.Children.Add(textBlockProduct1Label);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicTextBlocksProductLeftOversGeometryLabels["product1GeometryLabel"] = textBlockProduct1Label;

            //Create second textblock
            TextBlock textBlockProduct2Label = new TextBlock();
            textBlockProduct2Label.Name = "product2GeometryLabel";
            textBlockProduct2Label.Text = "0";
            textBlockProduct2Label.VerticalAlignment = VerticalAlignment.Center;
            textBlockProduct2Label.HorizontalAlignment = HorizontalAlignment.Center;
            textBlockProduct2Label.FontSize = 18;
            textBlockProduct2Label.FontWeight = FontWeights.Bold;
            textBlockProduct2Label.Margin = new Thickness(30, 0, 40, 0);

            //Add TextBlock to the leftOversPanel
            productsLeftOversGeometryLabels.Children.Add(textBlockProduct2Label);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicTextBlocksProductLeftOversGeometryLabels["product2GeometryLabel"] = textBlockProduct2Label;

            //Create Third textblock
            TextBlock textBlockLeftOver1Geometry = new TextBlock();
            textBlockLeftOver1Geometry.Name = "leftOver1GeometryLabel";
            textBlockLeftOver1Geometry.Text = "0";
            textBlockLeftOver1Geometry.VerticalAlignment = VerticalAlignment.Center;
            textBlockLeftOver1Geometry.HorizontalAlignment = HorizontalAlignment.Center;
            textBlockLeftOver1Geometry.FontSize = 18;
            textBlockLeftOver1Geometry.FontWeight = FontWeights.Bold;
            textBlockLeftOver1Geometry.Margin = new Thickness(20, 0, 40, 0);

            //Add TextBlock to the leftOversPanel
            productsLeftOversGeometryLabels.Children.Add(textBlockLeftOver1Geometry);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicTextBlocksProductLeftOversGeometryLabels["leftOver1GeometryLabel"] = textBlockLeftOver1Geometry;

            //Create Third textblock
            TextBlock textBlockLeftOver2Geometry = new TextBlock();
            textBlockLeftOver2Geometry.Name = "leftOver2GeometryLabel";
            textBlockLeftOver2Geometry.Text = "0";
            textBlockLeftOver2Geometry.VerticalAlignment = VerticalAlignment.Center;
            textBlockLeftOver2Geometry.HorizontalAlignment = HorizontalAlignment.Center;
            textBlockLeftOver2Geometry.FontSize = 18;
            textBlockLeftOver2Geometry.FontWeight = FontWeights.Bold;
            textBlockLeftOver2Geometry.Margin = new Thickness(30, 0, 40, 0);

            //Add TextBlock to the leftOversPanel
            productsLeftOversGeometryLabels.Children.Add(textBlockLeftOver2Geometry);

            //Store TextBlocks in dictionary with a name to allow reference in MainPage.xamls.cs
            dynamicTextBlocksProductLeftOversGeometryLabels["leftOver2GeometryLabel"] = textBlockLeftOver2Geometry;
        }


        // Method to get a StackPanel by name. This method is used when referencing the dynamically created StackPanels from MainPage.Xaml.cs
        public StackPanel GetStackPanelByName(string name)
        {
            if (dynamicStackPanels.TryGetValue(name, out StackPanel stackPanel))
            {
                return stackPanel;
            }
            else
            {
                throw new KeyNotFoundException($"StackPanel with name {name} not found.");
            }
        }


        // Method to get a TextBlock by name.This method is used when referencing the dynamically created TextBlocks from MainPage.Xaml.cs
        public TextBlock GetTextBlocksByName(string name)
        {
            if (dynamicTextBlocks.TryGetValue(name, out TextBlock textBlock))
            {
                return textBlock;
            }
            else
            {
                throw new KeyNotFoundException($"TextBlock with name {name} not found.");
            }
        }


        // Method to get a Image control by name.This method is used when referencing the dynamically created Image from MainPage.Xaml.cs
        public Image GetImageControlByName(string name)
        {
            if (dynamicImages.TryGetValue(name, out Image imageControl))
            {
                return imageControl;
            }
            else
            {
                throw new KeyNotFoundException($"Image with name {name} not found.");
            }
        }


        // Method to get a TextBlock by name.This method is used when referencing the dynamically created TextBlocks from MainPage.Xaml.cs
        public TextBlock GetProductsLeftOversGeometryLabelsByName(string name)
        {
            if (dynamicTextBlocksProductLeftOversGeometryLabels.TryGetValue(name, out TextBlock productsLeftOversLabels))
            {
                return productsLeftOversLabels;
            }
            else
            {
                throw new KeyNotFoundException($"TextBlock with name {name} not found.");
            }
        }
    }
}
