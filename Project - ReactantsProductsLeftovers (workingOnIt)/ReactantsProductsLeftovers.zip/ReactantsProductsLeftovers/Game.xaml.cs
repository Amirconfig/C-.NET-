﻿using System;
using System.Linq;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Popups;
using System.Threading.Tasks;
using Windows.UI.Xaml.Shapes;
using Windows.UI;
using ReactantsProductsLeftovers.Assets;
using System.Collections.Generic;
using Windows.UI.Xaml.Controls.Primitives;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace ReactantsProductsLeftovers
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Game : Page
    {
        //DynamicUIManager class that generates StackPanels, TextBlock, Image controls FOR REACTANTS WITH ONE PRODUCTS
        private DynamicUIManager dynamicUIManager;

        //DynamicUIManager class that generates StackPanels, TextBlock, Image controls FOR REACTANTS WITH TWO PRODUCTS
        private DynamicUIManagerTwoProducts dynamicUIManagerTwoProducts;

        //Variables for Number of Reactant's Molecules
        private int hydrogenMolecules;
        private int oxygenMolecules;
        private int nitrogenMolecules;
        private int methaneMolecules;
        private int aluminumMolecules;
        private int ironOxideMolecules;
        private int ethaneMolecules;
        private int ethanolMolecules;
        private int sodiumMolecules;
        private int etheneMolecules;
        private int glucoseMolecules;
        private int carbonMolecules;

        //Variables for StackPanels
        private StackPanel productOnePanel, productTwoPanel, leftOverOnePanel, leftOverTwoPanel;

        //Private tuple to hold the reaction results
        private int waterMoleculesProduced;
        private int ammoniaMoleculesProduced;
        private Tuple<int, int> methaneReactionResult;
        private Tuple<int, int> thermiteReactionResult;
        private Tuple<int, int> ethaneReactionResult;
        private Tuple<int, int> ethanolReactionResult;
        private Tuple<int, int> ironSodiumReactionResult;
        private Tuple<int, int> etheneReactionResult;
        private Tuple<int, int> glucoseReactionResult;
        private Tuple<int, int> ironOxideReductionResult;

        // Variables to hold desired leftover amounts
        private int desiredLeftOverMethane;
        private int desiredLeftOverOxygen;
        private int desiredLeftOverHydrogen;
        private int desiredLeftOverNitrogen;
        private int desiredLeftOverAmmonia;
        private int desiredLeftOverAluminum;
        private int desiredLeftOverIronOxide;
        private int desiredLeftOverEthane;
        private int desiredLeftOverEthanol;
        private int desiredLeftOverSodium;
        private int desiredLeftOverEthene;
        private int desiredLeftOverGlucose;
        private int desiredLeftOverCarbon;

        //Variables to hold desired product amounts
        private const int MaxProduct = 8;
        private int desiredCarbonDioxide;
        private int desiredWater;
        private int desiredAmmonia;
        private int desiredIron;
        private int desiredAluminumOxide;
        private int desiredSodiumOxide;
        private int desiredEthanol;

        //
        //


        //Class-level variable to store the path to or for molecular geometry for use
        private string molecularGeometry;
        private string reactant1Geometry;
        private string reactant2Geometry;
        private string productOneGeometry;
        private string productTwoGeometry;

        //Class level variable for a stackPanel. Used to determine the stackpanel to insert molecular geometry
        private StackPanel stackPanel;

        //Class level variable for NumericUpDown button
        private NumericUpDown numericUpDown;

        //Variable to hold the list of reactions
        private List<string> reactionNames;
        private List<string> selectedReactionName;
        private int currentChallengeNumber;
        private int totalScore;
        private int attempts;
        public Game()
        {
            this.InitializeComponent();
            //Set the Question Mark Visible
            questionMark.Visibility = Visibility.Visible;

            //Initialize the list of reactions
            InitializeReactions();

            //Initialize selected reaction
            SelectRandomReaction();

            //Initialize The Method to display 5 Challenges
            ReactionChallenges();

            // Subscribe to ValueChanged events for NumericUpDown controls
            reactant1.ValueChanged += NumericUpDown_ValueChanged;
            reactant2.ValueChanged += NumericUpDown_ValueChanged;

            //Initialize number of challenge attempts
            attempts = 0;
            
        }

        //Method to initialize a list of reactions
        private void InitializeReactions()
        {
            reactionNames = new List<string>
            {
                "Make Water",
                "Combust Methane",
                "Thermite Reaction",
                "Combust Ethane",
                "Combust Ethanol",
                "Iron (II) Oxide and Sodium",
                "Combust Ethene",
                "Fermentation of Glucose",
                "Iron (III) Oxide Reduction"
            };
            totalScore = 0;
        }
        //The method use LINQ to order the questions randomly and then takes the first 5 questions.
        private void SelectRandomReaction()
        {
            Random randomReaction = new Random();
            selectedReactionName = reactionNames.OrderBy(x => randomReaction.Next()).Take(5).ToList();
            currentChallengeNumber = 0;
        }

        //A method to Display the Selected Challenges
        private void ReactionChallenges()
        {
            if (currentChallengeNumber < selectedReactionName.Count)
            {
                //Use random function to randomly generate number of products and leftovers
                Random randomProductLeftOvers = new Random();
                //Display current challenge number
                txtChallengeNumber.Text = $"Challenge {currentChallengeNumber + 1} of {selectedReactionName.Count}";

                // Set reactants, products, and leftovers details: TextBlock labels, geometry/images
                switch (selectedReactionName[currentChallengeNumber])
                {
                    case "Make Water":

                        // Set initial amount of desired products and leftovers
                        this.desiredLeftOverHydrogen = randomProductLeftOvers.Next(1, 9);
                        this.desiredLeftOverOxygen = randomProductLeftOvers.Next(1, 9);

                        this.waterMoleculesProduced = ChemicalReactions.ReactH2AndO2(ref this.desiredLeftOverHydrogen, ref this.desiredLeftOverOxygen);
                        this.desiredWater = this.waterMoleculesProduced;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManager = new DynamicUIManager();
                        this.dynamicUIManager.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManager.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManager.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManager.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);


                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/MakeWater.png"));

                        txtBlockReactant1.Text = "H2";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "H2O";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "H2";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 and products
                        this.reactant1Geometry = "ms-appx:///Assets/H2.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/H2.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));


                        //Molecular Geometry as labels for products and left overs 1 and 2
                        this.dynamicUIManager.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        this.dynamicUIManager.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2.png"));
                        this.dynamicUIManager.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));



                        //Assign the labels with initial products and leftovers
                        dynamicUIManager.GetTextBlocksByName("txtBlockProductMolecule").Text = this.desiredWater.ToString();
                        dynamicUIManager.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.desiredLeftOverHydrogen.ToString();
                        dynamicUIManager.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.desiredLeftOverOxygen.ToString();

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManager.GetStackPanelByName("imageStackPanelProductOne");
                        this.leftOverOnePanel = dynamicUIManager.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManager.GetStackPanelByName("imageStackPanelLeftOver2");

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < this.desiredWater; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        //Add desired leftovers geometry
                        for (int i = 0; i < this.desiredLeftOverHydrogen; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverOxygen; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Make Ammonia":
                        // Set initial amount of desired products and leftOvers N2 + 3H2 -> 2NH3
                        this.desiredLeftOverNitrogen = randomProductLeftOvers.Next(1, 9);
                        this.desiredLeftOverHydrogen = randomProductLeftOvers.Next(1, 9);

                        //Get the reaction results from ReactN2AndH2
                        this.ammoniaMoleculesProduced = ChemicalReactions.ReactN2AndH2(ref this.desiredLeftOverNitrogen, ref this.desiredLeftOverHydrogen);

                        this.desiredAmmonia = this.ammoniaMoleculesProduced;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManager = new DynamicUIManager();
                        this.dynamicUIManager.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManager.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManager.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManager.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);


                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/MakeAmmonia.png"));

                        txtBlockReactant1.Text = "N2";
                        txtBlockReactant2.Text = "H2";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "NH3";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "N2";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "H2";

                        //Molecular Geometry to be added for reactant 1 and 2 and products
                        this.reactant1Geometry = "ms-appx:///Assets/N2.png";
                        this.reactant2Geometry = "ms-appx:///Assets/H2.png";
                        this.productOneGeometry = "ms-appx:///Assets/NH3.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/N2.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/H2.png"));


                        //Molecular Geometry as labels for products and left overs 1 and 2
                        this.dynamicUIManager.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/NH3.png"));
                        this.dynamicUIManager.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/N2.png"));
                        this.dynamicUIManager.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2.png"));



                        //Assign the labels with initial products and leftovers
                        dynamicUIManager.GetTextBlocksByName("txtBlockProductMolecule").Text = this.desiredAmmonia.ToString();
                        dynamicUIManager.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.desiredLeftOverNitrogen.ToString();
                        dynamicUIManager.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.desiredLeftOverHydrogen.ToString();

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManager.GetStackPanelByName("imageStackPanelProductOne");
                        this.leftOverOnePanel = dynamicUIManager.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManager.GetStackPanelByName("imageStackPanelLeftOver2");

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < this.desiredAmmonia; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        //Add desired leftovers geometry
                        for (int i = 0; i < this.desiredLeftOverNitrogen; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverHydrogen; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Combust Methane":
                        // Set initial amount of desired products and leftovers - CH4 + 2O2 -> CO2 + 2H2O
                        this.desiredLeftOverMethane = randomProductLeftOvers.Next(1, 9);
                        this.desiredLeftOverOxygen = randomProductLeftOvers.Next(1, 9);

                        // Get the reaction results from ReactCH4AndO2
                        this.methaneReactionResult = ChemicalReactions.ReactCH4AndO2(ref this.desiredLeftOverMethane, ref this.desiredLeftOverOxygen);

                        this.desiredCarbonDioxide = this.methaneReactionResult.Item1;
                        this.desiredWater = this.methaneReactionResult.Item2;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);


                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustMethane.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "CH4";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "CH4";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/H2.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/H20.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));


                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        //Assign the labels with initial products and leftovers
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.desiredCarbonDioxide.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.desiredWater.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.desiredLeftOverMethane.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.desiredLeftOverOxygen.ToString();

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < this.desiredCarbonDioxide; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < this.desiredWater; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverMethane; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverOxygen; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Thermite Reaction":
                        // Set initial amount of desired products and leftovers - 2Al + Fe2O3 -> Al2O3 + 2Fe
                        this.desiredLeftOverAluminum = randomProductLeftOvers.Next(1, 9);
                        this.desiredLeftOverIronOxide = randomProductLeftOvers.Next(1, 9);

                        //Call to a method simulating Thermite Reaction
                        this.thermiteReactionResult = ChemicalReactions.ReactAlAndFe2O3(ref this.desiredLeftOverAluminum, ref this.desiredLeftOverIronOxide);

                        this.desiredIron = this.thermiteReactionResult.Item1;
                        this.desiredAluminumOxide = this.thermiteReactionResult.Item2;


                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);


                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/ThermiteReaction.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "Al";
                        txtBlockReactant2.Text = "Fe2O3";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "Al2O3";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "Fe";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "Al";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "Fe2O3";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/AL.png";
                        this.reactant2Geometry = "ms-appx:///Assets/FE2O3.png";
                        this.productOneGeometry = "ms-appx:///Assets/AL2O3.png";
                        this.productTwoGeometry = "ms-appx:///Assets/FE.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/AL.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/FE2O3.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/AL2O3.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FE.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/AL.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FE2O3.png"));

                        //Assign the labels with initial products and leftovers
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.desiredAluminumOxide.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.desiredIron.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.desiredLeftOverAluminum.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.desiredLeftOverIronOxide.ToString();

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < this.desiredAluminumOxide; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < this.desiredIron; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        //Desired Leftovers
                        for (int i = 0; i < this.desiredLeftOverAluminum; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverIronOxide; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Combust Ethane":
                        // Set initial amount of desired products and leftovers - 2C2H6 + 7O2 -> 4CO2 + 6H2O
                        this.desiredLeftOverEthane = randomProductLeftOvers.Next(1, 9);
                        this.desiredLeftOverOxygen = randomProductLeftOvers.Next(1, 9);

                        //Call to a method simulating Ethane Combustion
                        this.ethaneReactionResult = ChemicalReactions.ReactC2H6AndO2(ref this.desiredLeftOverEthane, ref this.desiredLeftOverOxygen);

                        //Desired products
                        this.desiredCarbonDioxide = this.ethaneReactionResult.Item1;
                        this.desiredWater = this.ethaneReactionResult.Item2;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustEthane.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "C2H6";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "C2H6";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/C2H6.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H6.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H6.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        //Assign the labels with initial products and leftovers
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.desiredCarbonDioxide.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.desiredWater.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.desiredLeftOverEthane.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.desiredLeftOverOxygen.ToString();

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < this.desiredCarbonDioxide; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < this.desiredWater; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverEthane; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverOxygen; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Combust Ethanol":
                        //Set initial amount of leftovers - C2H5OH + 3O2 -> 2CO2 + 3H2O
                        this.desiredLeftOverEthanol = randomProductLeftOvers.Next(1, 9);
                        this.desiredLeftOverOxygen = randomProductLeftOvers.Next(1, 9);

                        //Call to a method simulating Ethanol Combustion
                        this.ethaneReactionResult = ChemicalReactions.ReactC2H5OHAndO2(ref this.desiredLeftOverEthanol, ref this.desiredLeftOverOxygen);

                        //Desired products
                        this.desiredCarbonDioxide = this.ethaneReactionResult.Item1;
                        this.desiredWater = this.ethaneReactionResult.Item2;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustEthanol.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "C2H5OH";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "C2H5OH";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/C2H5OH.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H5OH.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));


                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H5OH.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        //Assign the labels with initial products and leftovers
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.desiredCarbonDioxide.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.desiredWater.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.desiredLeftOverEthanol.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.desiredLeftOverOxygen.ToString();

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < this.desiredCarbonDioxide; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < this.desiredWater; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverEthanol; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverOxygen; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Iron (II) Oxide and Sodium":
                        // Set initial amount of desired products and leftovers - FeO + 2Na -> Na2O + Fe
                        this.desiredLeftOverIronOxide = randomProductLeftOvers.Next(1, 9);
                        this.desiredLeftOverSodium = randomProductLeftOvers.Next(1, 9);

                        //Call to a method simulating Reaction of Iron II Oxide and Sodium
                        this.ironSodiumReactionResult = ChemicalReactions.ReactFeOAndNa(ref this.desiredLeftOverIronOxide, ref this.desiredLeftOverSodium);

                        //Desired products
                        this.desiredSodiumOxide = this.ironSodiumReactionResult.Item1;
                        this.desiredIron = this.ironSodiumReactionResult.Item2;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/IronIIOxideAndSodium.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "FeO";
                        txtBlockReactant2.Text = "Na";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "Na2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "Fe";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "FeO";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "Na";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/FeO.png";
                        this.reactant2Geometry = "ms-appx:///Assets/Na.png";
                        this.productOneGeometry = "ms-appx:///Assets/Na2O.png";
                        this.productTwoGeometry = "ms-appx:///Assets/Fe.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/FeO.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/Na.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/Na2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/Fe.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FeO.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/Na.png"));

                        //Assign the labels with initial products and leftovers
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.desiredSodiumOxide.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.desiredIron.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.desiredLeftOverIronOxide.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.desiredLeftOverSodium.ToString();

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < this.desiredSodiumOxide; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < this.desiredIron; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        //LeftOvers
                        for (int i = 0; i < this.desiredLeftOverIronOxide; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverSodium; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Combust Ethene":
                        // Set initial amount of desired products and leftovers
                        this.desiredLeftOverEthene = randomProductLeftOvers.Next(1, 9);
                        this.desiredLeftOverOxygen = randomProductLeftOvers.Next(1, 9);

                        //Call to a method simulating Ethene Combustion
                        this.etheneReactionResult = ChemicalReactions.ReactC2H4AndO2(ref this.desiredLeftOverEthene, ref this.desiredLeftOverOxygen);

                        //Desired products
                        this.desiredCarbonDioxide = this.etheneReactionResult.Item1;
                        this.desiredWater = this.etheneReactionResult.Item1;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustEthene.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "C2H4";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "C2H4";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/C2H4.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2 in before Reaction section
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H4.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H4.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));
                        //Assign the labels with initial products and leftovers
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.desiredCarbonDioxide.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.desiredWater.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.desiredLeftOverEthene.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.desiredLeftOverOxygen.ToString();

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < this.desiredCarbonDioxide; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < this.desiredWater; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        //LeftOvers
                        for (int i = 0; i < this.desiredLeftOverEthene; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverOxygen; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                    case "Fermentation of Glucose":
                        // Set initial amount of desired products and leftovers
                        this.desiredLeftOverGlucose = randomProductLeftOvers.Next(1, 9);

                        //Call to a method simulating Glucose Fermentation
                        this.glucoseReactionResult = ChemicalReactions.ReactC6H12O6(ref this.desiredLeftOverGlucose);

                        //Desired Products
                        this.desiredEthanol = this.glucoseReactionResult.Item1;
                        this.desiredCarbonDioxide = this.glucoseReactionResult.Item2;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/FermentationOfGlucose.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "C6H12O6";
                        txtBlockReactant2.Text = "";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "C2H5OH";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "C6H12O6";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/C6H12O6.png";
                        this.reactant2Geometry = "ms-appx:///Assets/NoReactant.png";
                        this.productOneGeometry = "ms-appx:///Assets/C2H5OH.png";
                        this.productTwoGeometry = "ms-appx:///Assets/CO2.png";

                        //Molecular Geometry as labels for reactant 1 and 2 in before Reaction section
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C6H12O6.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/NoReactant.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H5OH.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C6H12O6.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/NoReactant.png"));

                        //Assign the labels with initial products and leftovers
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.desiredEthanol.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.desiredCarbonDioxide.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.desiredLeftOverGlucose.ToString();
                        //dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.desiredLeftOverOxygen.ToString();

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < this.desiredEthanol; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < this.desiredCarbonDioxide; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        //LeftOvers
                        for (int i = 0; i < this.desiredLeftOverGlucose; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }

                        break;
                    case "Iron (III) Oxide Reduction":
                        // Set initial amount of desired products and leftovers - Fe2O3 + 3C -> 2Fe + 3CO2
                        this.desiredLeftOverIronOxide = randomProductLeftOvers.Next(1, 9);
                        this.desiredLeftOverCarbon = randomProductLeftOvers.Next(1, 9);

                        //Call to a method simulating Iron III Oxide Reduction
                        this.ironOxideReductionResult = ChemicalReactions.ReactFe2O3AndC(ref this.desiredLeftOverIronOxide, ref this.desiredLeftOverCarbon);

                        //Desired products
                        this.desiredIron = this.ironOxideReductionResult.Item1;
                        this.desiredCarbonDioxide = this.ironOxideReductionResult.Item2;

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/IronIIIOxideReduction.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "Fe2O3";
                        txtBlockReactant2.Text = "C";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "Fe";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "Fe2O3";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "C";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/FE2O3.png";
                        this.reactant2Geometry = "ms-appx:///Assets/C.png";
                        this.productOneGeometry = "ms-appx:///Assets/FE.png";
                        this.productTwoGeometry = "ms-appx:///Assets/CO2.png";

                        //Molecular Geometry as labels for reactant 1 and 2 in before Reaction section
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/FE2O3.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FE.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FE2O3.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C.png"));

                        //Assign the labels with initial products and leftovers
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.desiredIron.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.desiredCarbonDioxide.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.desiredLeftOverIronOxide.ToString();
                        dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.desiredLeftOverCarbon.ToString();

                        //Populate products and leftovers StackPanels with geometry
                        this.productOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne");
                        this.productTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo");
                        this.leftOverOnePanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1");
                        this.leftOverTwoPanel = dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2");

                        //Add geometries for desired products and leftovers to StackPanel
                        for (int i = 0; i < this.desiredIron; i++)
                        {
                            //Call to a method that adds molecular geometry to StackPanel
                            AddImageToStackPanel(this.productOnePanel, this.productOneGeometry);
                        }
                        for (int i = 0; i < this.desiredCarbonDioxide; i++)
                        {
                            AddImageToStackPanel(this.productTwoPanel, this.productTwoGeometry);
                        }
                        //LeftOvers
                        for (int i = 0; i < this.desiredLeftOverIronOxide; i++)
                        {
                            AddImageToStackPanel(this.leftOverOnePanel, this.reactant1Geometry);
                        }
                        for (int i = 0; i < this.desiredLeftOverCarbon; i++)
                        {
                            AddImageToStackPanel(this.leftOverTwoPanel, this.reactant2Geometry);
                        }

                        break;
                }
            }
        }

        //Method to add molecular geometry/images for reactants based on button clicked and the value
        private void NumericUpDown_ValueChanged(object sender, RoutedEventArgs e)
        {
            if (selectedReactionName != null)
            {
                //Set the Question Mark image to invisible
                questionMark.Visibility = Visibility.Collapsed;
                //Set Sad Face invisible if present
                sadFace.Visibility = Visibility.Collapsed;
                //Set Smiley Face invisible if present
                smileyFace.Visibility = Visibility.Collapsed;

                //variable to hold the name of the button clicked
                this.numericUpDown = sender as NumericUpDown;

                //A call to the storyboard in MainPage.Xaml to animate the arrow after button click
                blowWindStoryboard.Begin();

                //Statement to check which button was clicked to assign appropriate panel and images to stack
                if (this.numericUpDown == reactant1)
                {
                    this.stackPanel = imageStackPanel1;
                    this.molecularGeometry = this.reactant1Geometry;
                }
                else
                {
                    this.stackPanel = imageStackPanel2;
                    this.molecularGeometry = this.reactant2Geometry;
                }

                // count only Image elements
                int imageCount = this.stackPanel.Children.OfType<Image>().Count();

                //If the value of the button is greater than count of images, add image
                if (this.numericUpDown.Value > imageCount)
                {
                    // Add images with animation
                    for (int i = imageCount; i < this.numericUpDown.Value; i++)
                    {
                        AddImageToStackPanel(this.stackPanel, this.molecularGeometry);
                    }
                }
                else if (this.numericUpDown.Value < imageCount)
                {
                    // Remove images
                    for (int i = imageCount; i > this.numericUpDown.Value; i--)
                    {
                        this.stackPanel.Children.RemoveAt(0);
                    }
                }
            }
        }

        // Method to add Molecular geometry to the stack panel
        private void AddImageToStackPanel(StackPanel stackPanel, string molecularGeometry)
        {
            Image newImage = new Image
            {
                Source = new BitmapImage(new Uri(molecularGeometry)),
                Width = 50,
                Height = 50,
                Margin = new Thickness(5, 0, 5, 0),
                RenderTransform = new TranslateTransform(),
                RenderTransformOrigin = new Windows.Foundation.Point(0.5, 1) // Start from bottom
            };

            stackPanel.Children.Insert(0, newImage);

            // Animate the image to move upwards
            Storyboard storyboard = new Storyboard();
            DoubleAnimation translateAnimation = new DoubleAnimation
            {
                From = 50,
                To = 0,
                Duration = new Duration(TimeSpan.FromSeconds(0.5)),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(translateAnimation, newImage);
            Storyboard.SetTargetProperty(translateAnimation, "(UIElement.RenderTransform).(TranslateTransform.Y)");

            storyboard.Children.Add(translateAnimation);
            storyboard.Begin();
        }

        //On-click Event: takes the number of molecules entered, simulate the reaction, and check if user has provided correct number of reactants
        private void BalanceEquationButton_Click(object sender, RoutedEventArgs e)
        {
            //Set the Question Mark image to invisible
            questionMark.Visibility = Visibility.Collapsed;
            //Set Sad Face invisible if present
            sadFace.Visibility = Visibility.Collapsed;
            //Set Smiley Face invisible if present
            smileyFace.Visibility = Visibility.Collapsed;

            switch (selectedReactionName[currentChallengeNumber])
            {
                case "Make Water":
                    // Number of H2 and O2 molecules available for the reaction
                    this.hydrogenMolecules = reactant1.Value;
                    this.oxygenMolecules = reactant2.Value;

                    //Get the reaction results from ReactH2AndO2
                    this.waterMoleculesProduced = ChemicalReactions.ReactH2AndO2(ref this.hydrogenMolecules, ref this.oxygenMolecules);

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckOneProduct(this.waterMoleculesProduced, this.hydrogenMolecules, this.oxygenMolecules, this.desiredWater, this.desiredLeftOverHydrogen, this.desiredLeftOverOxygen);

                    break;
                case "Make Ammonia":
                    // Number of N2 and H2 molecules available for the reaction
                    this.nitrogenMolecules = reactant1.Value;
                    this.hydrogenMolecules = reactant2.Value;

                    //Get the reaction results from ReactN2AndH2
                    this.ammoniaMoleculesProduced = ChemicalReactions.ReactN2AndH2(ref this.nitrogenMolecules, ref this.hydrogenMolecules);

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckOneProduct(this.ammoniaMoleculesProduced, this.nitrogenMolecules, this.hydrogenMolecules, this.desiredAmmonia, this.desiredLeftOverNitrogen, this.desiredLeftOverHydrogen);

                    break;
                case "Combust Methane":
                    // Number of CH4 and O2 molecules available for the reaction
                    this.methaneMolecules = reactant1.Value;
                    this.oxygenMolecules = reactant2.Value;

                    //Get the reaction results from ReactCH4AndO2
                    this.methaneReactionResult = ChemicalReactions.ReactCH4AndO2(ref this.methaneMolecules, ref this.oxygenMolecules);

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(this.methaneReactionResult.Item1, this.methaneReactionResult.Item2, this.methaneMolecules, this.oxygenMolecules, desiredCarbonDioxide, desiredWater, desiredLeftOverMethane, desiredLeftOverOxygen);

                    break;
                case "Thermite Reaction":
                    // Number of Al5 and Fe2O3 molecules available for the reaction
                    this.aluminumMolecules = reactant1.Value;
                    this.ironOxideMolecules = reactant2.Value;

                    //Call to a method simulating Thermite Reaction
                    this.thermiteReactionResult = ChemicalReactions.ReactAlAndFe2O3(ref this.aluminumMolecules, ref this.ironOxideMolecules);

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(this.thermiteReactionResult.Item1, this.thermiteReactionResult.Item2, this.aluminumMolecules, this.ironOxideMolecules, this.desiredIron, this.desiredAluminumOxide, this.desiredLeftOverAluminum, this.desiredLeftOverIronOxide);

                    break;
                case "Combust Ethane":
                    // Number of C2H6 and O2 molecules available for the reaction
                    this.ethaneMolecules = reactant1.Value;
                    this.oxygenMolecules = reactant2.Value;

                    //Call to a method simulating Ethane Combustion
                    this.ethaneReactionResult = ChemicalReactions.ReactC2H6AndO2(ref this.ethaneMolecules, ref this.oxygenMolecules);

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(this.ethaneReactionResult.Item1, this.ethaneReactionResult.Item2, this.ethaneMolecules, this.oxygenMolecules, this.desiredCarbonDioxide, this.desiredWater, this.desiredLeftOverEthane, this.desiredLeftOverOxygen);

                    break;
                case "Combust Ethanol":
                    // Number of C2H5OH and O2 molecules available for the reaction
                    this.ethanolMolecules = reactant1.Value;
                    this.oxygenMolecules = reactant2.Value;

                    //Call to a method simulating Ethanol Combustion
                    this.ethaneReactionResult = ChemicalReactions.ReactC2H5OHAndO2(ref this.ethanolMolecules, ref this.oxygenMolecules);

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(this.ethaneReactionResult.Item1, this.ethaneReactionResult.Item2, this.ethanolMolecules, this.oxygenMolecules, this.desiredCarbonDioxide, this.desiredWater, this.desiredLeftOverEthanol, this.desiredLeftOverOxygen);

                    break;
                case "Iron (II) Oxide and Sodium":
                    // Number of FeO and Na molecules available for the reaction
                    this.ironOxideMolecules = reactant1.Value;
                    this.sodiumMolecules = reactant2.Value;

                    //Call to a method simulating Reaction of Iron II Oxide and Sodium
                    this.ironSodiumReactionResult = ChemicalReactions.ReactFeOAndNa(ref this.ironOxideMolecules, ref this.sodiumMolecules);

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(this.ironSodiumReactionResult.Item1, this.ironSodiumReactionResult.Item2, this.ironOxideMolecules, this.sodiumMolecules, this.desiredSodiumOxide, this.desiredIron, this.desiredLeftOverIronOxide, this.desiredLeftOverSodium);

                    break;
                case "Combust Ethene":
                    // Number of C2H4 and O2 molecules available for the reaction
                    this.etheneMolecules = reactant1.Value;
                    this.oxygenMolecules = reactant2.Value;

                    //Call to a method simulating Ethene Combustion
                    this.etheneReactionResult = ChemicalReactions.ReactC2H4AndO2(ref this.etheneMolecules, ref this.oxygenMolecules);

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(this.etheneReactionResult.Item1, this.etheneReactionResult.Item2, this.etheneMolecules, this.oxygenMolecules, this.desiredCarbonDioxide, this.desiredWater, this.desiredLeftOverEthene, this.desiredLeftOverOxygen);

                    break;
                case "Fermentation of Glucose":
                    // Number of C6H12O6 molecules available for the reaction
                    this.glucoseMolecules = reactant1.Value;

                    //Call to a method simulating Glucose Fermentation
                    this.glucoseReactionResult = ChemicalReactions.ReactC6H12O6(ref this.glucoseMolecules);

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckOneReactantTwoProducts(this.glucoseReactionResult.Item1, this.glucoseReactionResult.Item2, this.glucoseMolecules, this.desiredEthanol, this.desiredCarbonDioxide, this.desiredLeftOverGlucose);

                    break;
                case "Iron (III) Oxide Reduction":
                    // Number of FE2O3 and C molecules available for the reaction
                    this.ironOxideMolecules = reactant1.Value;
                    this.carbonMolecules = reactant2.Value;

                    //Call to a method simulating Iron III Oxide Reduction
                    this.ironOxideReductionResult = ChemicalReactions.ReactFe2O3AndC(ref this.ironOxideMolecules, ref this.carbonMolecules);

                    //Pass the amount of products produced and leftovers, desired number of products and leftovers to a
                    //method that check if users reactants will produced desired results
                    CheckTwoProducts(this.ironOxideReductionResult.Item1, this.ironOxideReductionResult.Item2, this.ironOxideMolecules, this.carbonMolecules, this.desiredIron, this.desiredCarbonDioxide, this.desiredLeftOverIronOxide, this.desiredLeftOverCarbon);

                    break;
            }
        }
        //
        //Method to clear stack panels of Geometry and TextBlock values
        private void ClearGeometryAndTextBlocks()
        {
            reactant1.Value = 0;
            reactant2.Value = 0;

            imageStackPanel1.Children.Clear();
            imageStackPanel2.Children.Clear();

            productLeftOverPanel.Children.Clear();
            leftOversPanel.Children.Clear();
            productsLeftOversGeometryPanel.Children.Clear();
            productsLeftOversGeometryLabels.Children.Clear();

            smileyFace.Visibility = Visibility.Collapsed;
            sadFace.Visibility = Visibility.Collapsed;
            questionMark.Visibility = Visibility.Visible;
        }
        //
        //Method to Show Images as Answer for number of reactants
        private void ShowAnswerAsGeometry(StackPanel stackPanel, string molecularGeometry)
        {
            // count only Image elements
            int imageCount = this.stackPanel.Children.OfType<Image>().Count();

            //If the value of the button is greater than count of images, add image
            if (this.numericUpDown.Value > imageCount)
            {
                // Add images with animation
                for (int i = imageCount; i < this.numericUpDown.Value; i++)
                {
                    AddImageToStackPanel(this.stackPanel, this.molecularGeometry);
                }
            }
            else if (this.numericUpDown.Value < imageCount)
            {
                // Remove images
                for (int i = imageCount; i > this.numericUpDown.Value; i--)
                {
                    this.stackPanel.Children.RemoveAt(0);
                }
            }
        }
        //Event Handler for the next button
        private void NextChallengeButton_Click(object sender, RoutedEventArgs e)
        {
            ClearGeometryAndTextBlocks();
            currentChallengeNumber++;
            ReactionChallenges();
            attempts = 0;
            Next.Visibility = Visibility.Collapsed;
            Check.Visibility = Visibility.Visible;
        }
        //Event Handler for the Try button
        private void TryAgainChallengeButton_Click(object sender, RoutedEventArgs e)
        {
            smileyFace.Visibility = Visibility.Collapsed;
            sadFace.Visibility = Visibility.Collapsed;
            Check.Visibility = Visibility.Visible;
            TryAgain.Visibility = Visibility.Collapsed;
        }
        //Event Handler for View Answer
        private void ViewAnswerButton_Click(object sender, RoutedEventArgs e)
        {
            ViewAnswer.Visibility = Visibility.Collapsed;
            Check.Visibility = Visibility.Collapsed;
            Next.Visibility = Visibility.Visible;
            sadFace.Visibility = Visibility.Collapsed;
          
          
            // Set reactants, products, and leftovers details: TextBlock labels, geometry/images
            switch (selectedReactionName[currentChallengeNumber])
            {
                case "Make Water":
                    
                    CalculateReactants.CalculateReactantsForH2AndO2(this.desiredWater, this.desiredLeftOverHydrogen, this.desiredLeftOverOxygen, out int initialHydrogen, out int initialOxygen);
                    reactant1.Value = initialHydrogen;
                    reactant2.Value = initialOxygen;

                    //For loop to add expected reactants geometry to stackpanel
                    for (int i = 1; i <= initialHydrogen; i++)
                    {
                       ShowAnswerAsGeometry(this.imageStackPanel1, this.reactant1Geometry);
                        
                    }
                    for (int j = 1; j <=initialOxygen; j++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel2, this.reactant2Geometry);
                        
                    }
                    break;

                case "Make Ammonia":
                    CalculateReactants.CalculateReactantsForN2AndH2(this.desiredAmmonia, this.desiredLeftOverNitrogen, this.desiredLeftOverHydrogen, out int expectedNitrogen, out int expectedHydrogen);
                    reactant1.Value = expectedNitrogen;
                    reactant2.Value = expectedHydrogen;

                    for (int i = 1; i <= expectedNitrogen; i++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel1, this.reactant1Geometry);
                    }
                    for (int j = 1; j <= expectedHydrogen; j++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel2, this.reactant2Geometry);
                    }
                    break;
                
                case "Combust Methane":
                    CalculateReactants.CalculateReactantsForCH4AndO2(this.desiredCarbonDioxide,desiredWater, this.desiredLeftOverMethane, this.desiredLeftOverOxygen, out int expectedMethane, out int expectedMethaneOxygen);
                    reactant1.Value = expectedMethane;
                    reactant2.Value = expectedMethaneOxygen;

                    for (int i = 1; i <= (int)reactant1.Value; i++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel1, this.reactant1Geometry);
                    }
                    for (int j = 1; j <= (int)reactant2.Value; j++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel2, this.reactant2Geometry);
                    }

                    break;
                
                case "Thermite Reaction":
                    CalculateReactants.CalculateReactantsForAlAndFe2O3(this.desiredAluminumOxide, this.desiredIron, this.desiredLeftOverAluminum, this.desiredLeftOverIronOxide, out int expectedAluminum, out int expectedIronOxide);
                    reactant1.Value = expectedAluminum;
                    reactant2.Value = expectedIronOxide;

                    for (int i = 1; i <= expectedAluminum; i++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel1, this.reactant1Geometry);
                    }
                    for (int j = 1; j <= expectedIronOxide; j++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel2, this.reactant2Geometry);
                    }
                    
                    break;
                
                case "Combust Ethane":
                    CalculateReactants.CalculateReactantsForC2H6AndO2(this.desiredCarbonDioxide, this.desiredWater, this.desiredLeftOverEthane, this.desiredLeftOverOxygen, out int expectedEthane, out int expectedEthaneOxygen);
                    reactant1.Value = expectedEthane;
                    reactant2.Value = expectedEthaneOxygen;

                    for (int i = 1; i <= expectedEthane; i++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel1, this.reactant1Geometry);
                    }
                    for (int j = 1; j <= expectedEthaneOxygen; j++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel2, this.reactant2Geometry);
                    }
                    
                    break;
                
                case "Combust Ethanol":
                    CalculateReactants.CalculateReactantsForC2H5OHAndO2(this.desiredCarbonDioxide, this.desiredWater, this.desiredLeftOverEthanol, this.desiredLeftOverOxygen, out int expectedEthanol, out int expectedEthanolOxygen);
                    reactant1.Value = expectedEthanol;
                    reactant2.Value = expectedEthanolOxygen;

                    for (int i = 1; i <= expectedEthanol; i++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel1, this.reactant1Geometry);
                    }
                    for (int j = 1; j <= expectedEthanolOxygen; j++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel2, this.reactant2Geometry);
                    }
                    
                    break;
                
                case "Iron (II) Oxide and Sodium":
                    CalculateReactants.CalculateReactantsForFeOAndNa(this.desiredSodiumOxide, this.desiredIron, this.desiredLeftOverIronOxide, this.desiredLeftOverSodium, out int expectedIronIIOxide, out int expectedSodium);
                    reactant1.Value = expectedIronIIOxide;
                    reactant2.Value = expectedSodium;

                    for (int i = 1; i <= expectedIronIIOxide; i++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel1, this.reactant1Geometry);
                    }
                    for (int j = 1; j <= expectedSodium; j++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel2, this.reactant2Geometry);
                    }
                    
                    break;
               
                case "Combust Ethene":
                    CalculateReactants.CalculateReactantsForC2H4AndO2(this.desiredCarbonDioxide, this.desiredWater, this.desiredLeftOverEthene, this.desiredLeftOverOxygen, out int expectedEthene, out int expectedEtheneOxygen);
                    reactant1.Value = expectedEthene;
                    reactant2.Value = expectedEtheneOxygen;

                    for (int i = 1; i <= expectedEthene; i++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel1, this.reactant1Geometry);
                    }
                    for (int j = 1; j <= expectedEtheneOxygen; j++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel2, this.reactant2Geometry);
                    }
                    
                    break;
                
                case "Fermentation of Glucose":
                    CalculateReactants.CalculateReactantsForC6H12O6(this.desiredEthanol, this.desiredCarbonDioxide, this.desiredLeftOverGlucose, out int expectedGlucose);
                    reactant1.Value = expectedGlucose;
       
                    for (int i = 1; i <= expectedGlucose; i++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel1, this.reactant1Geometry);
                    }
                    break;
               
                case "Iron (III) Oxide Reduction":
                    CalculateReactants.CalculateReactantsForFe2O3AndC(this.desiredIron, this.desiredCarbonDioxide, this.desiredLeftOverIronOxide, this.desiredLeftOverCarbon, out int expectedIronIIIOxide, out int expectedCarbon);
                    reactant1.Value = expectedIronIIIOxide;
                    reactant2.Value = expectedCarbon;

                    for (int i = 1; i <= expectedIronIIIOxide; i++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel1, this.reactant1Geometry);
                    }
                    for (int j = 1; j <= expectedCarbon; j++)
                    {
                        ShowAnswerAsGeometry(this.imageStackPanel2, this.reactant2Geometry);
                    }
                    break;
            }
        }
        //A method to Check if the user's input react to produced amount of desired products and initial leftovers
        //This method applies to reactions that produce One product
        private void CheckOneProduct(int prodOneProduced, int leftOver1Produced, int leftOver2Produced, int desiredProdOne, int desiredLeftOver1, int desiredLeftOver2)
        {
            if (attempts == 0)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == desiredProdOne && leftOver1Produced == desiredLeftOver1 && leftOver2Produced == desiredLeftOver2)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 2;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    TryAgain.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
            else if (attempts == 1)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == desiredProdOne && leftOver1Produced == desiredLeftOver1 && leftOver2Produced == desiredLeftOver2)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 1;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    TryAgain.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
            else if (attempts == 2)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == desiredProdOne && leftOver1Produced == desiredLeftOver1 && leftOver2Produced == desiredLeftOver2)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 1;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    ViewAnswer.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
        }

        //A method to Check if the user's input react to produced amount of desired products and initial leftovers
        //This method applies to reactions that produce two products
        private void CheckTwoProducts(int prodOneProduced, int prodTwoProduced, int leftOver1Produced, int leftOver2Produced, int desiredProdOne, int desiredProdTwo, int desiredLeftOver1, int desiredLeftOver2)
        {
            if (attempts == 0)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == desiredProdOne &&
                        prodTwoProduced == desiredProdTwo &&
                        leftOver1Produced == desiredLeftOver1 &&
                        leftOver2Produced == desiredLeftOver2)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 2;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    TryAgain.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
            else if (attempts == 1)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == desiredProdOne &&
                        prodTwoProduced == desiredProdTwo &&
                        leftOver1Produced == desiredLeftOver1 &&
                        leftOver2Produced == desiredLeftOver2)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 1;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    TryAgain.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
            else if (attempts == 2)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == desiredProdOne &&
                        prodTwoProduced == desiredProdTwo &&
                        leftOver1Produced == desiredLeftOver1 &&
                        leftOver2Produced == desiredLeftOver2)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 1;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    ViewAnswer.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
        }
        //A method to Check if the user's input react to produced amount of desired products and initial leftovers
        //This method applies to reactions that have one reactant and produce two products
        private void CheckOneReactantTwoProducts(int prodOneProduced, int prodTwoProduced, int leftOver1Produced, int desiredProdOne, int desiredProdTwo, int desiredLeftOver1)
        {
            if (attempts == 0)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == desiredProdOne && prodTwoProduced == desiredProdTwo && leftOver1Produced == desiredLeftOver1)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 2;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    TryAgain.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
            else if (attempts == 1)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == desiredProdOne && prodTwoProduced == desiredProdTwo && leftOver1Produced == desiredLeftOver1)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 1;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    TryAgain.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
            else if (attempts == 2)
            {
                // Check if the user's input react to produced amount of desired products and initial leftovers
                if (prodOneProduced == desiredProdOne && prodTwoProduced == desiredProdTwo && leftOver1Produced == desiredLeftOver1)
                {
                    ShowConfettiEffect();
                    Check.Visibility = Visibility.Collapsed;
                    Next.Visibility = Visibility.Visible;
                    smileyFace.Visibility = Visibility.Visible;
                    SuccessSound.Play();
                    totalScore += 1;
                    txtScore.Text = $"Score: {totalScore}";
                }
                else
                {
                    sadFace.Visibility = Visibility.Visible;
                    Check.Visibility = Visibility.Collapsed;
                    ViewAnswer.Visibility = Visibility.Visible;
                    FailSound.Play();
                    attempts++;
                    txtScore.Text = $"Score: {totalScore}";
                    return; //Do not move to next Challenge
                }
            }
        }
        private void ShowConfettiEffect()
        {
            Random random = new Random();
            for (int i = 0; i < 30; i++)
            {
                Ellipse confetti = new Ellipse
                {
                    Width = 40,
                    Height = 40,
                    Fill = new SolidColorBrush(Color.FromArgb(
                        200,
                        (byte)random.Next(256),
                        (byte)random.Next(256),
                        (byte)random.Next(256)))
                };

                Canvas.SetLeft(confetti, random.Next((int)ConfettiCanvas.ActualWidth));
                Canvas.SetTop(confetti, -10);
                ConfettiCanvas.Children.Add(confetti);

                DoubleAnimation fallAnimation = new DoubleAnimation
                {
                    From = -10,
                    To = ConfettiCanvas.ActualHeight + 10,
                    Duration = TimeSpan.FromSeconds(2 + random.NextDouble() * 3),
                    EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn }
                };

                Storyboard.SetTarget(fallAnimation, confetti);
                Storyboard.SetTargetProperty(fallAnimation, "(Canvas.Top)");

                Storyboard storyboard = new Storyboard();
                storyboard.Children.Add(fallAnimation);
                storyboard.Begin();
            }
        }
    }
}