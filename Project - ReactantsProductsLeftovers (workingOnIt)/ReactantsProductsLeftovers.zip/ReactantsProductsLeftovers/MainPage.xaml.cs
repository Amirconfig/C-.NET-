﻿using System;
using System.Linq;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Media.Imaging;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace ReactantsProductsLeftovers
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        //DynamicUIManager class that generates StackPanels, TextBlock, Image controls FOR REACTANTS WITH ONE PRODUCTS
        private DynamicUIManager dynamicUIManager;

        //DynamicUIManager class that generates StackPanels, TextBlock, Image controls FOR REACTANTS WITH TWO PRODUCTS
        private DynamicUIManagerTwoProducts dynamicUIManagerTwoProducts;

        // Class-level variable to store the selected reaction
        private string selectedReaction;

        //Variables for Molecules
        private int hydrogenMolecules;
        private int oxygenMolecules;
        private int waterMoleculesProduced;
        private int nitrogenMolecules;
        private int ammoniaMoleculesProduced;
        private int methaneMolecules;
        private Tuple<int, int> methaneReactionResult;
        private int aluminumMolecules;
        private int ironOxideMolecules;
        private Tuple<int, int> thermiteReactionResult;
        private int ethaneMolecules;
        private Tuple<int, int> ethaneReactionResult;
        private int ethanolMolecules;
        private Tuple<int, int> ethanolReactionResult;
        private int sodiumMolecules;
        private Tuple<int, int> ironSodiumReactionResult;
        private int etheneMolecules;
        private Tuple<int, int> etheneReactionResult;
        private int glucoseMolecules;
        private Tuple<int, int> glucoseReactionResult;
        private int carbonMolecules;
        private Tuple<int, int> ironOxideReductionResult;

        //Class-level variable to store the path to or for molecular geometry for use
        private string molecularGeometry;
        private string reactant1Geometry;
        private string reactant2Geometry;
        private string productOneGeometry;
        private string productTwoGeometry;

        private StackPanel stackPanel;
        private NumericUpDown numericUpDown;

        public MainPage()
        {
            this.InitializeComponent();

            // Subscribe to ValueChanged events for NumericUpDown controls
            reactant1.ValueChanged += NumericUpDown_ValueChanged;
            reactant2.ValueChanged += NumericUpDown_ValueChanged;

            //Select Make Water reaction on launch
            selectReaction.SelectedIndex = 0;            
        }

        //Method to determine the type of reaction selected
        private void SelectReaction_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (selectReaction.SelectedItem is ComboBoxItem selectedItem)
            {
                //reset the number of molecules/reactants before updating new reaction details
                reactant1.Value = 0;
                reactant2.Value = 0;

                //Reset stackpanels each time a new reaction is selected
                imageStackPanel1.Children.Clear();
                imageStackPanel2.Children.Clear();
                productLeftOverPanel.Children.Clear();
                leftOversPanel.Children.Clear();
                productsLeftOversGeometryPanel.Children.Clear();
                productsLeftOversGeometryLabels.Children.Clear();
                
                //Reset the label for Products and LeftOvers after each selection of a reaction
                txtProducts.Margin = new Thickness(0, 0, 80, 0);
                txtLeftOvers.Margin = new Thickness(0, 0, 30, 0);


                //Clear text-box for number of molecules produced before updating new ones
                txtBlockReactant1.Text = String.Empty;
                txtBlockReactant2.Text = String.Empty;

                //Clear Text Blocks for products and left-overs reactants before updating new reaction details
                txtBlockReactant1.Text = String.Empty;
                txtBlockReactant2.Text = String.Empty;

                selectedReaction = selectedItem.Content.ToString();

                // Logic to Update Reaction Details
                switch (selectedReaction)
                {
                    case "Make Water":

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManager = new DynamicUIManager();
                        this.dynamicUIManager.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManager.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManager.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManager.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/MakeWater.png"));

                        txtBlockReactant1.Text = "H2";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "H2O";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "H2";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 and products
                        this.reactant1Geometry = "ms-appx:///Assets/H2.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/H2.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));


                        //Molecular Geometry as labels for products and left overs 1 and 2
                        this.dynamicUIManager.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        this.dynamicUIManager.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2.png"));
                        this.dynamicUIManager.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        break;

                    case "Make Ammonia":

                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManager = new DynamicUIManager();
                        this.dynamicUIManager.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManager.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManager.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManager.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/MakeAmmonia.png"));

                        txtBlockReactant1.Text = "N2";
                        txtBlockReactant2.Text = "H2";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "NH3";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "N2";
                        this.dynamicUIManager.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "H2";

                        //Molecular Geometry to be added for reactant 1 and 2 and products
                        this.reactant1Geometry = "ms-appx:///Assets/N2.png";
                        this.reactant2Geometry = "ms-appx:///Assets/H2.png";
                        this.productOneGeometry = "ms-appx:///Assets/NH3.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/N2.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/H2.png"));


                        //Molecular Geometry as labels for products and left overs 1 and 2
                        this.dynamicUIManager.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/NH3.png"));
                        this.dynamicUIManager.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/N2.png"));
                        this.dynamicUIManager.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2.png"));

                        break;

                    case "Combust Methane":
                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);


                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustMethane.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "CH4";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "CH4";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/H2.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/H20.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));


                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));
                        
                        break;

                    case "Thermite Reaction":
                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/ThermiteReaction.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "Al";
                        txtBlockReactant2.Text = "Fe2O3";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "Al2O3";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "Fe";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "Al";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "Fe2O3";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/AL.png";
                        this.reactant2Geometry = "ms-appx:///Assets/FE2O3.png";
                        this.productOneGeometry = "ms-appx:///Assets/AL2O3.png";
                        this.productTwoGeometry = "ms-appx:///Assets/FE.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/AL.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/FE2O3.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/AL2O3.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FE.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/AL.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FE2O3.png"));

                        break;

                    case "Combust Ethane":
                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustEthane.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "C2H6";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "C2H6";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/C2H6.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H6.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H6.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        break;

                    case "Combust Ethanol":
                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustEthanol.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "C2H5OH";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "C2H5OH";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/C2H5OH.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H5OH.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));
                      

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H5OH.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        break;

                    case "Iron (II) Oxide and Sodium":
                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/IronIIOxideAndSodium.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "FeO";
                        txtBlockReactant2.Text = "Na";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "Na2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "Fe";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "FeO";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "Na";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/FeO.png";
                        this.reactant2Geometry = "ms-appx:///Assets/Na.png";
                        this.productOneGeometry = "ms-appx:///Assets/Na2O.png";
                        this.productTwoGeometry = "ms-appx:///Assets/Fe.png";

                        //Molecular Geometry as labels for reactant 1 and 2
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/FeO.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/Na.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/Na2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/Fe.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FeO.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/Na.png"));

                        break;

                    case "Combust Ethene":
                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/CombustEthene.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "C2H4";
                        txtBlockReactant2.Text = "O2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "H2O";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "C2H4";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "O2";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/C2H4.png";
                        this.reactant2Geometry = "ms-appx:///Assets/O2.png";
                        this.productOneGeometry = "ms-appx:///Assets/CO2.png";
                        this.productTwoGeometry = "ms-appx:///Assets/H2O.png";

                        //Molecular Geometry as labels for reactant 1 and 2 in before Reaction section
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H4.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/H2O.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H4.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/O2.png"));

                        break;

                    case "Fermentation of Glucose":
                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/FermentationOfGlucose.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "C6H12O6";
                        txtBlockReactant2.Text = "";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "C2H5OH";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "C6H12O6";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/C6H12O6.png";
                        this.reactant2Geometry = "ms-appx:///Assets/NoReactant.png";
                        this.productOneGeometry = "ms-appx:///Assets/C2H5OH.png";
                        this.productTwoGeometry = "ms-appx:///Assets/CO2.png";

                        //Molecular Geometry as labels for reactant 1 and 2 in before Reaction section
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C6H12O6.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/NoReactant.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C2H5OH.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C6H12O6.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/NoReactant.png"));
                        
                        break;

                    case "Iron (III) Oxide Reduction":
                        //Initialize the dynamic StackPanels, TextBlocks, Images, and textblock labels before they are referenced by other methods
                        this.dynamicUIManagerTwoProducts = new DynamicUIManagerTwoProducts();
                        this.dynamicUIManagerTwoProducts.CreateBorderAndStackPanelDynamically(productLeftOverPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockslDynamically(leftOversPanel);
                        this.dynamicUIManagerTwoProducts.CreateImageControlsDynamically(productsLeftOversGeometryPanel);
                        this.dynamicUIManagerTwoProducts.CreateTextBlockLabelsForProductsAndImagesGeometry(productsLeftOversGeometryLabels);

                        //Display Stoichiometry formula of the reaction
                        formulaImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Formulas/IronIIIOxideReduction.png"));

                        //Set the label for Products and LeftOvers after reaction
                        txtProducts.Margin = new Thickness(0, 0, 30, 0);
                        txtLeftOvers.Margin = new Thickness(100, 0, 0, 0);

                        txtBlockReactant1.Text = "Fe2O3";
                        txtBlockReactant2.Text = "C";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product1GeometryLabel").Text = "Fe";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("product2GeometryLabel").Text = "CO2";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver1GeometryLabel").Text = "Fe2O3";
                        this.dynamicUIManagerTwoProducts.GetProductsLeftOversGeometryLabelsByName("leftOver2GeometryLabel").Text = "C";

                        //Molecular Geometry to be added for reactant 1 and 2 when button is clicked
                        this.reactant1Geometry = "ms-appx:///Assets/FE2O3.png";
                        this.reactant2Geometry = "ms-appx:///Assets/C.png";
                        this.productOneGeometry = "ms-appx:///Assets/FE.png";
                        this.productTwoGeometry = "ms-appx:///Assets/CO2.png";

                        //Molecular Geometry as labels for reactant 1 and 2 in before Reaction section
                        reactant1ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/FE2O3.png"));
                        reactant2ImageGeometry.Source = new BitmapImage(new Uri("ms-appx:///Assets/C.png"));

                        //Molecular Geometry as labels for products and left overs 1 and 2
                        dynamicUIManagerTwoProducts.GetImageControlByName("productsImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FE.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("products2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/CO2.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver1ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/FE2O3.png"));
                        dynamicUIManagerTwoProducts.GetImageControlByName("leftOver2ImageGeometry").Source = new BitmapImage(new Uri("ms-appx:///Assets/C.png"));

                        break;

                    default:
                        dynamicUIManager.GetTextBlocksByName("txtBlockProductMolecule").Text = "0";
                        dynamicUIManager.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = "0";
                        dynamicUIManager.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = "0";
                        break;
                }
            }

        }

        //Method to add molecular geometry/images for reactants based on button clicked and the value
        private void NumericUpDown_ValueChanged(object sender, RoutedEventArgs e)
        {
            if (selectReaction.SelectedIndex != -1)
            {
                //variable to hold the name of the button clicked
                this.numericUpDown = sender as NumericUpDown;

                //A call to the storyboard in MainPage.Xaml to animate the arrow after button click
                blowWindStoryboard.Begin();

                //Statement to check which button was clicked to assign appropriate panel and images to stack
                if (this.numericUpDown == reactant1)
                {
                    this.stackPanel = imageStackPanel1;
                    this.molecularGeometry = this.reactant1Geometry;
                }
                else
                {
                    this.stackPanel = imageStackPanel2;
                    this.molecularGeometry = this.reactant2Geometry;
                }

                // count only Image elements
                int imageCount = this.stackPanel.Children.OfType<Image>().Count();

                //If the images the value of the button is greater than count of images, add image
                if (this.numericUpDown.Value > imageCount)
                {
                    // Add images with animation
                    for (int i = imageCount; i < this.numericUpDown.Value; i++)
                    {
                        AddImageToStackPanel(this.stackPanel, this.molecularGeometry);
                    }
                }
                else if (this.numericUpDown.Value < imageCount)
                {
                    // Remove images
                    for (int i = imageCount; i > this.numericUpDown.Value; i--)
                    {
                        this.stackPanel.Children.RemoveAt(0);
                    }
                }

                // Update the stack panel in real-time
                UpdateStackPanel();
            }
        }

        // Method to add an image to the stack panel
        private void AddImageToStackPanel(StackPanel stackPanel, string molecularGeometry)
        {
            Image newImage = new Image
            {
                Source = new BitmapImage(new Uri(molecularGeometry)),
                Width = 50,
                Height = 50,
                Margin = new Thickness(5, 0, 5, 0),
                RenderTransform = new TranslateTransform(),
                RenderTransformOrigin = new Windows.Foundation.Point(0.5, 1) // Start from bottom
            };

            stackPanel.Children.Insert(0, newImage);

            // Animate the image to move upwards
            Storyboard storyboard = new Storyboard();
            DoubleAnimation translateAnimation = new DoubleAnimation
            {
                From = 50,
                To = 0,
                Duration = new Duration(TimeSpan.FromSeconds(0.5)),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(translateAnimation, newImage);
            Storyboard.SetTargetProperty(translateAnimation, "(UIElement.RenderTransform).(TranslateTransform.Y)");

            storyboard.Children.Add(translateAnimation);
            storyboard.Begin();
        }

        // Method to update the stack panel with the correct number of images
        private void UpdateStackPanel()
        {
            //Variables to hold the number of molecules for the reactants each time a button is clicked
            int reactant1Count = (int)reactant1.Value;
            int reactant2Count = (int)reactant2.Value;

            // Logic to handle different reactions
            switch (selectedReaction)
            {
                case "Make Water":
                    // Number of H2 and O2 molecules available for the reaction
                    this.hydrogenMolecules = reactant1Count;
                    this.oxygenMolecules = reactant2Count;

                    // Call to a method simulating Water Reaction
                    this.waterMoleculesProduced = ReactH2AndO2(ref this.hydrogenMolecules, ref this.oxygenMolecules);

                    // Displaying the result
                    dynamicUIManager.GetTextBlocksByName("txtBlockProductMolecule").Text = this.waterMoleculesProduced.ToString();
                    dynamicUIManager.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.hydrogenMolecules.ToString();
                    dynamicUIManager.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.oxygenMolecules.ToString();

                    break;

                case "Make Ammonia":
                    // Number of N2 and H2 molecules available for the reaction
                    this.nitrogenMolecules = reactant1Count;
                    this.hydrogenMolecules = reactant2Count;

                    //Call to a method simulating Ammonia Reaction
                    this.ammoniaMoleculesProduced = ReactN2AndH2(ref this.nitrogenMolecules, ref this.hydrogenMolecules);

                    //Displaying the result
                    dynamicUIManager.GetTextBlocksByName("txtBlockProductMolecule").Text = this.ammoniaMoleculesProduced.ToString();
                    dynamicUIManager.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.nitrogenMolecules.ToString();
                    dynamicUIManager.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.hydrogenMolecules.ToString();

                    break;

                case "Combust Methane":
                    // Number of CH4 and O2 molecules available for the reaction
                    this.methaneMolecules = reactant1Count;
                    this.oxygenMolecules = reactant2Count;

                    //Call to a method simulating Methane Combustion
                    this.methaneReactionResult = ReactCH4AndO2(ref this.methaneMolecules, ref this.oxygenMolecules);

                    //Displaying the result
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.methaneReactionResult.Item1.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.methaneReactionResult.Item2.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.methaneMolecules.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.oxygenMolecules.ToString();

                    break;

                case "Thermite Reaction":
                    // Number of Al5 and Fe2O3 molecules available for the reaction
                    this.aluminumMolecules = reactant1Count;
                    this.ironOxideMolecules = reactant2Count;

                    //Call to a method simulating Thermite Reaction
                    this.thermiteReactionResult = ReactAlAndFe2O3(ref this.aluminumMolecules, ref this.ironOxideMolecules);

                    //Displaying the result
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.thermiteReactionResult.Item2.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.thermiteReactionResult.Item1.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.aluminumMolecules.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.ironOxideMolecules.ToString();
                    break;

                case "Combust Ethane":
                    // Number of C2H6 and O2 molecules available for the reaction
                    this.ethaneMolecules = reactant1Count;
                    this.oxygenMolecules = reactant2Count;

                    //Call to a method simulating Ethane Combustion
                    this.ethaneReactionResult = ReactC2H6AndO2(ref this.ethaneMolecules, ref this.oxygenMolecules);

                    //Displaying the result
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.ethaneReactionResult.Item1.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.ethaneReactionResult.Item2.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.ethaneMolecules.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.oxygenMolecules.ToString();
                    
                    break;

                case "Combust Ethanol":
                    // Number of C2H5OH and O2 molecules available for the reaction
                    this.ethanolMolecules = reactant1Count;
                    this.oxygenMolecules = reactant2Count;

                    //Call to a method simulating Ethanol Combustion
                    this.ethanolReactionResult = ReactC2H5OHAndO2(ref this.ethanolMolecules, ref this.oxygenMolecules);

                    //Displaying the result
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.ethanolReactionResult.Item1.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.ethanolReactionResult.Item2.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.ethanolMolecules.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.oxygenMolecules.ToString();

                    break;
                case "Iron (II) Oxide and Sodium":
                    // Number of FeO and Na molecules available for the reaction
                    this.ironOxideMolecules = reactant1Count;
                    this.sodiumMolecules = reactant2Count;

                    //Call to a method simulating Reaction of Iron II Oxide and Sodium
                    this.ironSodiumReactionResult = ReactFeOAndNa(ref this.ironOxideMolecules, ref this.sodiumMolecules);

                    //Displaying the result
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.ironSodiumReactionResult.Item1.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.ironSodiumReactionResult.Item2.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.ironOxideMolecules.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.sodiumMolecules.ToString();

                    break;

                case "Combust Ethene":
                    // Number of C2H4 and O2 molecules available for the reaction
                    this.etheneMolecules = reactant1Count;
                    this.oxygenMolecules = reactant2Count;

                    //Call to a method simulating Ethene Combustion
                    this.etheneReactionResult = ReactC2H4AndO2(ref this.etheneMolecules, ref this.oxygenMolecules);

                    //Displaying the result
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.etheneReactionResult.Item1.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.etheneReactionResult.Item2.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.etheneMolecules.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.oxygenMolecules.ToString();
                    
                    break;

                case "Fermentation of Glucose":
                    // Number of C6H12O6 molecules available for the reaction
                    this.glucoseMolecules = reactant1Count;


                    //Call to a method simulating Glucose Fermentation
                    this.glucoseReactionResult = ReactC6H12O6(ref this.glucoseMolecules);

                    //Displaying the result
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.glucoseReactionResult.Item1.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.glucoseReactionResult.Item2.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.glucoseMolecules.ToString();
                   
                    break;

                case "Iron (III) Oxide Reduction":
                    // Number of FE2O3 and C molecules available for the reaction
                    this.ironOxideMolecules = reactant1Count;
                    this.carbonMolecules = reactant2Count;

                    //Call to a method simulating Iron III Oxide Reduction
                    this.ironOxideReductionResult = ReactFe2O3AndC(ref this.ironOxideMolecules, ref this.carbonMolecules);

                    //Displaying the result
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductMolecule").Text = this.ironOxideReductionResult.Item1.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockProductTwoMolecule").Text = this.ironOxideReductionResult.Item2.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver1Molecule").Text = this.ironOxideMolecules.ToString();
                    dynamicUIManagerTwoProducts.GetTextBlocksByName("txtBlockLeftOver2Molecule").Text = this.carbonMolecules.ToString();

                    break;
                    
                default:
                    break;
            }

            // Refresh the stack panel based on the updated molecule counts
            switch (selectedReaction)
            {
                case "Make Water":
                    UpdateLeftOverImages(dynamicUIManager.GetStackPanelByName("imageStackPanelProductOne"), this.waterMoleculesProduced, this.productOneGeometry);
                    UpdateLeftOverImages(dynamicUIManager.GetStackPanelByName("imageStackPanelLeftOver1"), this.hydrogenMolecules, this.reactant1Geometry);
                    UpdateLeftOverImages(dynamicUIManager.GetStackPanelByName("imageStackPanelLeftOver2"), this.oxygenMolecules, this.reactant2Geometry);
                    
                    break;

                case "Make Ammonia":
                    UpdateLeftOverImages(dynamicUIManager.GetStackPanelByName("imageStackPanelProductOne"), this.ammoniaMoleculesProduced, this.productOneGeometry);
                    UpdateLeftOverImages(dynamicUIManager.GetStackPanelByName("imageStackPanelLeftOver1"), this.nitrogenMolecules, this.reactant1Geometry);
                    UpdateLeftOverImages(dynamicUIManager.GetStackPanelByName("imageStackPanelLeftOver2"), this.hydrogenMolecules, this.reactant2Geometry);

                    break;

                case "Combust Methane":
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne"), this.methaneReactionResult.Item1, this.productOneGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo"), this.methaneReactionResult.Item2, this.productTwoGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1"), this.methaneMolecules, this.reactant1Geometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2"), this.oxygenMolecules, this.reactant2Geometry);

                    break;

                case "Thermite Reaction":
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne"), this.thermiteReactionResult.Item1, this.productOneGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo"), this.thermiteReactionResult.Item2, this.productTwoGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1"), this.aluminumMolecules, this.reactant1Geometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2"), this.ironOxideMolecules, this.reactant2Geometry);
                    
                    break;

                case "Combust Ethane":
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne"), this.ethaneReactionResult.Item1, this.productOneGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo"), this.ethaneReactionResult.Item2, this.productTwoGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1"), this.ethaneMolecules, this.reactant1Geometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2"), this.oxygenMolecules, this.reactant2Geometry);

                    break;

                case "Combust Ethanol":
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne"), this.ethanolReactionResult.Item1, this.productOneGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo"), this.ethanolReactionResult.Item2, this.productTwoGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1"), this.ethanolMolecules, this.reactant1Geometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2"), this.oxygenMolecules, this.reactant2Geometry);

                    break;

                case "Iron (II) Oxide and Sodium":
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne"), this.ironSodiumReactionResult.Item1, this.productOneGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo"), this.ironSodiumReactionResult.Item2, this.productTwoGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1"), this.ironOxideMolecules, this.reactant1Geometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2"), this.sodiumMolecules, this.reactant2Geometry);
                    
                    break;
                case "Combust Ethene":
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne"), this.etheneReactionResult.Item1, this.productOneGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo"), this.etheneReactionResult.Item2, this.productTwoGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1"), this.etheneMolecules, this.reactant1Geometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2"), this.oxygenMolecules, this.reactant2Geometry);
                    
                    break;

                case "Fermentation of Glucose":
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne"), this.glucoseReactionResult.Item1, this.productOneGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo"), this.glucoseReactionResult.Item2, this.productTwoGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1"), this.glucoseMolecules, this.reactant1Geometry);
    
                    break;

                case "Iron (III) Oxide Reduction":
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductOne"), this.ironOxideReductionResult.Item1, this.productOneGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelProductTwo"), this.ironOxideReductionResult.Item2, this.productTwoGeometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver1"), this.ironOxideMolecules, this.reactant1Geometry);
                    UpdateLeftOverImages(dynamicUIManagerTwoProducts.GetStackPanelByName("imageStackPanelLeftOver2"), this.carbonMolecules, this.reactant2Geometry);
                   
                    break;

                default:
                    break;
            }
        }

        // Method to update the left-over images
        private void UpdateLeftOverImages(StackPanel stackPanel, int moleculeCount, string molecularGeometry)
        {
            // count only Image elements
            int imageCount = stackPanel.Children.OfType<Image>().Count();

            // Add or remove images to match the molecule count
            if (moleculeCount > imageCount)
            {
                for (int i = imageCount; i < moleculeCount; i++)
                {
                    AddImageToStackPanel(stackPanel, molecularGeometry);
                }
            }
            else if (moleculeCount < imageCount)
            {
                for (int i = imageCount; i > moleculeCount; i--)
                {
                    stackPanel.Children.RemoveAt(0);
                }
            }
        }

       

        //Method to simulate Water Reaction
        static int ReactH2AndO2(ref int hydrogenMolecules, ref int oxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction 2H2 + O2 -> 2H2O
            const int hydrogenStoich = 2;
            const int oxygenStoich = 1;
            const int waterStoich = 2;

            // Calculate the maximum number of water molecules that can be produced
            int maxWaterByHydrogen = hydrogenMolecules / hydrogenStoich;
            int maxWaterByOxygen = oxygenMolecules / oxygenStoich;
            int maxWaterMolecules = Math.Min(maxWaterByHydrogen, maxWaterByOxygen) * waterStoich;

            // Update the remaining hydrogen and oxygen molecules
            hydrogenMolecules -= (maxWaterMolecules / waterStoich) * hydrogenStoich;
            oxygenMolecules -= (maxWaterMolecules / waterStoich) * oxygenStoich;

            return maxWaterMolecules;
        }

        //Method to simulate Ammonia Reaction
        static int ReactN2AndH2(ref int nitrogenMolecules, ref int hydrogenMolecules)
        {
            // Stoichiometric coefficients for the reaction N2 + 3H2 -> 2NH3
            const int nitrogenStoich = 1;
            const int hydrogenStoich = 3;
            const int ammoniaStoich = 2;

            // Calculate the maximum number of ammonia molecules that can be produced
            int maxAmmoniaByNitrogen = nitrogenMolecules / nitrogenStoich;
            int maxAmmoniaByHydrogen = hydrogenMolecules / hydrogenStoich;
            int maxAmmoniaMolecules = Math.Min(maxAmmoniaByNitrogen, maxAmmoniaByHydrogen) * ammoniaStoich;

            // Update the remaining nitrogen and hydrogen molecules
            nitrogenMolecules -= (maxAmmoniaMolecules / ammoniaStoich) * nitrogenStoich;
            hydrogenMolecules -= (maxAmmoniaMolecules / ammoniaStoich) * hydrogenStoich;

            return maxAmmoniaMolecules;
        }

        //Method to simulate Methane Combustion
        static Tuple<int, int> ReactCH4AndO2(ref int methaneMolecules, ref int oxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction CH4 + 2O2 -> CO2 + 2H2O
            const int methaneStoich = 1;
            const int oxygenStoich = 2;
            const int carbonDioxideStoich = 1;
            const int waterStoich = 2;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByMethane = methaneMolecules / methaneStoich;
            int maxReactionsByOxygen = oxygenMolecules / oxygenStoich;
            int maxReactions = Math.Min(maxReactionsByMethane, maxReactionsByOxygen);

            // Calculate the number of products
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;
            int waterProduced = maxReactions * waterStoich;

            // Update the remaining methane and oxygen molecules
            methaneMolecules -= maxReactions * methaneStoich;
            oxygenMolecules -= maxReactions * oxygenStoich;

            return Tuple.Create(carbonDioxideProduced, waterProduced);
        }

        //Method to simulate Thermite Reaction
        static Tuple<int, int> ReactAlAndFe2O3(ref int aluminumMolecules, ref int ironOxideMolecules)
        {
            // Stoichiometric coefficients for the reaction 2Al + Fe2O3 -> 2Fe + Al2O3
            const int aluminumStoich = 2;
            const int ironOxideStoich = 1;
            const int ironStoich = 2;
            const int aluminumOxideStoich = 1;

            // Calculate the maximum number of iron and aluminum oxide molecules that can be produced
            int maxReactionsByAluminum = aluminumMolecules / aluminumStoich;
            int maxReactionsByIronOxide = ironOxideMolecules / ironOxideStoich;
            int maxReactions = Math.Min(maxReactionsByAluminum, maxReactionsByIronOxide);

            // Calculate the number of products
            int ironProduced = maxReactions * ironStoich;
            int aluminumOxideProduced = maxReactions * aluminumOxideStoich;

            // Update the remaining aluminum and iron(III) oxide
            aluminumMolecules -= maxReactions * aluminumStoich;
            ironOxideMolecules -= maxReactions * ironOxideStoich;

            return Tuple.Create(ironProduced, aluminumOxideProduced);
        }

        //Methane to simulate Combustion of Ethane
        static Tuple<int, int> ReactC2H6AndO2(ref int ethaneMolecules, ref int oxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction 2C2H6 + 7O2 -> 4CO2 + 6H2O
            const int ethaneStoich = 2;
            const int oxygenStoich = 7;
            const int carbonDioxideStoich = 4;
            const int waterStoich = 6;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByEthane = ethaneMolecules / ethaneStoich;
            int maxReactionsByOxygen = oxygenMolecules / oxygenStoich;
            int maxReactions = Math.Min(maxReactionsByEthane, maxReactionsByOxygen);

            // Calculate the number of products
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;
            int waterProduced = maxReactions * waterStoich;

            // Update the remaining ethane and oxygen molecules
            ethaneMolecules -= maxReactions * ethaneStoich;
            oxygenMolecules -= maxReactions * oxygenStoich;

            return Tuple.Create(carbonDioxideProduced, waterProduced);
        }

        //Method to simulate Combustion of Ethanol
        static Tuple<int, int> ReactC2H5OHAndO2(ref int ethanolMolecules, ref int oxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction C2H5OH + 3O2 -> 2CO2 + 3H2O
            const int ethanolStoich = 1;
            const int oxygenStoich = 3;
            const int carbonDioxideStoich = 2;
            const int waterStoich = 3;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByEthanol = ethanolMolecules / ethanolStoich;
            int maxReactionsByOxygen = oxygenMolecules / oxygenStoich;
            int maxReactions = Math.Min(maxReactionsByEthanol, maxReactionsByOxygen);

            // Calculate the number of products
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;
            int waterProduced = maxReactions * waterStoich;

            // Update the remaining ethanol and oxygen molecules
            ethanolMolecules -= maxReactions * ethanolStoich;
            oxygenMolecules -= maxReactions * oxygenStoich;

            return Tuple.Create(carbonDioxideProduced, waterProduced);
        }

        //Method to simulate the displacement of Iron(II) oxide with Sodium
        static Tuple<int, int> ReactFeOAndNa(ref int ironOxideMolecules, ref int sodiumMolecules)
        {
            // Stoichiometric coefficients for the reaction FeO + 2Na -> Na2O + Fe
            const int ironOxideStoich = 1;
            const int sodiumStoich = 2;
            const int sodiumOxideStoich = 1;
            const int ironStoich = 1;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByIronOxide = ironOxideMolecules / ironOxideStoich;
            int maxReactionsBySodium = sodiumMolecules / sodiumStoich;
            int maxReactions = Math.Min(maxReactionsByIronOxide, maxReactionsBySodium);

            // Calculate the number of products
            int sodiumOxideProduced = maxReactions * sodiumOxideStoich;
            int ironProduced = maxReactions * ironStoich;

            // Update the remaining iron(II) oxide and sodium atoms
            ironOxideMolecules -= maxReactions * ironOxideStoich;
            sodiumMolecules -= maxReactions * sodiumStoich;

            return Tuple.Create(sodiumOxideProduced, ironProduced);
        }

        //Method to Simulate Combustion of Ethene
        static Tuple<int, int> ReactC2H4AndO2(ref int etheneMolecules, ref int oxygenMolecules)
        {
            // Stoichiometric coefficients for the reaction C2H4 + 3O2 -> 2CO2 + 2H2O
            const int etheneStoich = 1;
            const int oxygenStoich = 3;
            const int carbonDioxideStoich = 2;
            const int waterStoich = 2;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByEthene = etheneMolecules / etheneStoich;
            int maxReactionsByOxygen = oxygenMolecules / oxygenStoich;
            int maxReactions = Math.Min(maxReactionsByEthene, maxReactionsByOxygen);

            // Calculate the number of products
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;
            int waterProduced = maxReactions * waterStoich;

            // Update the remaining ethene and oxygen molecules
            etheneMolecules -= maxReactions * etheneStoich;
            oxygenMolecules -= maxReactions * oxygenStoich;

            return Tuple.Create(carbonDioxideProduced, waterProduced);
        }
        //Method to Simulate Fermentation of Glucose
        static Tuple<int, int> ReactC6H12O6(ref int glucoseMolecules)
        {
            // Stoichiometric coefficients for the reaction C6H12O6 -> 2C2H5OH + 2CO2
            const int glucoseStoich = 1;
            const int ethanolStoich = 2;
            const int carbonDioxideStoich = 2;

            // Calculate the maximum number of products that can be produced
            int maxReactions = glucoseMolecules / glucoseStoich;

            // Calculate the number of products
            int ethanolProduced = maxReactions * ethanolStoich;
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;

            // Update the remaining glucose molecules
            glucoseMolecules -= maxReactions * glucoseStoich;

            return Tuple.Create(ethanolProduced, carbonDioxideProduced);
        }

        //Method to simulate Iron (III) Oxide reduction
        static Tuple<int, int> ReactFe2O3AndC(ref int ironOxideMolecules, ref int carbonAtoms)
        {
            // Stoichiometric coefficients for the reaction Fe2O3 + 3C -> 2Fe + 3CO2
            const int ironOxideStoich = 1;
            const int carbonStoich = 3;
            const int ironStoich = 2;
            const int carbonDioxideStoich = 3;

            // Calculate the maximum number of products that can be produced
            int maxReactionsByIronOxide = ironOxideMolecules / ironOxideStoich;
            int maxReactionsByCarbon = carbonAtoms / carbonStoich;
            int maxReactions = Math.Min(maxReactionsByIronOxide, maxReactionsByCarbon);
            // Calculate the number of products
            int ironProduced = maxReactions * ironStoich;
            int carbonDioxideProduced = maxReactions * carbonDioxideStoich;

            // Update the remaining iron(III) oxide and carbon atoms
            ironOxideMolecules -= maxReactions * ironOxideStoich;
            carbonAtoms -= maxReactions * carbonStoich;

            return Tuple.Create(ironProduced, carbonDioxideProduced);
        }
    }
}