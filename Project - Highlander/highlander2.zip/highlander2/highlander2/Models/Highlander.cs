using System.Collections.Generic;

namespace highlander2.Models
{

    public struct Point
{
    public int X { get; set; }
    public int Y { get; set; }

    public Point(int x, int y)
    {
        X = x;
        Y = y;
    }
}

    public class Highlander
    {
        public int Id { get; set; }
        public bool IsGood { get; set; }
        public int Strength { get; set; }
        public Point Location { get; set; }
        public List<string> History { get; set; } = new List<string>();  // To store interaction history

        // Additional properties
        public int LastDefeatedIteration { get; private set; }

        public Highlander(int id, bool isGood, int strength, Point location)
        {
            Id = id;
            IsGood = isGood;
            Strength = strength;
            Location = location;
            LastDefeatedIteration = 0;  // Initialize with zero, meaning no battle won yet.
        }

        public void AddHistory(string eventDescription)
        {
            History.Add(eventDescription);
        }

        // Method to move the Highlander on the grid
        public void Move(Point newPosition)
        {
            // we can add logic here to ensure the move is valid (e.g., within grid bounds)
            Location = newPosition;
        }

        // Method to absorb the strength of a defeated Highlander and log the event
        public void Absorb(Highlander defeated, int iteration)
        {
            Strength += defeated.Strength;  // Absorb the strength of the defeated
            LastDefeatedIteration = iteration;
            AddHistory($"Iteration {iteration}: Absorbed strength from Highlander {defeated.Id}. New strength: {Strength}.");
        }

        // This method determines the chance of winning a conflict
        public double GetWinningChance(int totalStrengthInConflict)
        {
            return (double)Strength / totalStrengthInConflict;
        }
    }
}
