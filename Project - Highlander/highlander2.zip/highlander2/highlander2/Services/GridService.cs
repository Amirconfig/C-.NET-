using highlander2.Models;
using System.Collections.Generic;
using System.Text;

namespace highlander2.Services
{
    public class GridService
    {
        private char[,] grid;
        private int gridSize;

        public GridService(int size)
        {
            gridSize = size;
            grid = new char[size, size];
            InitializeGrid();
        }

        // Initializes the grid with empty values
        public void InitializeGrid()
        {
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    grid[i, j] = '.';  // '.' represents an empty space
                }
            }
        }

        // Converts the grid to a string format for easy display or logging
        public string GridToString()
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    builder.Append(grid[i, j] + " ");
                }
                builder.AppendLine();
            }
            return builder.ToString();
        }

        // Updates the grid with the current positions of all Highlanders
        public void UpdateGrid(List<Highlander> highlanders)
        {
            InitializeGrid();  // Clear the grid before updating

            foreach (var highlander in highlanders)
            {
                if (highlander.Location.X >= 0 && highlander.Location.X < gridSize &&
                    highlander.Location.Y >= 0 && highlander.Location.Y < gridSize)
                {
                    grid[highlander.Location.X, highlander.Location.Y] = highlander.IsGood ? 'G' : 'B';  // 'G' for good, 'B' for bad
                }
            }
        }
    }
}
