﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Windows.Storage;

public static class DatabaseHelper
{
    static string dbFileName = "HighlanderSim.db";
    static string dbPath = Path.Combine(ApplicationData.Current.LocalFolder.Path, dbFileName);

    public static void InitializeDatabase()
    {
        // Check if database file already exists to avoid unnecessary initialization
        if (!File.Exists(dbPath))
        {
            using (var connection = new SqliteConnection($"Filename={dbPath}"))
            {
                connection.Open();

                var command = connection.CreateCommand();
                command.CommandText =
                @"
                    CREATE TABLE IF NOT EXISTS GameResults (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        GameId TEXT NOT NULL,
                        Description TEXT NOT NULL,
                        Detail TEXT NOT NULL,
                        CreatedDate DATETIME DEFAULT CURRENT_TIMESTAMP
                    );
                ";
                command.ExecuteNonQuery();
            }
        }
    }



    // This method is part of the DatabaseHelper class and is used to insert game results into the database.
    public static async Task AddGameResultAsync(string gameId, string description, string detail)
    {
        using (var connection = new SqliteConnection($"Filename={dbPath}"))
        {
            connection.Open();

            var command = connection.CreateCommand();
            command.CommandText =
            @"
            INSERT INTO GameResults (GameId, Description, Detail)
            VALUES ($gameId, $description, $detail);
        ";

            command.Parameters.AddWithValue("$gameId", gameId);
            command.Parameters.AddWithValue("$description", description);
            command.Parameters.AddWithValue("$detail", detail);

            await command.ExecuteNonQueryAsync();
        }
    }


    public static async Task<List<GameResult>> ReadAllGamesAsync()
    {
        List<GameResult> results = new List<GameResult>();

        using (var connection = new SqliteConnection($"Filename={dbPath}"))
        {
            connection.Open();

            var command = connection.CreateCommand();
            command.CommandText =
            @"
                SELECT GameId, Description, Detail, CreatedDate 
                FROM GameResults;
            ";

            using (var reader = await command.ExecuteReaderAsync())
            {
                while (reader.Read())
                {
                    GameResult result = new GameResult
                    {
                        GameId = reader.GetString(0),
                        Description = reader.GetString(1),
                        Detail = reader.GetString(2),
                        CreatedDate = reader.GetDateTime(3)
                    };
                    results.Add(result);
                }
            }
        }
        return results;
    }

    public class GameResult
    {
        public string GameId { get; set; }
        public string Description { get; set; }
        public string Detail { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}



