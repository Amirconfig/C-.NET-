﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using System.Diagnostics; // Make sure to have this using directive for Debug.WriteLine

namespace highlander2
{
    public sealed partial class SummaryPage : Page, INotifyPropertyChanged
    {
        private string _summaryText;
        public ObservableCollection<HighlanderDetails> Highlanders { get; set; }

        public string SummaryText
        {
            get { return _summaryText; }
            set { SetProperty(ref _summaryText, value); }
        }

        public SummaryPage()
        {
            InitializeComponent();
            Highlanders = new ObservableCollection<HighlanderDetails>();
            this.DataContext = this;
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            if (e.Parameter is SimulationResults results)
            {
                SummaryText = results.Summary;  // Assign summary text
                UpdateUIWithResults(results);
                Debug.WriteLine("Navigated to Summary Page with summary: " + results.Summary);
            }
        }

        private void UpdateUIWithResults(SimulationResults results)
        {
            foreach (var highlander in results.Highlanders)
            {
                Highlanders.Add(highlander);
            }
        }

        // Event handler to close the application
        private void QuitGame_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            Windows.UI.Xaml.Application.Current.Exit();
        }

        // Event handler to navigate back to the previous page
        private void BackToSimulation_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            if (Frame.CanGoBack)
            {
                Frame.GoBack();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void SetProperty<T>(ref T storage, T value, [CallerMemberName] string propertyName = null)
        {
            if (Equals(storage, value))
            {
                return;
            }
            storage = value;
            OnPropertyChanged(propertyName);
        }

        private void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public class HighlanderDetails
    {
        public string Name { get; set; }
        public List<string> EventDetails { get; set; }
        public bool IsGood { get; set; }
        public string TypeDescription => IsGood ? "Good" : "Bad";
    }

    public class SimulationResults
    {
        public string Summary { get; set; }
        public ObservableCollection<HighlanderDetails> Highlanders { get; set; }
    }

}
