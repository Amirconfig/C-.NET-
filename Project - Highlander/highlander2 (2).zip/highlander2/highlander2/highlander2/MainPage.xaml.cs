﻿using System;
using System.Collections.Generic;
using highlander2.Models;  // Include the namespace where Highlander and Point are defined
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Storage;
using System.Threading.Tasks;
using System.Text;
using System.Collections.ObjectModel;

namespace highlander2
{
    public sealed partial class MainPage : Page
    {

        string gameID;
        int simCount;
        public MainPage()
        {
            simCount = 0;

            // Get current DateTime as a base for the game ID
            DateTime now = DateTime.Now;

            // Convert the current time to a long format string (including milliseconds)
            string dateTimeString = now.ToString("yyyyMMddHHmmssfff");

            // Use a random number generator
            Random random = new Random();

            // Generate a random number and append it to the dateTimeString
            int randomNumber = random.Next(1000, 9999);
            gameID = dateTimeString + randomNumber.ToString();


            this.InitializeComponent();

            InitializeLogPath();
        }

        private void InitializeLogPath()
        {
            try
            {
                StorageFolder localFolder = ApplicationData.Current.LocalFolder;
                logPath = Path.Combine(localFolder.Path, "SimulationLog.txt");
                logWriter = new StreamWriter(logPath, append: true);
                logWriter.AutoFlush = true;
                Log("Log initialized.");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Failed to initialize log file: " + ex.ToString());
            }
        }

        private void StartSimulation_Click(object sender, RoutedEventArgs e)
        {
            // Use TryParse to safely convert and validate inputs
            if (!int.TryParse(txtGoodHighlanders.Text, out int goodHighlanders) ||
                !int.TryParse(txtBadHighlanders.Text, out int badHighlanders) ||
                !int.TryParse(txtGridSize.Text, out int gridSize) ||
                !int.TryParse(txtMaxIterations.Text, out int maxIterations))
            {
                txtResults.Text = "Please enter valid numeric values.";
                return;  // Stop processing if any input is invalid
            }

            // Additional validation to check for reasonable values
            if (goodHighlanders < 0 || badHighlanders < 0 || gridSize <= 0 || maxIterations < 1)
            {
                txtResults.Text = "Please enter positive values. Grid size and max iterations must be greater than zero.";
                return;
            }

            // Create lists to hold your Highlander objects
            List<Highlander> goodGuys = new List<Highlander>();
            List<Highlander> badGuys = new List<Highlander>();

            // Random to place Highlanders randomly on the grid
            Random rand = new Random();

            // Initialize Good Highlanders
            for (int i = 0; i < goodHighlanders; i++)
            {
                highlander2.Models.Point location = new highlander2.Models.Point(rand.Next(0, gridSize), rand.Next(0, gridSize));
                Highlander goodGuy = new Highlander(i, true, 100, location);
                goodGuys.Add(goodGuy);
            }

            // Initialize Bad Highlanders
            for (int i = 0; i < badHighlanders; i++)
            {
                highlander2.Models.Point location = new highlander2.Models.Point(rand.Next(0, gridSize), rand.Next(0, gridSize));
                Highlander badGuy = new Highlander(i + goodHighlanders, false, 100, location);
                badGuys.Add(badGuy);
            }

            txtResults.Text = $"Initialized {goodHighlanders} good and {badHighlanders} bad Highlanders on a {gridSize}x{gridSize} grid. Ready to simulate for a max of {maxIterations} iterations.";


            InitializeGrid(gridSize);  // Initialize the grid with the given size
            //SetupLogging();
            Log("Simulation Started", 1);  // Log initial state

            RunSimulation(goodGuys, badGuys, gridSize, maxIterations);
            simCount++;
        }


        private async void RunSimulation(List<Highlander> goodGuys, List<Highlander> badGuys, int gridSize, int maxIterations)
        {
            try
            {
                for (int iteration = 0; iteration < maxIterations; iteration++)
                {
                    Log($"\n==***********************************==\nIteration {iteration + 1} started.");
                    MoveHighlanders(goodGuys.Concat(badGuys).ToList(), gridSize);
                    ResolveConflicts(goodGuys, badGuys, iteration);  // pass iteration count here
                    Log($"Iteration {iteration + 1} completed.");
                    if (CheckEndCondition(goodGuys, badGuys))
                    {
                        Log("End condition met.");
                        break;
                    }
                }
                DisplayResults(goodGuys, badGuys);  // Log final results before closing the writer
            }
            finally
            {
                if (logWriter != null)
                {
                    //logWriter.Close();  // Ensure the writer is closed properly
                }
                await CopyLogToAccessibleLocation();  // Continue with copying after closing the log
            }
        }



        private void Log(string message, int? iteration = null)
        {
            if (iteration.HasValue)
            {
                if(logWriter != null)
                {
                    SetupLogging();
                }
                logWriter.WriteLine(message);  // Use iteration + 1 for user-friendly counting
            }
            else
            {
                logWriter.WriteLine(message);
            }
            logWriter.Flush();  // Flush after every write to ensure it's saved
        }


        private void MoveHighlanders(List<Highlander> highlanders, int gridSize)
        {
            Random rand = new Random();
            Dictionary<Highlander, highlander2.Models.Point> newPositions = new Dictionary<Highlander, highlander2.Models.Point>();

            foreach (var highlander in highlanders)
            {
                int moveX = rand.Next(-1, 2); // Generates -1, 0, or 1
                int moveY = rand.Next(-1, 2);
                int newX = Math.Max(0, Math.Min(gridSize - 1, highlander.Location.X + moveX));
                int newY = Math.Max(0, Math.Min(gridSize - 1, highlander.Location.Y + moveY));
                newPositions[highlander] = new highlander2.Models.Point(newX, newY);  // Store new position
                highlander.Location = newPositions[highlander];  // Update position
            }

            UpdateGrid(highlanders);  // Update grid after all moves
            //Log("All Highlanders moved", 1);  // Log grid state after all moves
        }

        private async void DisplayResults(List<Highlander> goodGuys, List<Highlander> badGuys)
        {
            StringBuilder summaryBuilder = new StringBuilder();
            StringBuilder summaryBuilder2 = new StringBuilder();
            int goodRemaining = goodGuys.Count;
            int badRemaining = badGuys.Count;
            StringBuilder displaySummaryBuilder = new StringBuilder();

            Log("=================================================================");
            Log("=================================================================");

            if (goodGuys.Count + badGuys.Count == 1)
            {

                var lastHighlander = goodGuys.Count > 0 ? goodGuys[0] : badGuys[0];
                summaryBuilder.AppendLine($"Winner: Highlander {lastHighlander.Id} ({(lastHighlander.IsGood ? "Good" : "Bad")})");
                displaySummaryBuilder.AppendLine($"Winner: Highlander {lastHighlander.Id} ({(lastHighlander.IsGood ? "Good" : "Bad")})");
                summaryBuilder.AppendLine("History of interactions:");
                foreach (var eventDetail in lastHighlander.History)
                {
                    summaryBuilder.AppendLine(eventDetail);
                }
                summaryBuilder.AppendLine($"Total power absorbed: {lastHighlander.Strength}");

                summaryBuilder2.AppendLine(summaryBuilder.ToString());
            }
            else
            {
                
                summaryBuilder.AppendLine("Simulation ended with no single winner.");
                summaryBuilder.AppendLine($"{goodRemaining} Good Highlanders remained.");
                summaryBuilder.AppendLine($"{badRemaining} Bad Highlanders remained.");
                summaryBuilder2.AppendLine(summaryBuilder.ToString());

                foreach (var highlander in goodGuys.Concat(badGuys))
                {
                    summaryBuilder.AppendLine($"Highlander {highlander.Id} ({(highlander.IsGood ? "Good" : "Bad")}) - Events:");
                    foreach (var eventDetail in highlander.History)
                    {
                        summaryBuilder.AppendLine(eventDetail);
                    }
                }
            }

            // Show a ContentDialog with the complete summary for review before navigating
            ContentDialog summaryDialog = new ContentDialog
            {
                Title = "Simulation Summary",
                Content = new ScrollViewer
                {
                    Content = new TextBlock
                    {
                        Text = summaryBuilder.ToString(),
                        TextWrapping = TextWrapping.Wrap
                    }
                },
                CloseButtonText = "Ok"
            };
            // Store the result in the database
            await DatabaseHelper.AddGameResultAsync(gameID, summaryBuilder2.ToString(), summaryBuilder2.ToString());
            await summaryDialog.ShowAsync();

            // Construct the results object to be passed to the summary page
            SimulationResults results = new SimulationResults
            {
                Highlanders = new ObservableCollection<HighlanderDetails>(
                    goodGuys.Concat(badGuys).Select(h => new HighlanderDetails
                    {
                        Name = $"Highlander {h.Id} ({(h.IsGood ? "Good" : "Bad")})",
                        EventDetails = h.History.Select((eventDetail, index) => $"{eventDetail}").ToList(),
                        IsGood = h.IsGood
                    })),
                Summary = summaryBuilder2.ToString()
            };

            // Navigate to SummaryPage with structured results
            this.Frame.Navigate(typeof(SummaryPage), results);
        }



        private async Task CopyLogToAccessibleLocation()
        {
            try
            {
                StorageFolder localFolder = ApplicationData.Current.LocalFolder;
                StorageFile logFile = await localFolder.GetFileAsync("SimulationLog.txt");
                StorageFolder documentsFolder = KnownFolders.DocumentsLibrary;
                await logFile.CopyAsync(documentsFolder, "SimulationLog.txt", NameCollisionOption.ReplaceExisting);
                logPath = Path.Combine(documentsFolder.Path, "SimulationLog.txt");
            }
            catch (Exception ex)
            {
                Log("Failed to copy log file: " + ex.Message);
            }

        }

        private bool CheckEndCondition(List<Highlander> goodGuys, List<Highlander> badGuys)
        {
            if (goodGuys.Count + badGuys.Count <= 1)
            {
                Log("Simulation ending: Less than or one Highlander remaining.");
                return true;  // End condition met: only one or none left
            }
            return false;
        }


        private void ResolveConflicts(List<Highlander> goodGuys, List<Highlander> badGuys, int iteration)
        {
            var allHighlanders = goodGuys.Concat(badGuys).ToList();
            var positions = allHighlanders.GroupBy(h => new { h.Location.X, h.Location.Y });

            foreach (var position in positions)
            {
                if (position.Count() > 1)  // Conflict detected
                {
                    ResolveConflictAtPosition(position.ToList(), goodGuys, badGuys, iteration);
                }
            }
        }


        private void ResolveConflictAtPosition(List<Highlander> conflictingHighlanders, List<Highlander> goodGuys, List<Highlander> badGuys, int iteration)
        {
            // Group highlanders at this position by type (Good or Bad)
            var groupedByType = conflictingHighlanders.GroupBy(h => h.IsGood).ToList();

            if (groupedByType.Count == 1)
            {
                // All highlanders are of the same type, check if they are bad
                bool areAllBad = groupedByType[0].Key == false;
                if (areAllBad)
                {
                    // All bad highlanders fight: last one standing wins
                    ResolveBattle(conflictingHighlanders, goodGuys, badGuys, iteration);
                }
                // If all are good, they do not fight
            }
            else
            {
                // Mixed group, good and bad highlanders encountered
                var goodGroup = groupedByType.FirstOrDefault(g => g.Key == true);
                var badGroup = groupedByType.FirstOrDefault(g => g.Key == false);

                ResolveGoodBadConflict(goodGroup.ToList(), badGroup.ToList(), goodGuys, badGuys, iteration);
            }

            // Update the grid to reflect the resolution
            UpdateGrid(goodGuys.Concat(badGuys).ToList());
        }


        private void ResolveBattle(List<Highlander> highlanders, List<Highlander> goodGuys, List<Highlander> badGuys, int iteration)
        {
            int totalStrength = highlanders.Sum(h => h.Strength);
            // Decide the battle based on the strength of the highlanders.
            while (highlanders.Count > 1)
            {
                Highlander winner = DecideWinner(highlanders, totalStrength);
                foreach (var loser in highlanders.Where(h => h != winner).ToList())
                {
                    winner.Absorb(loser, iteration);
                    highlanders.Remove(loser);
                    if (loser.IsGood) goodGuys.Remove(loser); else badGuys.Remove(loser);
                }
            }

            // After resolving the battle, log the details with the iteration number
            foreach (var highlander in highlanders)
            {
                Log($"Highlander {highlander.Id} ({(highlander.IsGood ? "Good" : "Bad")}) - Current strength: {highlander.Strength}", iteration);
            }
        }

        private Highlander DecideWinner(List<Highlander> highlanders, int totalStrength)
        {
            double randomNumber = new Random().NextDouble();
            double cumulativeProbability = 0.0;

            foreach (var highlander in highlanders)
            {
                cumulativeProbability += highlander.GetWinningChance(totalStrength);
                if (randomNumber < cumulativeProbability)
                {
                    return highlander;
                }
            }

            return highlanders.Last();  // Fallback in case of rounding errors
        }

        private void ResolveGoodBadConflict(List<Highlander> goodGroup, List<Highlander> badGroup, List<Highlander> goodGuys, List<Highlander> badGuys, int iteration)
        {
            foreach (var good in goodGroup)
            {
                foreach (var bad in badGroup)
                {
                    string interactionDetails = $"Iteration {iteration}: ";
                    if (AttemptEscape(good, bad))
                    {
                        good.AddHistory(interactionDetails + $"Escaped from {bad.Id}");
                        bad.AddHistory(interactionDetails + $"Failed to catch {good.Id}");
                        Log($"Good Highlander {good.Id} escaped from Bad Highlander {bad.Id}");
                    }
                    else
                    {
                        if (good.Strength > bad.Strength)
                        {
                            good.AddHistory(interactionDetails + $"Killed {bad.Id} and absorbed power");
                            badGuys.Remove(bad);
                            Log($"Good Highlander {good.Id} killed Bad Highlander {bad.Id} and absorbed power");
                        }
                        else
                        {
                            bad.AddHistory(interactionDetails + $"Killed {good.Id}");
                            goodGuys.Remove(good);
                            Log($"Bad Highlander {bad.Id} killed Good Highlander {good.Id}");
                        }
                    }
                }
            }
        }



        private bool AttemptEscape(Highlander good, Highlander bad)
        {
            // Randomly decide if escape is successful based on relative strength
            return new Random().NextDouble() < (double)good.Strength / (good.Strength + bad.Strength);
        }





        private StreamWriter logWriter;
        private string logPath;  // Add this line

        private void SetupLogging()
        {
            // Setting up the log file path to use the local app data store
            string folderPath = ApplicationData.Current.LocalFolder.Path;
            logPath = Path.Combine(folderPath, "SimulationLog.txt");

            txtResults.Text = logPath;

            // Close existing log writer if open
            if (logWriter != null)
            {
                logWriter.Dispose();
            }

            try
            {
                // Set append mode to false to overwrite the existing file
                logWriter = new StreamWriter(logPath, false);  // This will clear the log file on each run
                logWriter.AutoFlush = true;  // AutoFlush to immediately write to file
            }
            catch (Exception ex)
            {
                txtResults.Text = "Failed to initialize log file: " + ex.Message;
            }
        }




        // Add a global variable to represent the grid
        private char[,] simulationGrid;

        private void InitializeGrid(int gridSize)
        {
            simulationGrid = new char[gridSize, gridSize];
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    simulationGrid[i, j] = '.';  // Use '.' to represent an empty cell
                }
            }
        }

        private string GridToString()
        {
            StringBuilder gridRepresentation = new StringBuilder();
            for (int i = 0; i < simulationGrid.GetLength(0); i++)
            {
                for (int j = 0; j < simulationGrid.GetLength(1); j++)
                {
                    gridRepresentation.Append(simulationGrid[i, j] + " ");
                }
                gridRepresentation.AppendLine();
            }
            return gridRepresentation.ToString();
        }

        private void UpdateGrid(List<Highlander> highlanders)
        {
            // Clear previous positions
            InitializeGrid(simulationGrid.GetLength(0));

            // Mark current positions of all Highlanders
            foreach (var highlander in highlanders)
            {
                if (highlander.Location.X < simulationGrid.GetLength(0) && highlander.Location.Y < simulationGrid.GetLength(1))
                {
                    char symbol = highlander.IsGood ? 'G' : 'B';
                    simulationGrid[highlander.Location.X, highlander.Location.Y] = symbol;
                }
            }
        }

        // Implementing IDisposable to ensure resources are cleaned up correctly
        public void Dispose()
        {
            logWriter?.Dispose();
        }

        // Ensure logging resources are disposed of when the page is navigated from
        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            try
            {
                if (logWriter != null)
                {
                    logWriter.Dispose();
                    logWriter = null;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Error disposing log writer: " + ex.ToString());
            }
            base.OnNavigatedFrom(e);
        }


        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            if (logWriter == null)
            {
                InitializeLogPath();  // Attempt to reinitialize if not already done
            }
        }

        private void ViewGamesHistory_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(DBResult)); // Navigate to the DBResult page
        }


        private void QuitGame_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Exit(); // This will close the application
        }



        private void txtGoodHighlanders_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ScrollViewer_ViewChanged(object sender, ScrollViewerViewChangedEventArgs e)
        {

        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }
    }
}
