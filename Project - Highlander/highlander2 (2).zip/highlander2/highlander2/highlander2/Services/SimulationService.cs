using highlander2.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace highlander2.Services
{
    public class SimulationService
    {
        private StreamWriter logWriter;
        public string LogPath { get; private set; }

        public SimulationService(string logPath)
        {
            LogPath = logPath;
            logWriter = new StreamWriter(logPath, append: true) { AutoFlush = true };
        }

        public void Log(string message, bool includeGrid = false, string gridData = "")
        {
            if (includeGrid && !string.IsNullOrEmpty(gridData))
            {
                logWriter.WriteLine("Current Grid State:");
                logWriter.WriteLine(gridData);
            }
            logWriter.WriteLine(message);
        }

        public void CloseLog()
        {
            logWriter?.Close();
        }

        public void MoveHighlanders(List<Highlander> highlanders, int gridSize)
        {
            Random rand = new Random();
            foreach (var highlander in highlanders)
            {
                int moveX = rand.Next(-1, 2);
                int moveY = rand.Next(-1, 2);
                int newX = Math.Max(0, Math.Min(gridSize - 1, highlander.Location.X + moveX));
                int newY = Math.Max(0, Math.Min(gridSize - 1, highlander.Location.Y + moveY));
                highlander.Move(new Point(newX, newY));
                Log($"Highlander {highlander.Id} moved to ({newX}, {newY})");
            }
        }

        public void ResolveConflicts(List<Highlander> highlanders)
        {
            var groupedByLocation = highlanders.GroupBy(h => new { h.Location.X, h.Location.Y });
            foreach (var group in groupedByLocation)
            {
                if (group.Count() > 1)
                {
                    // Conflict resolution logic: random Highlander wins
                    Highlander winner = group.OrderBy(x => Guid.NewGuid()).FirstOrDefault();
                    foreach (var highlander in group)
                    {
                        if (highlander != winner)
                        {
                            Log($"Highlander {highlander.Id} killed by Highlander {winner.Id} at location ({winner.Location.X}, {winner.Location.Y})");
                            highlanders.Remove(highlander);
                        }
                    }
                }
            }
        }

        public bool CheckEndCondition(List<Highlander> highlanders)
        {
            if (highlanders.Count <= 1)
            {
                Log("Simulation ending: Less than or one Highlander remaining.");
                return true;
            }
            return false;
        }
    }
}
