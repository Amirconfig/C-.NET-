﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace highlander2
{
    public sealed partial class DBResult : Page
    {
        public ObservableCollection<GameResult> GameResults { get; set; }

        public DBResult()
        {
            this.InitializeComponent();
            GameResults = new ObservableCollection<GameResult>(); // Initialize the collection
        }

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            var gameResults = await DatabaseHelper.ReadAllGamesAsync();
            foreach (var result in gameResults)
            {
                GameResults.Add(new highlander2.GameResult
                {
                    GameId = result.GameId,
                    Description = result.Description,
                    Detail = result.Detail,
                    CreatedDate = result.CreatedDate
                });
                // Debug output to show each game result loaded
                Debug.WriteLine($"Loaded Game Result: ID={result.GameId}, Description={result.Description}, Detail={result.Detail}, Created={result.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss")}");
            
        }


        }



        private void LoadGameResults()
        {
            // Load your game results from the database here
            // This is a placeholder logic
            var results = DatabaseHelper.ReadAllGamesAsync().Result;
            foreach (var result in results)
            {
                GameResults.Add(new GameResult { Description = result.Description, Detail = result.Detail });
            }
        }

        private void QuitGame_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            Windows.UI.Xaml.Application.Current.Exit();
        }

        private void BackToSimulation_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            if (Frame.CanGoBack)
            {
                Frame.GoBack();
            }
        }
    }

    // Dummy class for illustration
    public class GameResult
    {
        public string Description { get; set; }
        public string Detail { get; set; }
        public DateTime CreatedDate { get; internal set; }
        public string GameId { get; internal set; }
    }
}
