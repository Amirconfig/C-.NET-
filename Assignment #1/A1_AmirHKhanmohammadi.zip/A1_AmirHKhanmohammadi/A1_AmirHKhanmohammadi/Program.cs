﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1_AmirHKhanmohammadi
{
    internal class Program
    {
        // Calculates sin(2θ) for a given θ.
        public double f(double theta)
        {
            return Math.Sin(2 * theta);
        }

        // Calculates log(θ) for a given θ.
        public double g(double theta)
        {
            return Math.Log(theta);
        }

        // Displays the calculation results in a tabular format.
        public static void Display(double theta, double sin2Theta, double logTheta)
        {
            // I used String Interpolation : The syntax is $"...", with expressions inside {}
            Console.WriteLine($"{theta:F2}\t\t{sin2Theta:F4}\t\t{logTheta:F4}");
        }
        //Main() -----------------------
        static void Main(string[] args)
        {
            // Encoding for Special Characters (θ) (googled)
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Welcome message and program description (I wanted to add sorry!)
            Console.WriteLine("Welcome to the Theta Calculation Program!");
            Console.WriteLine("This program calculates sin(2θ) and log(θ) for a range of θ values.");

            while (true)
            {
                // Step 1 -> declare variables
                double lowerBound, upperBound;
                int numberOfValues;

                // Step 2 -> get value from the user
                Console.Write("Enter the lower value of θ (in radians): ");
                lowerBound = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter the upper value of θ (in radians): ");
                upperBound = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter the number of θ values to calculate: ");
                numberOfValues = Convert.ToInt32(Console.ReadLine());

                double interval = (upperBound - lowerBound) / (numberOfValues - 1);
                Program program = new Program();

                // Step 3 -> Calculation and Step 4 -> display result
                Console.WriteLine("\nθ (rad)\t\tSin(2θ)\t\tLog(θ)");
                Console.WriteLine("---------------------------------------------");
                for (int i = 0; i < numberOfValues; i++)
                {
                    double theta = lowerBound + i * interval;
                    Display(theta, program.f(theta), program.g(theta)); // Displays the calculation results in tabular form
                }

                // Check if the user wants to perform another calculation
                Console.WriteLine("\nWould you like to perform another calculation? (yes/no)");
                string response = Console.ReadLine().ToLower();
                if (response != "yes")
                {
                    if (response == "no")
                    {
                        Console.WriteLine("Thank you for using my app. Exiting in 5 seconds...");
                        System.Threading.Thread.Sleep(5000); // Waits for 5 seconds
                    }
                    break;
                }
            }
        }
    }
}

