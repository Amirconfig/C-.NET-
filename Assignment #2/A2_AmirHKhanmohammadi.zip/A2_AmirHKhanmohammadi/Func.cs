﻿using System;

namespace A2_AmirHKhanmohammadi.Functions
{
    public class Func : IFunc
    {
        public double func(double theta)
        {
            return Math.Log(theta);
        }
    }
}
