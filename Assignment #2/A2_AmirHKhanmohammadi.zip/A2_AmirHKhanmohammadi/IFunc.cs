﻿

namespace A2_AmirHKhanmohammadi.Functions
{
    public interface IFunc
    {
        double func(double theta);
    }
}
