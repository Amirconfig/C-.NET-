﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using A2_AmirHKhanmohammadi.Functions;


namespace A2_AmirHKhanmohammadi
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            ResultsDataGrid.Items.Clear();

            string errorMessage = "";
            bool isValid = true;

            // Validate Lower Bound
            if (!double.TryParse(LowerBoundTextBox.Text, out double lowerBound))
            {
                errorMessage += "- Invalid input for lower value of θ. Please enter a valid number.\n";
                isValid = false;
            }

            // Validate Upper Bound
            if (!double.TryParse(UpperBoundTextBox.Text, out double upperBound))
            {
                errorMessage += "- Invalid input for upper value of θ. Please enter a valid number.\n";
                isValid = false;
            }
            else if (lowerBound >= upperBound)
            {
                errorMessage += "- The upper value of θ must be greater than the lower value of θ.\n";
                isValid = false;
            }

            // Validate Number of Intervals
            if (!int.TryParse(IntervalsTextBox.Text, out int numberOfValues) || numberOfValues <= 0)
            {
                errorMessage += "- Please enter a positive integer for the number of intervals.\n";
                isValid = false;
            }

            // If not valid, show the error message(s) and exit the handler
            if (!isValid)
            {
                CustomDialog customDialog = new CustomDialog(errorMessage.TrimEnd('\n'));
                customDialog.ShowDialog();
                return;
            }

            // Perform calculations and update the DataGrid
            double interval = (upperBound - lowerBound) / numberOfValues;
            IFunc logFunction = new Func(); // Using the Func class that implements IFunc

            for (int i = 0; i < numberOfValues; i++)
            {
                double theta = lowerBound + i * interval;
                double sin2Theta = SinComponent.Sin2Theta(theta);
                double logTheta;

                try
                {
                    logTheta = logFunction.func(theta);
                }
                catch
                {
                    logTheta = double.NaN; // Handle invalid log input
                }

                // Populate the DataGrid
                ResultsDataGrid.Items.Add(new { Theta = theta, Sin2Theta = sin2Theta, LogTheta = double.IsNaN(logTheta) ? "Invalid" : logTheta.ToString() });
            }
        }



        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            // Clear text boxes and the DataGrid
            LowerBoundTextBox.Clear();
            UpperBoundTextBox.Clear();
            IntervalsTextBox.Clear();
            ResultsDataGrid.Items.Clear();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close(); // Closes the MainWindow
        }


    }
}

