﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2_AmirHKhanmohammadi
{
    public static class SinComponent
    {
        public static double Sin2Theta(double theta)
        {
            return Math.Sin(2 * theta);
        }
    }
}
