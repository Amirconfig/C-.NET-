﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace AmirWCFServiceAndUWPApp
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public double CalculateHarp(double ale, double hora, double hark, double manjp, double supe, double naviz, double anx)
        {
            double part1 = Math.Pow(3, (1 + (ale / hora)) / 23);

            double part2 = ((anx + Math.Pow(5 * supe, anx)) / manjp)
                           / (manjp + ((hark + Math.Pow(hora, supe + 5)) / (naviz * hark)));

            double part3 = (Math.Pow((4 + supe) / (4.33 * hark),
                           ((manjp + Math.Pow(ale, anx)) / (naviz + (0.679 * hora)))))
                           / (hora * Math.Pow(supe, naviz));

            double harp = part1 + part2 + part3;
            return harp;
        }


    }
}
