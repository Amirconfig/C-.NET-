﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Media.Protection.PlayReady;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;


namespace AmirUWPApp
{

    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();

        }

        private async void CalculateButton_Click(object sender, RoutedEventArgs e)
        {

            ResultTextBlock.Text = string.Empty;

            HarpCalculationServiceReference.Service1Client sc = new HarpCalculationServiceReference.Service1Client();

            try
            {

                double ale = Convert.ToDouble(AleTextBox.Text);
                double hora = Convert.ToDouble(HoraTextBox.Text);
                double hark = Convert.ToDouble(HarkTextBox.Text);
                double manjp = Convert.ToDouble(ManjpTextBox.Text);
                double supe = Convert.ToDouble(SupeTextBox.Text);
                double naviz = Convert.ToDouble(NavizTextBox.Text);
                double anx = Convert.ToDouble(AnxTextBox.Text);


                double result = await sc.CalculateHarpAsync(ale, hora, hark, manjp, supe, naviz, anx);
                ResultTextBlock.Text = result.ToString();

            }
            catch (FormatException)
            {
                ResultTextBlock.Text = "Please enter valid numbers for all fields.";
            }
            catch (Exception ex)
            {
                ResultTextBlock.Text = "An error occurred: " + ex.Message;
            }

        }
    }
}
